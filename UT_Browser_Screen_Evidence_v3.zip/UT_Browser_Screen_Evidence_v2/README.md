# UT Browser Screen Evidence

Real Chrome, Edge, and Firefox browser automation that captures before/after screenshots and packs them into one evidence workbook per browser.

## Files

- `ut_cases.md` — editable Markdown file containing URL, credentials, selectors, and before/after text per case
- `run-ut.js` — Playwright runner with two separate commands: `node run-ut.js before` captures the clean full browser-window **before** screenshot plus the raw server HTML and rendered DOM for every case/browser and stops; `node run-ut.js after` reads the saved before HTML/DOM, captures the **after** screenshots and HTML, and compares them so the changed area can be boxed
- `nav-find.js` — navigation resolution module (route config lookup, cache replay, scoring helpers)
- `nav-gen.js` — auto-generates `nav-routes.json` from project source files
- `nav-sources.json` — lists project roots + baseUrl for the generator
- `nav-routes.json` — generated navigation routes (committed, hand-editable)
- `capture-window.ps1` — Windows helper that captures the actual OS browser window (tab bar + address bar) from the screen
- `generate_evidence.py` — builds one xlsx per browser (`画面エビデンス_Chrome.xlsx`, `_Edge.xlsx`, `_Firefox.xlsx`) with the real before/after screenshots embedded side by side and a native Excel rectangle annotation overlaid on the changed area of each screenshot
- `ut-report/` — generated results, before/after screenshots, and per-case raw HTML + rendered DOM files

## Setup

```bash
npm install
pip install -r requirements.txt
# Edit nav-sources.json with your project paths, then generate routes:
npm run nav:generate
```

## Run the full evidence flow

The flow is split into two browser runs so you can modify the real code in between:

```bash
npm run ut          # 1. capture all BEFORE evidence, then stop
# ... modify your real code (save + restart / re-serve, or change the page in DevTools) ...
npm run modified    # 2. capture all AFTER evidence, compare with before, generate the Excel workbooks
```

`npm run ut` captures the before evidence (screenshot, raw HTML, rendered DOM) for every UT case in all three browsers (Chrome, Edge, Firefox) and stops. `npm run modified` re-opens each browser, captures the after evidence, compares it against the saved before HTML/DOM, and immediately generates the three browser-specific workbooks (`画面エビデンス_*.xlsx`) with the real before/after screenshots side by side and a red box on the changed area.

To only regenerate the workbooks from the last after run (without re-capturing browsers):

```bash
python generate_evidence.py
```

An all-in-one run without a code-change pause is also available:

```bash
npm run evidence
```

## Edit the case values

Update the entries in `ut_cases.md`. Each case runs in all three browsers, so the `Browser` field is not needed. Each case supports two modes:

### 1) BeforeText / AfterText mode (existing workflow)

```md
## UT-001
- TestID: UT-001
- URL: https://www.saucedemo.com/
- LoginId: standard_user
- Password: secret_sauce
- LoginIdSelector: #user-name
- PasswordSelector: #password
- LoginButtonSelector: #login-button
- BeforeText: Sauce Labs Backpack   # text visible on the original screen
- AfterText: Sauce Labs Bag         # text shown after the modification
- Keyword: Sauce Labs Backpack      # fallback label / matching text
- Description: Product title label change verification
```

### 2) Keyword-only mode (optional, only when `AfterText` is empty)

```md
## UT-001
- TestID: UT-001
- URL: http://localhost:5173/
- LoginId: (not applicable)
- Password: (not applicable)
- LoginIdSelector: -
- PasswordSelector: -
- LoginButtonSelector: -
- Keyword: Skip — start at N5
- Description: Skip text label change verification
```

When `AfterText` is absent, the runner uses `Keyword` during the before run to find the target element, saves its bounding box position, and then reuses that saved position during the after run instead of searching by text again. This lets the evidence workbook continue to highlight the same UI element even if the visible text changes completely.

### 3) `PartialText` mode (optional, for "fix part" cases where only a text fragment changes)

When the change is only a small fragment of a larger label (e.g. `Skip — start at N5` → `Skip — begin with N5`), add a `PartialText` field with just the fragment that changes. The runner locates the element by substring match (instead of exact match) and boxes **only that text span**, not the whole keyword element:

```md
## UT-001
- TestID: UT-001
- URL: http://localhost:5174/
- LoginId: (not applicable)
- Password: (not applicable)
- LoginIdSelector: -
- PasswordSelector: -
- LoginButtonSelector: -
- Keyword: Skip — start at N5
- PartialText: start at N5
- Description: Skip text label change verification (start at N5 -> begin with N5)
```

`Keyword` keeps the full label (shown in the workbook's Keyword column); `PartialText` is the fragment that is found and boxed.

**Auto-slice (no `AfterPartialText`):** with only `PartialText`, the before box wraps the whole fragment (`start at N5`), and the **after box is auto-sliced to the changed words** (`begin with`). In the after run the runner re-locates the element by its saved stable selector, reads its current text, diffs it against the saved before text, and boxes only the changed slice. The shared `N5` is not boxed in the after screenshot, and no index counting is needed.

**Auto-slice (both boxes precise):** optionally add `AfterPartialText: begin with N5`. Then the runner diffs the two fragments and both boxes wrap only the changed words — before `start at`, after `begin with`.

Optional manual overrides take precedence over auto-slice (indices are character offsets into the fragment, end is exclusive):
- `SliceStart` / `SliceEnd` — before box slice.
- `AfterSliceStart` / `AfterSliceEnd` — after box slice (default to `SliceStart`/`SliceEnd`).

The runner reads these values at runtime, so flows can be edited without touching the JavaScript.

### 4) Expected result and user verdict (optional)

Add `ExpectedResult` to specify text that must appear on the after-screen for
the case to pass. If set and the text is not found, the status becomes `FAILED`
(Excel still generates). `ManualStatus` records your own verdict
(`PASS`/`FAIL`/`SKIP`/`NG`/`OK`) as `User Verdict` in the report and Excel;
it never affects exit codes.

```md
## UT-001
- TestID: UT-001
- URL: http://localhost:5173/
- Keyword: Dashboard
- ExpectedResult: Dashboard is live
- ManualStatus: PASS
- Description: Dashboard screen renders after deploy
```

When the change is only a small fragment of a larger label (e.g. `Skip — start at N5` → `Skip — begin with N5`), add a `PartialText` field with just the fragment that changes. The runner locates the element by substring match (instead of exact match) and boxes **only that text span**, not the whole keyword element:

```md
## UT-001
- TestID: UT-001
- URL: http://localhost:5174/
- LoginId: (not applicable)
- Password: (not applicable)
- LoginIdSelector: -
- PasswordSelector: -
- LoginButtonSelector: -
- Keyword: Skip — start at N5
- PartialText: start at N5
- Description: Skip text label change verification (start at N5 -> begin with N5)
```

`Keyword` keeps the full label (shown in the workbook's Keyword column); `PartialText` is the fragment that is found and boxed.

**Auto-slice (no `AfterPartialText`):** with only `PartialText`, the before box wraps the whole fragment (`start at N5`), and the **after box is auto-sliced to the changed words** (`begin with`). In the after run the runner re-locates the element by its saved stable selector, reads its current text, diffs it against the saved before text, and boxes only the changed slice. The shared `N5` is not boxed in the after screenshot, and no index counting is needed.

**Auto-slice (both boxes precise):** optionally add `AfterPartialText: begin with N5`. Then the runner diffs the two fragments and both boxes wrap only the changed words — before `start at`, after `begin with`.

Optional manual overrides take precedence over auto-slice (indices are character offsets into the fragment, end is exclusive):
- `SliceStart` / `SliceEnd` — before box slice.
- `AfterSliceStart` / `AfterSliceEnd` — after box slice (default to `SliceStart`/`SliceEnd`).

The runner reads these values at runtime, so flows can be edited without touching the JavaScript.

## Real-code change flow

The runner is split into two separate commands so the before evidence is captured first, you modify the real code, and then the after evidence is captured and compared:

1. **`npm run ut`** — for every case × browser, opens the real browser, logs in, verifies the gate text (`BeforeText` or `Keyword`), captures the before screenshot, raw HTML, and rendered DOM, and (in keyword-only mode) remembers the element's viewport position. Then it stops (no interactive pause).
2. **Modify the code** — edit the served source and save + restart / re-serve the app, or change the page in DevTools.
3. **`npm run modified`** — re-opens each browser, logs in again, captures the after screenshot, raw HTML, and rendered DOM, compares the before/after HTML and DOM, and generates the Excel workbooks.

No JS-only fix is applied automatically. If the rendered page is identical before/after (no change detected), that case is marked `ERROR` and the runner continues checking the remaining cases. After all cases finish, the command exits with an error before writing the report or generating Excel workbooks, so unchanged evidence such as `start at N5` before and `start at N5` after blocks output generation. Fix + re-serve the code and run `npm run modified` again (the before evidence is still on disk). The `AfterText`-not-found case stays a warning only.

Note: for SPA apps (Vite, React, etc.) the raw server HTML is only the app shell and never contains your content, so the unchanged-code validation is done on the **rendered DOM** (Vite's `?t=` HMR cache-busters are stripped first). The raw HTML is kept for evidence and shown in the message, but only informational.

## HTML evidence

For every case and browser, the runner saves two kinds of HTML evidence (no separate diff files are written — the diff is computed internally to locate the changed area):

Raw server source (the same content as "View Page Source" / Ctrl+U), fetched over HTTP with the logged-in session:

- `ut-report/html/{TestID}-{Browser}-before.html` — server HTML before the change
- `ut-report/html/{TestID}-{Browser}-after.html` — server HTML after the change

Rendered DOM (the live page after JavaScript, matching what DevTools Elements shows), captured at the same before/after points:

- `ut-report/html/{TestID}-{Browser}-before.dom.html` — rendered DOM before the modification
- `ut-report/html/{TestID}-{Browser}-after.dom.html` — rendered DOM after the modification

The DOM change proves the rendered change (e.g. `Skip — start at N5` → `Skip — begin with N5`); the raw-source change proves the actual served code (for a Vite SPA the raw shell stays identical — that is expected).

If nothing changed, the after run records an `ERROR` for that browser/case, keeps processing the rest of the cases, then stops before report and workbook generation.

## Browser handling

Each browser leg uses the **same system-first launch logic with automatic fallback**:

| Leg | System browser (preferred) | Fallback (after `npm install` alone) |
|---|---|---|
| Chrome | Installed Google Chrome (`channel: 'chrome'`) | Playwright bundled Chromium |
| Edge | Installed Microsoft Edge (`channel: 'msedge'`) | Playwright bundled Chromium |
| Firefox | Installed Mozilla Firefox (`channel: 'moz-firefox'`, WebDriver BiDi) | Playwright bundled Firefox |

- If the system browser is missing or fails a launch smoke test, the runner prints a `WARNING:` and relaunches with the bundled build, so the full flow always works with only `npm install`.
- The engine actually used (browser name, version, system vs bundled) is recorded per case in `ut_report.json` (`Engine` field), in `ut_report.md`, and as a "Captured with ..." note under each case in the evidence workbooks.
- When the Edge leg falls back to bundled Chromium, window capture automatically targets the Chromium process (`chrome.exe`) so OS-window screenshots still work.
- To provision real Chrome/Edge via npm on machines where they are missing: `npm run setup:browsers` (opt-in; may trigger an OS installer/UAC prompt). Firefox must be installed normally to be picked up — otherwise the bundled build is used.
- Overlay boxes use the viewport size recorded at capture time (`ViewportBefore`/`ViewportAfter` in `ut_report.json`) instead of assuming 1440x900, so annotation positions stay accurate even when browsers round the window size differently.

Login fields are optional: if `LoginButtonSelector` matches, the runner logs in before capturing evidence.

## Navigation (config-driven, no blind search)

When a case has a `TargetScreen`, the runner resolves its URL from two knowledge
files — never by crawling or searching live:

1. **`nav-routes.json`** (preferred) — auto-generated from your project's source
   code via `npm run nav:generate`. See `nav-sources.json` for project paths.
2. **`ut-report/navigation-path.json`** — learned cache written automatically
   after successful runs.

If neither file has a matching route, the runner **throws an error immediately**
so you fix the route config instead of waiting for a blind crawl to fail.

Reuse strategy is selectable per case via `- NavReplay: auto|direct|replay`:

- `auto` *(default)* — direct jump first; if the target screen is not found,
  replay the recorded click steps from the start screen; fail ⇒ null.
- `direct` — direct jump only (fastest).
- `replay` — always follow the recorded button path from the start screen.

Every strategy dismisses cookie/consent modals along the way, matches saved
hrefs against percent-encoded/volatile-query URLs, and refuses to replay
destructive controls (ログアウト・削除・支払 etc.). See `NAVIGATION.md` for
the full architecture.

### Generating navigation routes

```bash
# 1. Edit nav-sources.json — add your project root(s) + baseUrl
# 2. Run the generator:
npm run nav:generate
# 3. Review and commit nav-routes.json (or add manual tweaks)
```

The generator scans JBoss/JSP, Struts, Next.js, Nuxt, Vue Router, React Router,
Java controller mappings, and more. Matched routes are scored against
`TargetScreen` fields in `ut_cases.md`.

## Notes

- Screenshots capture the real OS browser window (with tab bar and address bar) via `capture-window.ps1`; if window capture fails, it falls back to a full-page Playwright capture.
- The evidence screenshots are kept pristine — they are never modified. The changed area is annotated with a native, editable Excel rectangle shape (border `#C00000` RGB 192, 0, 0, ~5 px width, transparent fill, ~5 px padding) overlaid on each screenshot in the workbook.
- Overlay coordinates are computed by diffing the red channel of the clean screenshot against the temporary annotated capture, so they stay correct regardless of display scaling or browser chrome.
- Left column in each workbook = before / original, right column = after / modified.
- The runner fails gracefully if selectors or expected text change and writes the error details into the report and the workbook.
- Navigation routes are generated from source code, not discovered at runtime. If a screen is missing, add the project to `nav-sources.json` and re-run `npm run nav:generate`, or add the entry manually to `nav-routes.json`.
- `ExpectedResult` and `ManualStatus` fields appear in both the markdown report and the Excel workbook (under "期待結果 / Expected Result" and "ユーザー判定 / User Verdict" rows).
- `ManualStatus` never affects exit codes — it's a user annotation only.
