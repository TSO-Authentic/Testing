﻿const fs = require('fs');
const path = require('path');
const { spawn } = require('child_process');
const express = require('express');
const { loadNavCache, findRouteEntry, upsertRouteEntry, normalizeForMatch, loadRouteConfig, matchRouteEntry } = require('./nav-find');
const { classifyKeywordChange } = require('./keyword-diff');

const app = express();
const PORT = 3000;
const ROOT = __dirname;
const recordingControlsSupported = true;
const recordingState = { token: '', paused: false };
const CASE_FILE = path.join(ROOT, 'ut_cases.md');
const FEATURE_FILE = path.join(ROOT, 'test-feature.md');
const REPORT_DIR = path.join(ROOT, 'ut-report');
const NAV_PATH_FILE = path.join(REPORT_DIR, 'navigation-path.json');
const SCREENSHOT_DIR = path.join(REPORT_DIR, 'screenshots');

app.use(express.json());
app.use(express.static(path.join(ROOT, 'public')));

function sendSSE(res, text, type = 'info') {
  res.write(JSON.stringify({ text, type }) + '\n');
}

function parseCases(markdownText) {
  const cleaned = markdownText.replace(/<!--[\s\S]*?-->/g, '');
  const blocks = cleaned.split(/^##\s+/m).filter(Boolean);
  const cases = [];
  for (const block of blocks) {
    const lines = block.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const data = {};
    for (const line of lines) {
      if (line.includes(':')) {
        const norm = line.replace(/^-\s*/, '');
        const idx = norm.indexOf(':');
        const key = norm.slice(0, idx).trim();
        const val = norm.slice(idx + 1).trim();
        data[key] = val;
      }
    }
    if (data.TestID) cases.push(data);
  }
  return cases;
}

function getNextTestID() {
  let content = '';
  if (fs.existsSync(CASE_FILE)) {
    content = fs.readFileSync(CASE_FILE, 'utf8').replace(/<!--[\s\S]*?-->/g, '');
  }
  const matches = content.match(/- TestID:\s*(UT-[\w-]+)/g);
  if (!matches) return 'UT-001';
  const ids = matches.map(m => {
    const num = m.match(/UT-(\d+)/);
    return num ? parseInt(num[1], 10) : 0;
  });
  const max = Math.max(...ids);
  return `UT-${String(max + 1).padStart(3, '0')}`;
}

function buildCaseBlock(testId, data, existingCase = null) {
  const lines = [
    `## ${testId}`,
    `- TestID: ${testId}`,
    `- URL: ${data.url}`,
    `- BaseURL: ${data.baseUrl || data.url}`,
    `- LoginId: ${data.username || '(not applicable)'}`,
    `- Password: ${data.password || '(not applicable)'}`,
    `- LoginIdSelector: ${data.loginIdSelector || '-'}`,
    `- PasswordSelector: ${data.passwordSelector || '-'}`,
    `- LoginButtonSelector: ${data.loginButtonSelector || '-'}`,
    `- TargetScreen: ${data.targetScreen}`,
    `- Keyword: ${data.keyword}`,
  ];

  if (data.mode === 'before') {
    lines.push(`- BeforeText: ${data.keyword}`);
    if (data.partialText) {
      lines.push(`- PartialText: ${data.partialText}`);
    }
  } else if (data.mode === 'after') {
    const existingBeforeText = existingCase?.BeforeText || existingCase?.Keyword || '';
    const change = classifyKeywordChange(existingBeforeText, data.keyword);
    const manualPartial = data.partialText || existingCase?.PartialText || '';

    if (change.kind === 'identical') {
      // pure keyword-only mode: no BeforeText/AfterText lines
    } else if (manualPartial) {
      if (existingBeforeText) {
        lines.push(`- BeforeText: ${existingBeforeText}`);
      }
      lines.push(`- AfterText: ${data.keyword}`);
      lines.push(`- PartialText: ${manualPartial}`);
      const manualAfterPartial = data.afterPartialText || existingCase?.AfterPartialText || '';
      if (manualAfterPartial) {
        lines.push(`- AfterPartialText: ${manualAfterPartial}`);
      }
    } else if (change.kind === 'partial') {
      lines.push(`- PartialText: ${change.beforeFragment}`);
      lines.push(`- AfterPartialText: ${change.afterFragment}`);
    } else if (change.kind === 'entire') {
      if (existingBeforeText) {
        lines.push(`- BeforeText: ${existingBeforeText}`);
      }
      lines.push(`- AfterText: ${data.keyword}`);
    }
  }

  lines.push(`- Description: ${data.targetScreen} - ${data.keyword} verification`);

  if (data.navReplay === 'direct' || data.navReplay === 'replay') {
    lines.push(`- NavReplay: ${data.navReplay}`);
  }

  if (Array.isArray(data.browsers) && data.browsers.length) {
    lines.push(`- Browsers: ${data.browsers.join(', ')}`);
  }

  if (Array.isArray(data.elements) && data.elements.length) {
    // Compact single-line JSON — JSON.stringify never emits raw newlines,
    // so the md one-line-per-field invariant holds even with multiline values.
    lines.push(`- Elements: ${JSON.stringify(data.elements)}`);
  }

  lines.push(`- RedBox: ${data.redBox === undefined || data.redBox ? 'true' : 'false'}`);

  const afterFillAction = data.afterFillAction || (data.submitButtonSelector ? 'custom' : 'none');
  if (afterFillAction === 'none') {
    // no button click after form fill
  } else {
    lines.push(`- AfterFillAction: ${afterFillAction}`);
    const customSel = data.submitButtonSelector && data.submitButtonSelector !== '-'
      ? data.submitButtonSelector
      : (afterFillAction === 'cancel' ? 'Cancel' : 'Submit');
    lines.push(`- SubmitButtonSelector: ${customSel}`);
  }

  if (data.expectedResult) {
    lines.push(`- ExpectedResult: ${data.expectedResult}`);
  }

  const manualStatus = String(data.manualStatus || '').trim().toUpperCase();
  if (manualStatus === 'PASS' || manualStatus === 'FAIL') {
    lines.push(`- ManualStatus: ${manualStatus}`);
  }

  if (data.dangerousOk) {
    lines.push(`- DangerousOk: true`);
  }

  return lines.join('\n') + '\n';
}

function clearEvidence(testId) {
  const HTML_DIR = path.join(REPORT_DIR, 'html');
  const ARTIFACT_DIR = path.join(ROOT, 'artifacts');

  const patterns = [
    { dir: SCREENSHOT_DIR, glob: `${testId}-*.png` },
    { dir: HTML_DIR, glob: `${testId}-*` },
    { dir: ARTIFACT_DIR, glob: `${testId}-*-annotated.png` },
  ];

  let count = 0;
  for (const { dir, glob } of patterns) {
    if (!fs.existsSync(dir)) continue;
    const prefix = glob.split('*')[0];
    const suffix = glob.split('*').pop();
    const entries = fs.readdirSync(dir);
    for (const entry of entries) {
      if (entry.startsWith(prefix) && (suffix === '' || entry.endsWith(suffix))) {
        fs.unlinkSync(path.join(dir, entry));
        count++;
      }
    }
  }

  if (fs.existsSync(NAV_PATH_FILE)) {
    fs.unlinkSync(NAV_PATH_FILE);
    count++;
  }

  return count;
}

function hasBeforeEvidence(testId, browsers) {
  for (const browser of browsers) {
    const shotPath = path.join(SCREENSHOT_DIR, `${testId}-${browser}-before.png`);
    if (!fs.existsSync(shotPath)) return false;
  }
  return true;
}

function runNpmCommand(command, args, send) {
  return new Promise((resolve) => {
    const isWin = process.platform === 'win32';
    const proc = spawn(command, args, {
      cwd: ROOT,
      shell: isWin,
      env: { ...process.env, FORCE_COLOR: '0' },
    });

    let hasOutput = false;

    proc.stdout.on('data', (data) => {
      const text = data.toString().trim();
      if (text) {
        send(text);
        hasOutput = true;
      }
    });

    proc.stderr.on('data', (data) => {
      const text = data.toString().trim();
      if (text) {
        send(text, 'warn');
        hasOutput = true;
      }
    });

    proc.on('close', (code) => {
      if (code === 0) {
        send('Command completed successfully.', 'success');
      } else {
        send(`Command exited with code ${code}.`, code === 1 ? 'error' : 'warn');
      }
      resolve(code);
    });

    proc.on('error', (err) => {
      send(`Failed to start command: ${err.message}`, 'error');
      resolve(1);
    });
  });
}

async function tryRecordAutoLogin(page, username, password, send) {
  if (!username && !password) return;
  const usernameSelectors = [
    '#username', '#loginId', '#userId', '#email',
    'input[name="username"]', 'input[name="loginId"]', 'input[name="userId"]', 'input[name="email"]',
    'input[type="email"]', 'input[placeholder*="user" i]', 'input[placeholder*="id" i]',
  ];
  const passwordSelectors = [
    '#password', '#pass', '#passwd',
    'input[name="password"]', 'input[name="pass"]', 'input[name="passwd"]',
    'input[type="password"]',
  ];
  const loginButtonSelectors = [
    'button[type="submit"]', 'input[type="submit"]',
    'button:has-text("Login")', 'button:has-text("ログイン")',
    'button:has-text("Sign in")', 'button:has-text("Submit")',
    '#loginBtn', '#loginButton', '.login-btn', '.btn-login',
  ];

  let filled = false;
  if (username) {
    for (const sel of usernameSelectors) {
      try {
        const el = await page.$(sel);
        if (el && await el.isVisible()) {
          await el.fill(username);
          filled = true;
          send(`Filled username using ${sel}`);
          break;
        }
      } catch {}
    }
  }

  if (password) {
    for (const sel of passwordSelectors) {
      try {
        const el = await page.$(sel);
        if (el && await el.isVisible()) {
          await el.fill(password);
          filled = true;
          send(`Filled password using ${sel}`);
          break;
        }
      } catch {}
    }
  }

  if (filled) {
    for (const sel of loginButtonSelectors) {
      try {
        const el = await page.$(sel);
        if (el && await el.isVisible()) {
          await el.click();
          send(`Clicked login button using ${sel}`);
          await page.waitForTimeout(3000).catch(() => {});
          break;
        }
      } catch {}
    }
  }
}

app.post('/record-route', async (req, res) => {
  res.setHeader('Content-Type', 'application/x-ndjson');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const { url, username, password, targetScreen, keyword } = req.body;

  if (!url || !targetScreen) {
    sendSSE(res, 'ERROR: URL and Target Screen are required.', 'error');
    return res.end();
  }

  sendSSE(res, `Recording route to "${targetScreen}"...`);
  sendSSE(res, `URL: ${url}`);
  if (keyword) sendSSE(res, `Keyword: ${keyword}`);

  const token = Math.random().toString(36).slice(2) + Date.now().toString(36);
  recordingState.token = token;
  recordingState.paused = false;
  let browser;
  const serverSteps = [];

  const isNavigationError = (err) => {
    const msg = (err && err.message) || String(err || '');
    return /Execution context was destroyed|most likely because of a navigation|detached from its page|Cannot find context/i.test(msg);
  };

  const pushNavStep = async () => {
    let href = '';
    try { href = page.url(); } catch { /* page mid-navigation */ }
    serverSteps.push({ kind: 'nav', href, text: 'NAVIGATION (page changed)', tag: 'nav', index: -1, inMenu: false });
  };

  try {
    const { chromium } = require('playwright');
    browser = await chromium.launch({ headless: false });
    const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
    const page = await context.newPage();

    await page.exposeFunction('__pushRecordedStep', (step) => {
      if (!(recordingState.paused && recordingState.token === token)) {
        serverSteps.push(step);
      }
    });

    await page.addInitScript(() => {
      window.__recordingSteps = [];
      document.addEventListener('click', function(e) {
        const el = e.target.closest('a[href], button:not([disabled]), [role="link"], [role="button"]');
        if (!el) return;
        const tag = el.tagName.toLowerCase();
        const anchor = el.closest('a');
        const href = (anchor && anchor.href) || el.getAttribute('data-href') || '';
        const rawText = (el.textContent || el.value || '').trim();
        const text = rawText.replace(/\s+/g, ' ').substring(0, 60);
        const parent = el.parentElement;
        const siblings = parent ? Array.from(parent.children).filter(c => c.tagName === el.tagName) : [];
        const index = siblings.indexOf(el);
        const inMenu = !!el.closest('[role="navigation"], nav, .menu, .nav, #menu, #nav, .sidebar, header');
        const step = { kind: 'click', href, text, tag, index, inMenu };
        window.__recordingSteps.push(step);
        if (typeof window.__pushRecordedStep === 'function') {
          window.__pushRecordedStep(step);
        }
      }, true);
    });

    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
    await page.waitForTimeout(2000).catch(() => {});

    await tryRecordAutoLogin(page, username, password, sendSSE);

    sendSSE(res, '');
    sendSSE(res, '--- Browser opened. Click through to the target screen. ---');
    sendSSE(res, `Recording... (stops when heading matches "${targetScreen}"${keyword ? ` + body contains "${keyword}"` : ''})`);
    sendSSE(res, '');
    if (recordingControlsSupported) {
      sendSSE(res, 'Pause/Resume via the console buttons. Navigation during recording is captured and recording continues.', 'info');
    }

    const startTime = Date.now();
    const timeout = 120000;
    let detected = false;
    let lastPausedNote = { paused: null, at: 0 };

    while (Date.now() - startTime < timeout) {
      try {
        await page.waitForTimeout(1500);
      } catch {
        sendSSE(res, 'Browser was closed — stopping recording.', 'warn');
        break;
      }

      if (recordingState.paused && recordingState.token === token) {
        if (lastPausedNote.paused !== true || Date.now() - lastPausedNote.at > 10000) {
          sendSSE(res, '  (paused) detection and click recording are frozen — resume when ready.', 'warn');
          lastPausedNote = { paused: true, at: Date.now() };
        }
        continue;
      }
      if (lastPausedNote.paused === true && !recordingState.paused) {
        sendSSE(res, `  (resumed) ${serverSteps.length} step(s) captured so far.`, 'success');
      }
      lastPausedNote = { paused: recordingState.paused, at: Date.now() };

      let heading = '';
      let bodyText = '';
      let navDuringPoll = false;

      try {
        heading = await page.evaluate(() => {
          return Array.from(document.querySelectorAll('h1, h2, h3'))
            .map(e => e.textContent.trim()).join(' ');
        });
      } catch (err) {
        if (isNavigationError(err)) {
          navDuringPoll = true;
          await pushNavStep();
          sendSSE(res, `  Navigation detected during capture (${(err.message || '').split('\n')[0]}) — continuing...`, 'warn');
        } else {
          throw err;
        }
      }

      if (!navDuringPoll) {
        try {
          bodyText = await page.evaluate(() => (document.body?.innerText || '').substring(0, 50000));
        } catch (err) {
          if (isNavigationError(err)) {
            navDuringPoll = true;
            await pushNavStep();
            sendSSE(res, `  Navigation detected during capture (${(err.message || '').split('\n')[0]}) — continuing...`, 'warn');
          } else {
            throw err;
          }
        }
      }

      if (heading) {
        const screenMatch = heading.toLowerCase().includes(targetScreen.toLowerCase());
        const keywordMatch = !keyword || bodyText.toLowerCase().includes(keyword.toLowerCase());
        if (screenMatch && keywordMatch) {
          detected = true;
          sendSSE(res, `Target screen "${targetScreen}" detected!`, 'success');
          break;
        }
      }
    }

    let steps = serverSteps.slice();
    try {
      const pageSteps = await page.evaluate(() => window.__recordingSteps || []);
      for (const s of pageSteps) {
        if (!steps.some(existing => existing.text === s.text && existing.href === s.href && existing.kind === s.kind)) {
          steps.push(s);
        }
      }
    } catch (err) {
      if (!isNavigationError(err)) throw err;
    }

    if (steps.length === 0) {
      sendSSE(res, 'WARNING: No clicks were recorded. The browser may not have been interacted with.', 'warn');
    }

    if (detected || steps.length > 0) {
      if (!detected && steps.length > 0) {
        sendSSE(res, 'WARNING: Target screen was never detected within the time limit — route saved to your last position anyway. Verify it before relying on it.', 'warn');
      }
      const entry = {
        project: 'browser-recording',
        domain: (() => { try { return new URL(url).hostname; } catch { return ''; } })(),
        targetScreen,
        normalizedScreen: normalizeForMatch(targetScreen),
        keyword: keyword || '',
        startUrl: url,
        directUrl: page.url(),
        routePath: (() => { try { return new URL(page.url()).pathname; } catch { return ''; } })(),
        steps,
        inMenu: steps.some(s => s.inMenu),
        source: 'browser-recorded',
        extractedKind: 'recorded',
        score: 100,
        generatedAt: new Date().toISOString(),
        recorded: true,
      };
      upsertRouteEntry(ROOT, entry);
      sendSSE(res, `Route saved to nav-routes.json`, 'success');
      res.write(JSON.stringify({ type: 'recorded-steps', found: true, source: 'recorded', targetScreen, startUrl: url, directUrl: entry.directUrl, steps }) + '\n');
      sendSSE(res, '');
      sendSSE(res, '--- Recorded Steps ---');
      for (let i = 0; i < steps.length; i++) {
        const s = steps[i];
        sendSSE(res, `  Step ${i + 1}: click "${s.text}" (${s.tag}) → ${s.href}`);
      }
      sendSSE(res, '');
      sendSSE(res, `Direct URL: ${entry.directUrl}`);
    } else {
      sendSSE(res, 'ERROR: No steps recorded and target screen not detected. Nothing saved.', 'error');
    }

    await browser.close();
    sendSSE(res, 'Recording complete.', 'success');
  } catch (err) {
    sendSSE(res, `ERROR: ${err.message}`, 'error');
    if (browser) await browser.close().catch(() => {});
  }

  res.end();
});

app.post('/record-control', (req, res) => {
  const { action } = req.body || {};
  if (action === 'pause') {
    recordingState.paused = true;
  } else if (action === 'resume') {
    recordingState.paused = false;
  }
  res.json({ ok: true, paused: recordingState.paused });
});

app.post('/run', async (req, res) => {
  res.setHeader('Content-Type', 'application/x-ndjson');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  const data = req.body;
  const action = data.action || 'replace';
  const mode = data.mode || 'before';
  const browsers = data.browsers || ['Chrome'];

  sendSSE(res, `Mode: ${mode === 'before' ? '修正前画面 (Before)' : '修正後画面 (After)'}`);
  sendSSE(res, `Browsers: ${browsers.join(', ')}`);
  sendSSE(res, `Action: ${action === 'add' ? 'Add New Case' : 'Replace Existing'}`);

  try {
    data.baseUrl = data.url;
    let targetUrl = data.url;

    if (data.targetScreen) {
      sendSSE(res, `\n--- Target Screen Navigation ---`);
      const routed = findRouteEntry(ROOT, data.targetScreen);
      const cached = loadNavCache(REPORT_DIR, data.targetScreen, (msg, type) => sendSSE(res, msg, type));
      const previewUrl = (routed && (routed.directUrl || routed.foundUrl)) || (cached && cached.foundUrl) || '';
      if (previewUrl) {
        targetUrl = previewUrl;
        data.url = previewUrl;
        sendSSE(res, `Target screen URL: ${previewUrl}${routed ? ' (generated route)' : ''}`, 'success');
      } else {
        sendSSE(res, `No navigation route for "${data.targetScreen}" — the case will ERROR unless nav-routes.json or saved history provides one. Run: npm run nav:generate`, 'warn');
      }
    }

    const testId = syncCaseToMd(data.testId || null, data, action);

    const cases = readTestCases();
    const jsonIdx = cases.findIndex(c => c.id === testId);
    const jsonCase = {
      id: testId,
      targetScreen: data.targetScreen || '',
      keyword: data.keyword || '',
      url: data.url || '',
      username: data.username || '',
      password: data.password || '',
      loginIdSelector: data.loginIdSelector || '',
      passwordSelector: data.passwordSelector || '',
      loginButtonSelector: data.loginButtonSelector || '',
      afterFillAction: data.afterFillAction || '',
      submitButtonSelector: data.submitButtonSelector || '',
      mode: data.mode || 'before',
      navReplay: data.navReplay || 'auto',
      expectedResult: data.expectedResult || '',
      manualStatus: data.manualStatus || '',
      dangerousOk: !!data.dangerousOk,
      redBox: data.redBox === undefined ? true : !!data.redBox,
      partialTextEnabled: !!data.partialText,
      partialText: data.partialText || '',
      browsers: data.browsers || ['Chrome'],
      elements: data.elements || [],
    };
    if (jsonIdx >= 0) {
      cases[jsonIdx] = { ...cases[jsonIdx], ...jsonCase };
    } else {
      cases.push(jsonCase);
    }
    writeTestCases(cases);

    syncFeatureDoc();
    sendSSE(res, `Case ${testId} written to ut_cases.md`, 'success');

    if (mode === 'after') {
      if (!hasBeforeEvidence(testId, browsers)) {
        sendSSE(res, `ERROR: Before evidence not found for ${testId}. Run 修正前画面 (Before) first.`, 'error');
        res.end();
        return;
      }
      sendSSE(res, `Before evidence verified on disk.`, 'success');
    }

    const browsersArg = browsers.join(',');

    if (mode === 'before') {
      sendSSE(res, `\n--- Running node run-ut.js before (${browsersArg}) ---`);
      await runNpmCommand('node', ['run-ut.js', 'before', '--browsers', browsersArg, '--case', testId], (msg, type) => sendSSE(res, msg, type));
      sendSSE(res, `\nDone. Modify your code, then come back and run 修正後画面 (After).`, 'success');
    } else {
      sendSSE(res, `\n--- Running node run-ut.js after (${browsersArg}) ---`);
      await runNpmCommand('node', ['run-ut.js', 'after', '--browsers', browsersArg, '--case', testId], (msg, type) => sendSSE(res, msg, type));
      sendSSE(res, `\n--- Generating Excel evidence ---`);
      await runNpmCommand('python', ['generate_evidence.py'], (msg, type) => sendSSE(res, msg, type));
      const cleared = clearEvidence(testId);
      sendSSE(res, `Evidence cleared for ${testId} (${cleared} files removed). Ready for next action.`, 'success');
      sendSSE(res, `\nDone. Evidence captured and Excel workbooks generated.`, 'success');
    }
  } catch (err) {
    sendSSE(res, `ERROR: ${err.message}`, 'error');
  }

  res.end();
});

// ─── CRUD API for test-cases.json ────────────────────────────────────────────

const TEST_CASES_FILE = path.join(ROOT, 'test-cases.json');

function readTestCases() {
  if (!fs.existsSync(TEST_CASES_FILE)) return [];
  try {
    return JSON.parse(fs.readFileSync(TEST_CASES_FILE, 'utf8'));
  } catch {
    return [];
  }
}

function writeTestCases(cases) {
  fs.writeFileSync(TEST_CASES_FILE, JSON.stringify(cases, null, 2), 'utf8');
}

// Regenerate the auto-managed case table inside test-feature.md. The section
// between the CASES:AUTO markers is machine-owned; everything around it stays
// hand-editable.
function syncFeatureDoc() {
  if (!fs.existsSync(FEATURE_FILE)) return;
  try {
    const cases = readTestCases();
    const cell = v => String(v === undefined || v === null ? '' : v)
      .replace(/\|/g, '\\|')
      .replace(/\r?\n/g, ' ');
    const detail = e => (!e || !String(e.label || '').trim())
      ? '⚠ no label — skipped by runner'
      : `${e.type || 'text'} · ${cell(e.label)} · ${cell(e.value)}`;
    const rows = [];
    for (const c of cases) {
      const els = Array.isArray(c.elements) ? c.elements.filter(Boolean) : [];
      const brs = Array.isArray(c.browsers) && c.browsers.length ? c.browsers.join(', ') : 'Chrome';
      const base = `| ${c.id} | ${cell(c.targetScreen)} | ${cell(c.keyword)} | ${c.navReplay || 'auto'} | ${brs} | ${els.length} |`;
      if (!els.length) {
        rows.push(base + ' — |');
      } else {
        els.forEach((e, i) => {
          rows.push(`${i === 0 ? base : '| | | | | | |'} ${detail(e)} |`);
        });
      }
    }
    const section = [
      '<!-- CASES:AUTO -->',
      '## Current Test Cases (auto-generated)',
      '',
      'Regenerated automatically whenever cases are created, updated or deleted through the UI/API. Each form element gets its own detail row.',
      '',
      '| ID | Target Screen | Keyword | NavReplay | Browsers | # | Element Details |',
      '|----|---------------|---------|-----------|----------|---|-----------------|',
      ...rows,
      '<!-- /CASES:AUTO -->',
    ].join('\n');
    let doc = fs.readFileSync(FEATURE_FILE, 'utf8');
    const markerRe = /<!-- CASES:AUTO -->[\s\S]*?<!-- \/CASES:AUTO -->/;
    if (markerRe.test(doc)) {
      doc = doc.replace(markerRe, section);
    } else {
      doc = doc.trimEnd() + '\n\n' + section + '\n';
    }
    fs.writeFileSync(FEATURE_FILE, doc, 'utf8');
  } catch (err) {
    console.error(`WARNING: could not sync ${path.basename(FEATURE_FILE)}: ${err.message}`);
  }
}

function getNextTestCaseID(cases) {
  if (cases.length === 0) return 'UT-001';
  const ids = cases.map(c => {
    const m = c.id && c.id.match(/UT-(\d+)/);
    return m ? parseInt(m[1], 10) : 0;
  });
  const max = Math.max(...ids);
  return `UT-${String(max + 1).padStart(3, '0')}`;
}

// Scan BOTH test-cases.json and ut_cases.md so a freshly generated ID can
// never collide with an ID that already exists in either store.
function nextCaseID() {
  let max = 0;
  for (const c of readTestCases()) {
    const m = c.id && String(c.id).match(/UT-(\d+)/);
    if (m) max = Math.max(max, parseInt(m[1], 10));
  }
  if (fs.existsSync(CASE_FILE)) {
    const content = fs.readFileSync(CASE_FILE, 'utf8').replace(/<!--[\s\S]*?-->/g, '');
    for (const m of content.matchAll(/- TestID:\s*UT-(\d+)/g)) {
      max = Math.max(max, parseInt(m[1], 10));
    }
  }
  return `UT-${String(max + 1).padStart(3, '0')}`;
}

function syncCaseToMd(testId, data, action) {
  // Upsert semantics for every action: if a block with this TestID already
  // exists it is replaced in place; only truly new IDs are appended.
  void action;
  const content = fs.existsSync(CASE_FILE) ? fs.readFileSync(CASE_FILE, 'utf8') : '';
  const cleaned = content.replace(/<!--[\s\S]*?-->/g, '');
  const blocks = cleaned.split(/^(?=## )/m).filter(b => b.trim());

  const idx = blocks.findIndex(b => b.includes(`- TestID: ${testId}`));
  if (idx === -1) {
    const id = testId || getNextTestID();
    const block = buildCaseBlock(id, data, null);
    const separator = cleaned.trimEnd() ? '\n\n' : '';
    fs.writeFileSync(CASE_FILE, cleaned.trimEnd() + separator + block, 'utf8');
    return id;
  }

  const existingCases = parseCases(blocks[idx]);
  const existingCase = existingCases[0] || null;
  blocks[idx] = buildCaseBlock(testId, data, existingCase);
  fs.writeFileSync(CASE_FILE, blocks.join('\n'), 'utf8');
  return testId;
}

function removeCaseFromMd(testId) {
  const content = fs.existsSync(CASE_FILE) ? fs.readFileSync(CASE_FILE, 'utf8') : '';
  const cleaned = content.replace(/<!--[\s\S]*?-->/g, '');
  const blocks = cleaned.split(/^(?=## )/m).filter(b => b.trim());
  const filtered = blocks.filter(b => !b.includes(`- TestID: ${testId}`));
  if (filtered.length === blocks.length) return 0;
  fs.writeFileSync(CASE_FILE, filtered.join('\n'), 'utf8');
  return 1;
}

app.get('/api/cases', (req, res) => {
  res.json(readTestCases());
});

app.get('/api/cases/:id', (req, res) => {
  const cases = readTestCases();
  const found = cases.find(c => c.id === req.params.id);
  if (!found) return res.status(404).json({ error: 'Case not found' });
  res.json(found);
});

app.post('/api/cases', (req, res) => {
  const cases = readTestCases();
  const newCase = {
    id: nextCaseID(),
    targetScreen: req.body.targetScreen || '',
    keyword: req.body.keyword || '',
    url: req.body.url || '',
    username: req.body.username || '',
    password: req.body.password || '',
    loginIdSelector: req.body.loginIdSelector || '',
    passwordSelector: req.body.passwordSelector || '',
    loginButtonSelector: req.body.loginButtonSelector || '',
    afterFillAction: req.body.afterFillAction || '',
    submitButtonSelector: req.body.submitButtonSelector || '',
    mode: req.body.mode || 'before',
    navReplay: req.body.navReplay || 'auto',
    expectedResult: req.body.expectedResult || '',
    manualStatus: req.body.manualStatus || '',
    dangerousOk: !!req.body.dangerousOk,
    redBox: req.body.redBox === undefined ? true : !!req.body.redBox,
    partialTextEnabled: !!req.body.partialTextEnabled,
    partialText: req.body.partialText || '',
    browsers: req.body.browsers || ['Chrome'],
    elements: req.body.elements || [],
  };
  cases.push(newCase);
  writeTestCases(cases);
  syncCaseToMd(newCase.id, req.body, 'add');
  syncFeatureDoc();
  res.status(201).json(newCase);
});

app.put('/api/cases/:id', (req, res) => {
  const cases = readTestCases();
  const idx = cases.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Case not found' });
  const old = cases[idx];
  cases[idx] = {
    ...old,
    targetScreen: req.body.targetScreen ?? old.targetScreen,
    keyword: req.body.keyword ?? old.keyword,
    url: req.body.url ?? old.url,
    username: req.body.username ?? old.username,
    password: req.body.password ?? old.password,
    loginIdSelector: req.body.loginIdSelector ?? old.loginIdSelector,
    passwordSelector: req.body.passwordSelector ?? old.passwordSelector,
    loginButtonSelector: req.body.loginButtonSelector ?? old.loginButtonSelector,
    afterFillAction: req.body.afterFillAction ?? old.afterFillAction,
    submitButtonSelector: req.body.submitButtonSelector ?? old.submitButtonSelector,
    mode: req.body.mode ?? old.mode,
    navReplay: req.body.navReplay ?? old.navReplay,
    expectedResult: req.body.expectedResult ?? old.expectedResult,
    manualStatus: req.body.manualStatus ?? old.manualStatus,
    dangerousOk: req.body.dangerousOk ?? old.dangerousOk,
    redBox: req.body.redBox ?? old.redBox,
    partialTextEnabled: req.body.partialTextEnabled ?? old.partialTextEnabled,
    partialText: req.body.partialText ?? old.partialText,
    browsers: req.body.browsers ?? old.browsers,
    elements: req.body.elements ?? old.elements,
  };
  writeTestCases(cases);
  syncCaseToMd(old.id, req.body, 'replace');
  syncFeatureDoc();
  res.json(cases[idx]);
});

app.delete('/api/cases/:id', (req, res) => {
  let cases = readTestCases();
  const idx = cases.findIndex(c => c.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Case not found' });
  const removed = cases.splice(idx, 1)[0];
  writeTestCases(cases);
  removeCaseFromMd(removed.id);
  syncFeatureDoc();
  res.json({ deleted: removed.id });
});

app.get('/api/route-steps', (req, res) => {
  const screen = String(req.query.screen || '').trim();
  if (!screen) return res.status(400).json({ error: 'screen query parameter required' });
  let matches = [];
  try {
    const config = loadRouteConfig(ROOT);
    matches = ((config && config.routes) || [])
      .map(entry => ({ entry, score: matchRouteEntry(entry, screen) }))
      .filter(x => x.score > 0)
      .sort((a, b) => b.score - a.score);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
  // Priority: recorded routes are ground truth; fall back to generated-from-src.
  const pick = matches.find(x => x.entry.recorded) || matches[0];
  if (!pick) return res.json({ found: false, source: null, targetScreen: screen, directUrl: '', startUrl: '', steps: [] });
  const { entry } = pick;
  res.json({
    found: true,
    source: entry.recorded ? 'recorded' : 'generated',
    targetScreen: entry.targetScreen,
    directUrl: entry.directUrl || '',
    startUrl: entry.startUrl || '',
    steps: (entry.steps || []).map(s => ({
      text: s.text || '',
      tag: s.tag || '',
      href: s.href || '',
      index: typeof s.index === 'number' ? s.index : -1,
    })),
  });
});

app.get('/api/routes', (req, res) => {
  const navFile = path.join(ROOT, 'nav-routes.json');
  if (!fs.existsSync(navFile)) return res.json([]);
  try {
    const data = JSON.parse(fs.readFileSync(navFile, 'utf8'));
    const screens = (data.routes || []).map(r => ({
      targetScreen: r.targetScreen,
      directUrl: r.directUrl || '',
      keyword: r.keyword || '',
    }));
    res.json(screens);
  } catch {
    res.json([]);
  }
});

app.listen(PORT, () => {
  console.log(`\nUT Browser Screen Evidence Tool`);
  console.log(`Open http://localhost:${PORT} in your browser\n`);
});
