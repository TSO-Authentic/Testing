const fs = require('fs');
const path = require('path');
const { execFile } = require('child_process');
const { promisify } = require('util');
const { chromium, firefox, webkit } = require('playwright');
const Diff = require('diff');
const { loadNavCache, resolveRouteConfig, resolveFromCache, normalizeUrlKey } = require('./nav-find');

const execFileAsync = promisify(execFile);

const ROOT = __dirname;
const CASE_FILE = path.join(ROOT, 'ut_cases.md');
const REPORT_DIR = path.join(ROOT, 'ut-report');
const SCREENSHOT_DIR = path.join(REPORT_DIR, 'screenshots');
const HTML_DIR = path.join(REPORT_DIR, 'html');
const ARTIFACT_DIR = path.join(ROOT, 'artifacts');
const WINDOW_CAPTURE_SCRIPT = path.join(ROOT, 'capture-window.ps1');
const ANNOTATION_COLOR = 'rgb(192, 0, 0)';
const BROWSERS = ['Chrome', 'Edge', 'Firefox'];
const windowCaptureWarned = new Set();

async function waitForPageSettled(page) {
  for (let attempt = 0; attempt < 8; attempt++) {
    try {
      const ready = await page.evaluate(() => document.readyState);
      if (ready === 'complete') return;
    } catch { /* navigation in flight — retry */ }
    await page.waitForTimeout(500).catch(() => {});
  }
}

async function capturePageDom(page) {
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      return await page.content();
    } catch { /* page navigating — retry */ }
    await waitForPageSettled(page);
  }
  return page.content();
}

async function capturePageText(page) {
  for (let attempt = 0; attempt < 5; attempt++) {
    try {
      return await page.evaluate(() => document.body.innerText);
    } catch { /* page navigating — retry */ }
    await waitForPageSettled(page);
  }
  return page.evaluate(() => document.body.innerText);
}

function parseCases(markdownText) {
  const cleaned = markdownText.replace(/<!--[\s\S]*?-->/g, '');
  const blocks = cleaned.split(/^##\s+/m).filter(Boolean);
  const cases = [];

  for (const block of blocks) {
    const lines = block.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
    const caseData = {};

    for (const line of lines) {
      if (line.includes(':')) {
        const normalizedLine = line.replace(/^-\s*/, '');
        const idx = normalizedLine.indexOf(':');
        const key = normalizedLine.slice(0, idx).trim();
        const value = normalizedLine.slice(idx + 1).trim();
        caseData[key] = value;
      }
    }

    if (caseData.TestID) {
      cases.push(caseData);
    }
  }

  return cases;
}

function normalizeManualStatus(value) {
  const v = String(value || '').trim().toUpperCase();
  return (v === 'PASS' || v === 'FAIL') ? v : '';
}

function getBrowserType(name) {
  const map = {
    chrome: chromium,
    edge: chromium,
    firefox,
    webkit,
    chromium,
  };

  const browserName = (name || 'chromium').toLowerCase();
  const selected = map[browserName];
  if (!selected) {
    throw new Error(`Unsupported browser: ${name}. Supported: Chrome, Edge, Firefox, chromium, webkit`);
  }
  return selected;
}

const ENGINE_INFO = {};

function getChannel(name) {
  const map = {
    chrome: 'chrome',
    edge: 'msedge',
    firefox: 'moz-firefox',
  };
  return map[(name || '').toLowerCase()];
}

async function smokeTestBrowser(browser) {
  const context = await browser.newContext();
  try {
    const page = await context.newPage();
    await page.goto('about:blank', { timeout: 15000 });
    if ((await page.evaluate(() => 1 + 1)) !== 2) {
      throw new Error('evaluate smoke check returned an unexpected value');
    }
    await page.content();
    await page.close();
  } finally {
    await context.close().catch(() => {});
  }
}

async function launchRealBrowser(name) {
  const browserType = getBrowserType(name);
  const channel = getChannel(name);
  if (channel) {
    let browser = null;
    try {
      browser = await browserType.launch({ headless: false, channel });
      await smokeTestBrowser(browser);
      ENGINE_INFO[name] = { label: `${name} ${browser.version()} (system ${channel})`, bundled: false };
      return browser;
    } catch (error) {
      if (browser) {
        await browser.close().catch(() => {});
      }
      console.warn(`WARNING: system ${name} (${channel}) unavailable (${(error.message || String(error)).split('\n')[0]}); falling back to the Playwright bundled build.`);
    }
  }
  const browser = await browserType.launch({ headless: false });
  ENGINE_INFO[name] = { label: `${name} ${browser.version()} (Playwright bundled build)`, bundled: true };
  return browser;
}

function ensureDirs() {
  fs.mkdirSync(REPORT_DIR, { recursive: true });
  fs.mkdirSync(SCREENSHOT_DIR, { recursive: true });
  fs.mkdirSync(HTML_DIR, { recursive: true });
  fs.mkdirSync(ARTIFACT_DIR, { recursive: true });
}

async function hasText(page, text) {
  const content = await page.locator('body').textContent();
  return (content || '').includes(text);
}

function computeDiff(before, after, context = 2) {
  const changes = Diff.diffLines(before, after);
  const hasChanges = changes.some(c => c.added || c.removed);
  if (!hasChanges) {
    return { changed: false, unified: 'No differences found.' };
  }
  const unified = Diff.createPatch('file', before, after, '', '', { context });
  return { changed: true, unified };
}

function findElementByText(page, text) {
  return page.evaluate(async ({ text, annotationColor }) => {
    const stabilizeAfterScroll = async (node) => {
      node.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
      let prevKey = null;
      for (let i = 0; i < 12; i++) {
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        const rect = node.getBoundingClientRect();
        const key = `${rect.x},${rect.y},${rect.width},${rect.height}`;
        if (key === prevKey) break;
        prevKey = key;
      }
    };

    const find = () => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.trim()) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      let node = walker.nextNode();
      while (node) {
        if (node.parentElement && node.parentElement.textContent.trim() === text.trim()) {
          return node.parentElement;
        }
        node = walker.nextNode();
      }

      const all = Array.from(document.querySelectorAll('body *'));
      const exact = all.find(e => e.childNodes.length && e.textContent.trim() === text.trim());
      if (exact) {
        return exact;
      }

      const needle = text.trim();
      const isWordChar = (ch) => !!ch && /[A-Za-z0-9_\u3005\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/.test(ch);

      const wholeWordIncludes = (haystack, frag) => {
        let idx = haystack.indexOf(frag);
        while (idx !== -1) {
          const before = idx > 0 ? haystack[idx - 1] : '';
          const after = idx + frag.length < haystack.length ? haystack[idx + frag.length] : '';
          if (!isWordChar(before) && !isWordChar(after)) {
            return true;
          }
          idx = haystack.indexOf(frag, idx + 1);
        }
        return false;
      };

      const needsBoundary = /^[A-Za-z0-9]+$/.test(needle);
      const containers = all.filter(e =>
        e.childNodes.length &&
        (needsBoundary ? wholeWordIncludes(e.textContent.trim(), needle) : e.textContent.trim().includes(needle))
      );
      if (!containers.length) {
        return null;
      }
      return containers.reduce((best, e) => (!best || e.textContent.length < best.textContent.length ? e : best));
    };

    const spanBoxOf = (root, fragment) => {
      if (!fragment) {
        return null;
      }

      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.length) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      const nodes = [];
      let full = '';
      let node = walker.nextNode();
      while (node) {
        nodes.push({ node, offset: full.length });
        full += node.nodeValue;
        node = walker.nextNode();
      }

      const idx = full.indexOf(fragment);
      if (idx === -1) {
        return null;
      }

      const locate = (pos) => {
        for (let i = nodes.length - 1; i >= 0; i--) {
          if (pos >= nodes[i].offset) {
            return { node: nodes[i].node, offset: pos - nodes[i].offset };
          }
        }
        return null;
      };

      const startPos = locate(idx);
      const lastPos = locate(idx + fragment.length - 1);
      if (!startPos || !lastPos) {
        return null;
      }

      try {
        const range = document.createRange();
        range.setStart(startPos.node, startPos.offset);
        range.setEnd(lastPos.node, lastPos.offset + 1);
        const rect = range.getBoundingClientRect();
        if (!rect || rect.width <= 0 || rect.height <= 0) {
          return null;
        }
        return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
      } catch (_) {
        return null;
      }
    };

    const drawOverlay = (box) => {
      const existing = document.getElementById('ut-position-highlight');
      if (existing) {
        existing.remove();
      }
      const div = document.createElement('div');
      div.id = 'ut-position-highlight';
      div.style.position = 'fixed';
      div.style.left = `${box.x}px`;
      div.style.top = `${box.y}px`;
      div.style.width = `${box.width}px`;
      div.style.height = `${box.height}px`;
      div.style.boxShadow = `0 0 0 3px ${annotationColor}`;
      div.style.pointerEvents = 'none';
      div.style.zIndex = '2147483647';
      document.documentElement.appendChild(div);
    };

    const el = find();
    if (!el) {
      return false;
    }

    await stabilizeAfterScroll(el);

    const spanBox = spanBoxOf(el, text.trim());
    if (spanBox) {
      drawOverlay(spanBox);
      return spanBox;
    }

    el.setAttribute('data-ut-highlight', 'true');
    el.style.boxShadow = `0 0 0 3px ${annotationColor}`;
    const rect = el.getBoundingClientRect();
    return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
  }, { text, annotationColor: ANNOTATION_COLOR });
}

function findElementTarget(page, text, options = {}) {
  return page.evaluate(async ({ text, partial, sliceStart, sliceEnd, keyword }) => {
    const rectToBox = (rect) => ({
      x: rect.x,
      y: rect.y,
      width: rect.width,
      height: rect.height,
    });

    const stabilizeAfterScroll = async (node) => {
      node.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
      let prevKey = null;
      for (let i = 0; i < 12; i++) {
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        const rect = node.getBoundingClientRect();
        const key = `${rect.x},${rect.y},${rect.width},${rect.height}`;
        if (key === prevKey) break;
        prevKey = key;
      }
    };

    const elementPath = (el) => {
      const path = [];
      let node = el;
      while (node && node !== document.body) {
        const parent = node.parentElement;
        if (!parent) {
          break;
        }
        path.unshift(Array.from(parent.children).indexOf(node));
        node = parent;
      }
      return path;
    };

    const elementFromPath = (path) => {
      let node = document.body;
      for (const index of path) {
        if (!node || !node.children || !node.children[index]) {
          return null;
        }
        node = node.children[index];
      }
      return node;
    };

    const WHOLE_SELECTORS = [
      'button', 'a', '[role="button"]', 'input', 'select', 'textarea', 'label',
      'li', 'tr', '[data-testid]', '[data-annotation-id]', '[data-ut-target]',
    ].join(', ');

    const nearestWholeElement = (el) => (
      el.closest(WHOLE_SELECTORS) || el
    );

    const cssEscape = (value) => (
      window.CSS && typeof window.CSS.escape === 'function'
        ? window.CSS.escape(value)
        : value.replace(/["\\]/g, '\\$&')
    );

    const stableIdOf = (el) => {
      if (el.id) return `#${cssEscape(el.id)}`;
      if (el.dataset && el.dataset.annotationId) return `[data-annotation-id="${cssEscape(el.dataset.annotationId)}"]`;
      if (el.dataset && el.dataset.testid) return `[data-testid="${cssEscape(el.dataset.testid)}"]`;
      return null;
    };

    const stableSelectorOf = (el) => {
      const stableId = stableIdOf(el);
      if (stableId) {
        return stableId;
      }

      const parts = [];
      let node = el;
      while (node && node !== document.body) {
        const parent = node.parentElement;
        if (!parent) {
          break;
        }

        const tag = node.tagName.toLowerCase();
        const sameTagSiblings = Array.from(parent.children).filter(child => child.tagName === node.tagName);
        const index = sameTagSiblings.indexOf(node) + 1;
        const selector = sameTagSiblings.length > 1 ? `${tag}:nth-of-type(${index})` : tag;
        parts.unshift(selector);
        node = parent;
      }

      return `body > ${parts.join(' > ')}`;
    };

    const findAllExact = () => {
      const found = [];
      const seen = new Set();
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.trim()) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      let node = walker.nextNode();
      while (node) {
        const parent = node.parentElement;
        if (parent && parent.textContent.trim() === text.trim() && !seen.has(parent)) {
          seen.add(parent);
          found.push(parent);
        }
        node = walker.nextNode();
      }

      for (const el of Array.from(document.querySelectorAll('body *'))) {
        if (!seen.has(el) && el.childNodes.length && el.textContent.trim() === text.trim()) {
          found.push(el);
        }
      }

      return found;
    };

    // A candidate is only usable when it actually renders: hidden duplicates
    // (e.g. display:none SP/mobile menus) produce 0x0 boxes and must not win.
    const renderedBoxOf = (candidate) => {
      const whole = nearestWholeElement(candidate);
      const rect = whole.getBoundingClientRect();
      if (rect && rect.width > 0 && rect.height > 0 && whole.getClientRects().length > 0) {
        return rectToBox(rect);
      }
      return null;
    };

    const collectPartialCandidates = (needle) => {
      const found = [];
      const seen = new Set();
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.length) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      let node = walker.nextNode();
      while (node) {
        const parent = node.parentElement;
        if (parent && parent.textContent.includes(needle) && !seen.has(parent)) {
          seen.add(parent);
          found.push(parent);
        }
        node = walker.nextNode();
      }

      if (!found.length) {
        for (const el of Array.from(document.querySelectorAll('body *'))) {
          if (el.childNodes.length && el.textContent.includes(needle)) {
            found.push(el);
          }
        }
      }

      return found;
    };

    const pickSmallestWithHint = (pool) => {
      const smallest = (list) => list.reduce((best, el) => (!best || el.textContent.length < best.textContent.length ? el : best), null);
      const hint = (keyword || '').trim().toLowerCase();
      if (hint) {
        const withHint = pool.filter(el => el.textContent.toLowerCase().includes(hint));
        if (withHint.length) {
          return smallest(withHint);
        }
      }
      return smallest(pool);
    };

    const pickFromList = (list, usePartialRules) => {
      if (!list || !list.length) {
        return null;
      }
      const rendered = list.filter(candidate => renderedBoxOf(candidate));
      const pool = rendered.length ? rendered : list;
      const chosen = usePartialRules ? pickSmallestWithHint(pool) : pool[0];
      if (!chosen) {
        return null;
      }
      if (!renderedBoxOf(chosen)) {
        try { chosen.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' }); } catch (_) { /* noop */ }
      }
      return { el: chosen };
    };

    const spanBoxOf = (root, fragment, start = 0, end) => {
      if (!fragment) {
        return null;
      }

      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.length) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      const startIdx = Math.max(0, start || 0);
      const endIdx = end == null ? fragment.length : Math.min(fragment.length, end);
      const useSlice = endIdx > startIdx;
      const needle = useSlice ? fragment.slice(startIdx, endIdx) : fragment;

      const nodes = [];
      let full = '';
      let node = walker.nextNode();
      while (node) {
        nodes.push({ node, offset: full.length });
        full += node.nodeValue;
        node = walker.nextNode();
      }

      const idx = full.indexOf(needle);
      if (idx === -1) {
        return null;
      }

      const locate = (pos) => {
        for (let i = nodes.length - 1; i >= 0; i--) {
          if (pos >= nodes[i].offset) {
            return { node: nodes[i].node, offset: pos - nodes[i].offset };
          }
        }
        return null;
      };

      const startPos = locate(idx);
      const lastPos = locate(idx + needle.length - 1);
      if (!startPos || !lastPos) {
        return null;
      }

      try {
        const range = document.createRange();
        range.setStart(startPos.node, startPos.offset);
        range.setEnd(lastPos.node, lastPos.offset + 1);
        const rect = range.getBoundingClientRect();
        if (!rect || rect.width <= 0 || rect.height <= 0) {
          return null;
        }
        return rectToBox(rect);
      } catch (_) {
        return null;
      }
    };

    let outcome = pickFromList(partial ? collectPartialCandidates(text.trim()) : findAllExact(), partial);
    if (!outcome) {
      outcome = pickFromList(partial ? findAllExact() : collectPartialCandidates(text.trim()), !partial);
    }
    if (!outcome || !outcome.el) {
      return null;
    }
    const el = outcome.el;

    await stabilizeAfterScroll(el);
    const target = nearestWholeElement(el);
    const matchedPath = elementPath(el);
    const matchedFromPath = elementFromPath(matchedPath);
    const rect = target.getBoundingClientRect();
    const stableId = stableIdOf(target);
    const stableSelector = stableSelectorOf(target);
    let box = rectToBox(rect);
    let wholeFallback = false;
    if (partial) {
      const fragmentBox = spanBoxOf(el, text.trim(), sliceStart, sliceEnd);
      if (fragmentBox) {
        box = fragmentBox;
      } else {
        wholeFallback = true;
      }
    }

    return {
      box,
      wholeFallback,
      partial: !!partial,
      sliceStart,
      sliceEnd,
      matchedText: el.textContent.trim(),
      matchedPath,
      stableId,
      stableSelector,
      targetTagName: target.tagName.toLowerCase(),
      matchedTagName: el.tagName.toLowerCase(),
      text: text.trim(),
    };
  }, { text, partial: !!options.partial, sliceStart: options.sliceStart, sliceEnd: options.sliceEnd, keyword: options.keyword || '' });
}

function boxFromTarget(target) {
  if (target && target.box) {
    return target.box;
  }
  return target;
}

function toScreenshotCoords(box) {
  if (box && box.box) {
    box = box.box;
  }
  return { x: box.x, y: box.y, width: box.width, height: box.height };
}

function resolveFreshTargetBox(page, target) {
  if (!target) {
    return Promise.resolve(null);
  }

  return page.evaluate(async ({ target }) => {
    const boxOf = (el) => {
      const rect = el.getBoundingClientRect();
      return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
    };

    const stabilizeAfterScroll = async (node) => {
      node.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
      let prevKey = null;
      for (let i = 0; i < 12; i++) {
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        const rect = node.getBoundingClientRect();
        const key = `${rect.x},${rect.y},${rect.width},${rect.height}`;
        if (key === prevKey) break;
        prevKey = key;
      }
    };

    const WHOLE_SELECTORS = [
      'button', 'a', '[role="button"]', 'input', 'select', 'textarea', 'label',
      'li', 'tr', '[data-testid]', '[data-annotation-id]', '[data-ut-target]',
    ].join(', ');

    const nearestWholeElement = (el) => (
      el.closest(WHOLE_SELECTORS) || el
    );

    const selector = target.stableSelector || target.stableId;
    if (selector) {
      const bySelector = document.querySelector(selector);
      if (bySelector) {
        const whole = nearestWholeElement(bySelector);
        await stabilizeAfterScroll(whole);
        return boxOf(whole);
      }
    }

    if (target.text) {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.trim()) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });
      let node = walker.nextNode();
      while (node) {
        if (node.parentElement && node.parentElement.textContent.trim() === target.text.trim()) {
          const whole = nearestWholeElement(node.parentElement);
          await stabilizeAfterScroll(whole);
          return boxOf(whole);
        }
        node = walker.nextNode();
      }
    }

    return target.box || null;
  }, { target });
}

async function upgradeStaleTargetToPartial(page, target, testCase) {
  const keywordHint = testCase.Keyword || '';
  let upgraded = await findElementTarget(page, testCase.PartialText, {
    partial: true,
    keyword: keywordHint,
  });

  if (!upgraded && target.matchedText) {
    const selector = target.stableSelector || target.stableId;
    if (selector) {
      const currentText = await page.evaluate((sel) => {
        const el = document.querySelector(sel);
        return el ? el.textContent.trim() : null;
      }, selector);
      if (currentText) {
        const autoSlices = sliceRange(target.matchedText, currentText);
        const changedSlice = currentText.slice(autoSlices.start, autoSlices.afterEnd).trim();
        if (changedSlice) {
          upgraded = await findElementTarget(page, changedSlice, { partial: true, keyword: keywordHint });
        }
      }
    }
  }

  if (!upgraded || !upgraded.box) {
    return null;
  }
  console.log(`  Upgraded stale whole-element position to fragment mode for '${upgraded.text}'.`);
  return upgraded;
}

function highlightElementTarget(page, target) {
  if (!target) {
    return Promise.resolve(false);
  }

  return page.evaluate(async ({ target, annotationColor }) => {
    const stabilizeAfterScroll = async (node) => {
      node.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'instant' });
      let prevKey = null;
      for (let i = 0; i < 12; i++) {
        await new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(resolve)));
        const rect = node.getBoundingClientRect();
        const key = `${rect.x},${rect.y},${rect.width},${rect.height}`;
        if (key === prevKey) break;
        prevKey = key;
      }
    };

    const WHOLE_SELECTORS = [
      'button', 'a', '[role="button"]', 'input', 'select', 'textarea', 'label',
      'li', 'tr', '[data-testid]', '[data-annotation-id]', '[data-ut-target]',
    ].join(', ');

    const nearestWholeElement = (el) => (
      el.closest(WHOLE_SELECTORS) || el
    );

    const elementFromPath = (path) => {
      let node = document.body;
      for (const index of path || []) {
        if (!node || !node.children || !node.children[index]) {
          return null;
        }
        node = node.children[index];
      }
      return node;
    };

    const findByText = (text) => {
      if (!text) {
        return null;
      }

      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.trim()) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      let node = walker.nextNode();
      while (node) {
        if (node.parentElement && node.parentElement.textContent.trim() === text.trim()) {
          return node.parentElement;
        }
        node = walker.nextNode();
      }

      return Array.from(document.querySelectorAll('body *'))
        .find(el => el.childNodes.length && el.textContent.trim() === text.trim()) || null;
    };

    const findPartialElement = (fragment) => {
      if (!fragment) {
        return null;
      }

      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.trim()) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      let node = walker.nextNode();
      while (node) {
        if (node.parentElement && node.parentElement.textContent.includes(fragment.trim())) {
          return node.parentElement;
        }
        node = walker.nextNode();
      }

      return Array.from(document.querySelectorAll('body *'))
        .find(el => el.childNodes.length && el.textContent.includes(fragment.trim())) || null;
    };

    const spanBoxOf = (root, fragment, start, end) => {
      if (!fragment) {
        return null;
      }

      const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
        acceptNode(node) {
          if (!node.nodeValue || !node.nodeValue.length) {
            return NodeFilter.FILTER_REJECT;
          }
          return NodeFilter.FILTER_ACCEPT;
        },
      });

      const startIdx = Math.max(0, start || 0);
      const endIdx = end == null ? fragment.length : Math.min(fragment.length, end);
      const useSlice = endIdx > startIdx;
      const needle = useSlice ? fragment.slice(startIdx, endIdx) : fragment;

      const nodes = [];
      let full = '';
      let node = walker.nextNode();
      while (node) {
        nodes.push({ node, offset: full.length });
        full += node.nodeValue;
        node = walker.nextNode();
      }

      const idx = full.indexOf(needle);
      if (idx === -1) {
        return null;
      }

      const locate = (pos) => {
        for (let i = nodes.length - 1; i >= 0; i--) {
          if (pos >= nodes[i].offset) {
            return { node: nodes[i].node, offset: pos - nodes[i].offset };
          }
        }
        return null;
      };

      const startPos = locate(idx);
      const lastPos = locate(idx + needle.length - 1);
      if (!startPos || !lastPos) {
        return null;
      }

      try {
        const range = document.createRange();
        range.setStart(startPos.node, startPos.offset);
        range.setEnd(lastPos.node, lastPos.offset + 1);
        const rect = range.getBoundingClientRect();
        if (!rect || rect.width <= 0 || rect.height <= 0) {
          return null;
        }
        return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
      } catch (_) {
        return null;
      }
    };

    if (target.partial && target.text) {
      const partialEl = (target.stableSelector && document.querySelector(target.stableSelector))
        || elementFromPath(target.matchedPath)
        || findPartialElement(target.text);
      if (!partialEl) {
        return false;
      }
      await stabilizeAfterScroll(partialEl);
      const box = spanBoxOf(partialEl, target.text.trim(), target.sliceStart, target.sliceEnd);
      if (!box) {
        return false;
      }
      const existing = document.getElementById('ut-position-highlight');
      if (existing) {
        existing.remove();
      }
      const div = document.createElement('div');
      div.id = 'ut-position-highlight';
      div.style.position = 'fixed';
      div.style.left = `${box.x}px`;
      div.style.top = `${box.y}px`;
      div.style.width = `${box.width}px`;
      div.style.height = `${box.height}px`;
      div.style.boxShadow = `0 0 0 3px ${annotationColor}`;
      div.style.pointerEvents = 'none';
      div.style.zIndex = '2147483647';
      document.documentElement.appendChild(div);
      return box;
    }

    const selector = target.stableSelector || target.stableId;
    const matched = (selector && document.querySelector(selector))
      || elementFromPath(target.matchedPath)
      || findByText(target.text);
    if (!matched) {
      return false;
    }

    await stabilizeAfterScroll(matched);

    if (target.text) {
      const spanBox = spanBoxOf(matched, target.text.trim(), target.sliceStart, target.sliceEnd);
      if (spanBox) {
        const existing = document.getElementById('ut-position-highlight');
        if (existing) {
          existing.remove();
        }
        const div = document.createElement('div');
        div.id = 'ut-position-highlight';
        div.style.position = 'fixed';
        div.style.left = `${spanBox.x}px`;
        div.style.top = `${spanBox.y}px`;
        div.style.width = `${spanBox.width}px`;
        div.style.height = `${spanBox.height}px`;
        div.style.boxShadow = `0 0 0 3px ${annotationColor}`;
        div.style.pointerEvents = 'none';
        div.style.zIndex = '2147483647';
        document.documentElement.appendChild(div);
        return spanBox;
      }
    }

    const el = nearestWholeElement(matched);
    el.setAttribute('data-ut-highlight', 'true');
    el.style.boxShadow = `0 0 0 3px ${annotationColor}`;
    const rect = el.getBoundingClientRect();
    return { x: rect.x, y: rect.y, width: rect.width, height: rect.height };
  }, { target, annotationColor: ANNOTATION_COLOR });
}

function drawBoxAtPosition(page, box) {
  return page.evaluate(({ box, annotationColor }) => {
    const targetBox = box && box.box ? box.box : box;
    const existing = document.getElementById('ut-position-highlight');
    if (existing) {
      existing.remove();
    }
    const div = document.createElement('div');
    div.id = 'ut-position-highlight';
    div.style.position = 'fixed';
    div.style.left = `${targetBox.x}px`;
    div.style.top = `${targetBox.y}px`;
    div.style.width = `${targetBox.width}px`;
    div.style.height = `${targetBox.height}px`;
    div.style.boxShadow = `0 0 0 3px ${annotationColor}`;
    div.style.pointerEvents = 'none';
    div.style.zIndex = '2147483647';
    document.documentElement.appendChild(div);
    return { x: targetBox.x, y: targetBox.y, width: targetBox.width, height: targetBox.height };
  }, { box, annotationColor: ANNOTATION_COLOR });
}

function clearHighlight(page) {
  return page.evaluate(() => {
    const el = document.querySelector('[data-ut-highlight]');
    if (el) {
      el.style.boxShadow = '';
      el.removeAttribute('data-ut-highlight');
    }
    const overlay = document.getElementById('ut-position-highlight');
    if (overlay) {
      overlay.remove();
    }
  });
}

async function captureCleanAndAnnotated(browserName, startTime, page, cleanPath, annotPath, locator, drawBox = true) {
  const normalizedLocator = typeof locator === 'string'
    ? { type: 'text', value: locator }
    : locator;

  const scrollY = await page.evaluate(() => window.scrollY);

  let annotationRect = null;
  if (drawBox) {
    if (normalizedLocator.type === 'box') {
      annotationRect = await drawBoxAtPosition(page, normalizedLocator.value);
    } else if (normalizedLocator.type === 'target') {
      const highlighted = await highlightElementTarget(page, normalizedLocator.value);
      if (highlighted) {
        annotationRect = highlighted;
      } else {
        annotationRect = await drawBoxAtPosition(page, normalizedLocator.value);
      }
    } else {
      annotationRect = await findElementByText(page, normalizedLocator.value);
    }
  }
  await captureEvidence(browserName, startTime, page, annotPath);
  await clearHighlight(page);
  await captureEvidence(browserName, startTime, page, cleanPath);
  await page.evaluate((y) => window.scrollTo(0, y), scrollY);
  return { cleanPath, annotPath, annotationRect };
}

function positionFilePath(testId, browser) {
  return path.join(HTML_DIR, `${testId}-${browser}-position.json`);
}

function viewportFilePath(testId, browser) {
  return path.join(HTML_DIR, `${testId}-${browser}-viewport.json`);
}

function readViewport(page) {
  return page.evaluate(() => ({
    innerWidth: window.innerWidth,
    innerHeight: window.innerHeight,
    outerWidth: window.outerWidth,
    outerHeight: window.outerHeight,
    devicePixelRatio: window.devicePixelRatio,
  }));
}

function isKeywordOnlyCase(testCase) {
  return !testCase.AfterText && (!!testCase.Keyword || !!testCase.PartialText);
}

function redBoxEnabled(testCase) {
  const v = String(testCase.RedBox || '').trim().toLowerCase();
  if (v === 'true') return true;
  if (v === 'false') return false;
  return !('RedBox' in testCase);
}

function resolvePositionFromFile(testCase) {
  const posPath = positionFilePath(testCase.TestID, testCase.Browser);
  if (!fs.existsSync(posPath)) {
    throw new Error(`Position file missing (${path.basename(posPath)}) - run npm run ut first to remember the keyword position.`);
  }
  return JSON.parse(fs.readFileSync(posPath, 'utf8'));
}

function getProcessName(browser) {
  const map = {
    chrome: 'chrome',
    edge: 'msedge',
    firefox: 'firefox',
  };
  const name = (browser || '').toLowerCase();
  if (name === 'edge' && ENGINE_INFO[name] && ENGINE_INFO[name].bundled) {
    // Bundled fallback for Edge is Chromium, whose process is chrome.exe.
    return 'chrome';
  }
  return map[name];
}

async function captureBrowserWindow(browserName, startTime, page, outPath) {
  const processName = getProcessName(browserName);
  if (!processName) {
    throw new Error(`Cannot capture browser window for unsupported browser '${browserName}'.`);
  }
  if (page.isClosed()) {
    throw new Error('Page already closed — skipping window capture.');
  }

  const winPos = await page.evaluate(() => ({
    x: window.screenX,
    y: window.screenY,
  }));

  const args = [
    '-NoProfile',
    '-ExecutionPolicy',
    'Bypass',
    '-File',
    WINDOW_CAPTURE_SCRIPT,
    '-ProcessName',
    processName,
    '-StartTime',
    startTime.toISOString(),
    '-ExpectedX',
    String(winPos.x),
    '-ExpectedY',
    String(winPos.y),
    '-OutFile',
    outPath,
  ];
  await execFileAsync('powershell.exe', args, {
    timeout: 60000,
    windowsHide: true,
  });
}

async function captureEvidence(browserName, startTime, page, outPath) {
  const dedupeKey = path.basename(outPath).replace(/-(before|after)(-annotated)?\.png$/g, '');
  if (windowCaptureWarned.has(dedupeKey)) {
    await page.screenshot({ path: outPath, fullPage: false }).catch(() => {});
    return;
  }
  try {
    await captureBrowserWindow(browserName, startTime, page, outPath);
  } catch (error) {
    windowCaptureWarned.add(dedupeKey);
    console.warn(
      `Window capture failed for ${path.basename(outPath)}, falling back to screenshot.\n` +
      `  ${error.message}\n` +
      `  stderr: ${(error.stderr || '').trim() || '(none)'}\n` +
      `  code: ${error.code}  signal: ${error.signal || 'none'}  killed: ${error.killed ? 'yes' : 'no'}`
    );
    if (page.isClosed()) {
      throw new Error('page/browser was closed before the fallback screenshot could run');
    }
    await page.setViewportSize({ width: 1440, height: 900 }).catch(() => {});
    await page.screenshot({ path: outPath, fullPage: false });
  }
}

function prettyHtml(html) {
  return html.replace(/>\s*</g, '>\n<').trim();
}

function normalizeHtml(html) {
  return String(html)
    .replace(/[?&]t=\d+/g, '')
    .replace(/^&/, '?');
}

async function captureRawSource(context, url) {
  const response = await context.request.get(url);
  if (!response.ok()) {
    console.warn(`  Note: ${url} returned HTTP ${response.status()} ${response.statusText()}; capturing the served body as View Page Source.`);
  }
  return response.text();
}

function isPlaceholder(value) {
  return !value || value === '-' || value === '(not applicable)';
}

function toInt(value) {
  if (value === undefined || value === null || value === '') {
    return undefined;
  }
  const n = parseInt(String(value), 10);
  return Number.isFinite(n) ? n : undefined;
}

// Date Field Rule: the mapped value is the source of truth. For native date
// inputs convert MM/DD/YYYY (and M/D/YYYY) to YYYY-MM-DD; keep YYYY-MM-DD as-is.
// Returns null when the value cannot be parsed as a date at all.
function toNativeDateValue(value) {
  const raw = String(value === undefined || value === null ? '' : value).trim();
  if (!raw) return '';
  let m = raw.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);
  if (m) {
    return `${m[1]}-${String(m[2]).padStart(2, '0')}-${String(m[3]).padStart(2, '0')}`;
  }
  m = raw.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (m) {
    return `${m[3]}-${String(m[1]).padStart(2, '0')}-${String(m[2]).padStart(2, '0')}`;
  }
  m = raw.match(/^(\d{4})\/(\d{1,2})\/(\d{1,2})$/);
  if (m) {
    return `${m[1]}-${String(m[2]).padStart(2, '0')}-${String(m[3]).padStart(2, '0')}`;
  }
  return null;
}

function isValidBox(box) {
  return !!box && Number.isFinite(box.x) && Number.isFinite(box.y)
    && Number.isFinite(box.width) && Number.isFinite(box.height)
    && box.width > 0 && box.height > 0;
}

function warnWholeFallback(context, target) {
  if (target && target.wholeFallback) {
    console.warn(`  WARNING: ${context} - fragment-only box could not be computed; using the whole element box instead.`);
  }
}

function isWordChar(ch) {
  if (!ch) {
    return false;
  }
  return /[A-Za-z0-9_\u3005\u3040-\u30ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/.test(ch);
}

function sliceRange(beforeText, afterText) {
  const before = beforeText || '';
  const after = afterText || '';
  let start = 0;
  const maxPrefix = Math.min(before.length, after.length);
  while (start < maxPrefix && before[start] === after[start]) {
    start++;
  }
  let suffix = 0;
  const maxSuffix = Math.min(before.length, after.length) - start;
  while (suffix < maxSuffix && before[before.length - 1 - suffix] === after[after.length - 1 - suffix]) {
    suffix++;
  }

  let s = start;
  while (s > 0 && isWordChar(before[s]) && isWordChar(before[s - 1])) {
    s--;
  }
  let beforeEnd = before.length - suffix;
  while (beforeEnd < before.length && isWordChar(before[beforeEnd]) && isWordChar(before[beforeEnd - 1])) {
    beforeEnd++;
  }
  let afterEnd = after.length - suffix;
  while (afterEnd < after.length && isWordChar(after[afterEnd]) && isWordChar(after[afterEnd - 1])) {
    afterEnd++;
  }

  return {
    start: s,
    beforeEnd,
    afterEnd,
  };
}

async function resolveCaseUrl(page, testCase, navOverrides = {}) {
  let targetUrl = testCase.URL;
  if (!testCase.TargetScreen) return targetUrl;

  const log = (msg, level) => (level === 'warn' || level === 'success' ? console.log(`  ${msg}`) : console.log(msg));
  const strategy = ['auto', 'direct', 'replay'].includes(testCase.NavReplay) ? testCase.NavReplay : 'auto';
  const allowDangerous = testCase.DangerousOk === true || testCase.DangerousOk === 'true';
  const navOpts = {
    strategy,
    allowDangerous,
    loginId: testCase.LoginId || '',
    loginPassword: testCase.Password || '',
    loginIdSelector: testCase.LoginIdSelector || '',
    passwordSelector: testCase.PasswordSelector || '',
    loginButtonSelector: testCase.LoginButtonSelector || '',
  };

  // Keyword-only after-mode navigation must not require the (possibly changed)
  // keyword text to still be on the page; the saved position file re-locates
  // the target element, so verify landing by target-screen heading only.
  const navKeyword = navOverrides.relaxKeyword ? '' : (testCase.Keyword || '');

  // 1. Generated routes (nav-routes.json) — preferred knowledge source.
  const routedUrl = await resolveRouteConfig(page, ROOT, testCase.TargetScreen, navKeyword, log, navOpts);
  if (routedUrl) {
    return routedUrl;
  }

  // 2. Learned history (navigation-path.json).
  const cachedUrl = await resolveFromCache(page, REPORT_DIR, testCase.TargetScreen, navKeyword, log, navOpts);
  if (cachedUrl) {
    return cachedUrl;
  }

  // No blind searching by design: a missing route must fail loudly so the
  // route config gets fixed instead of crawling the site.
  throw new Error(`No navigation route for target screen "${testCase.TargetScreen}" (no usable entry in nav-routes.json / ut-report/navigation-path.json). Run: npm run nav:generate`);
}

async function loginAndGoto(page, testCase, navOverrides = {}) {
  const targetUrl = await resolveCaseUrl(page, testCase, navOverrides);
  if (normalizeUrlKey(page.url()) !== normalizeUrlKey(targetUrl)) {
    await page.goto(targetUrl, { waitUntil: 'domcontentloaded', timeout: 60000 });
  }
  await page.waitForTimeout(2000).catch(() => {});

  for (let i = 0; i < 6; i++) {
    const modalExists = await page.evaluate(() => !!(
      document.querySelector('[role="dialog"]') ||
      document.querySelector('[aria-modal="true"]')
    ));
    if (!modalExists) break;

    console.log(`  Modal detected — dismissing...`);

    await page.keyboard.press('Escape');
    await page.waitForTimeout(800).catch(() => {});

    let stillOpen = await page.evaluate(() => !!(
      document.querySelector('[role="dialog"]') ||
      document.querySelector('[aria-modal="true"]')
    ));

    if (stillOpen) {
      await page.evaluate(() => {
        const skipBtn = Array.from(document.querySelectorAll('button, a')).find(el =>
          el.textContent.trim().toLowerCase().includes('skip')
        );
        if (skipBtn) skipBtn.click();
      });
      await page.waitForTimeout(800).catch(() => {});
    }

    stillOpen = await page.evaluate(() => !!(
      document.querySelector('[role="dialog"]') ||
      document.querySelector('[aria-modal="true"]')
    ));

    if (stillOpen) {
      await page.evaluate(() => {
        const n5Btn = Array.from(document.querySelectorAll('button')).find(el =>
          el.textContent.includes('N5')
        );
        if (n5Btn) n5Btn.click();
      });
      await page.waitForTimeout(800).catch(() => {});
    }

    const dismissed = await page.evaluate(() => !(
      document.querySelector('[role="dialog"]') ||
      document.querySelector('[aria-modal="true"]')
    ));
    if (dismissed) {
      console.log(`  Modal dismissed`);
      break;
    }
  }
  if (testCase.LoginNavSelector) {
    const navLink = page.locator(testCase.LoginNavSelector);
    if (await navLink.count()) {
      await navLink.click();
      await page.waitForLoadState('load', { timeout: 15000 });
      await page.waitForTimeout(1000).catch(() => {}); // wait for the login page to stabilize
    } else {
      console.warn(`  LoginNavSelector '${testCase.LoginNavSelector}' not found, skipping navigation.`);
    }
  }
  const loginBtnRaw = testCase.LoginButtonSelector || '';
  const hasCreds = !!(testCase.LoginId || testCase.Password);
  const skipLogin = testCase.LoginButtonSelector === '(not applicable)' || !hasCreds;
  if (skipLogin) {
    await page.waitForLoadState('load', { timeout: 15000 }).catch(() => {});
    return;
  }

  const loginBtn = loginBtnRaw ? await resolveSelectorLocator(page, loginBtnRaw) : page.locator('button[type="submit"], input[type="submit"]').first();
  if (loginBtn && (await loginBtn.count())) {
    const idSel  = testCase.LoginIdSelector  || '';
    const pwSel  = testCase.PasswordSelector || '';
    const idEl = idSel ? await resolveSelectorLocator(page, idSel)  : page.locator('input[type="text"], input[type="email"]').first();
    const pwEl = pwSel ? await resolveSelectorLocator(page, pwSel)  : page.locator('input[type="password"]').first();
    if (idEl && pwEl && (await idEl.count()) && (await pwEl.count())) {
      await idEl.fill(testCase.LoginId || '');
      await pwEl.fill(testCase.Password || '');
      await loginBtn.click();
      await page.waitForLoadState('load', { timeout: 30000 }).catch(() => {});
      await page.waitForTimeout(1000).catch(() => {});
    }
  }

  // ─── Form element auto-fill ────────────────────────────────────────────────
  // Elements come from the form builder: [{type,label,value}, ...]. "label"
  // is resolved as a CSS selector first, then via name/id/accessible-label/
  // placeholder fallbacks — first visible match wins. Runs after navigation,
  // modal dismissal and login so the target controls are actually present.
  await fillCaseElements(page, testCase);

  // ─── After-fill action (submit / cancel / custom / none) ──────────────────
  const afterAction = testCase.AfterFillAction || testCase.afterFillAction || '';
  const submitSel = testCase.SubmitButtonSelector || testCase.submitButtonSelector || '';
  const actBtn = await findAfterFillButton(page, afterAction, submitSel);
  if (actBtn) {
    console.log(`  Clicking ${afterAction === 'cancel' ? 'Cancel' : 'Submit'} button after form fill`);
    await actBtn.click();
    await page.waitForLoadState('load', { timeout: 15000 }).catch(() => {});
    await page.waitForTimeout(1000).catch(() => {});
  } else if (afterAction && afterAction !== 'none') {
    console.warn(`  After-fill button not found (action: ${afterAction}) — skipping.`);
  }
}

async function findAfterFillButton(page, action, customSel) {
  const a = String(action || '').toLowerCase();
  if (a === 'none' || a === 'skip') return null;

  let names = [];
  if (a === 'submit') names = ['Submit', 'Save', '登録', '保存', '確認'];
  else if (a === 'cancel') names = ['Cancel', 'キャンセル', '戻る', '閉じる'];
  else { // 'custom' or legacy (empty action with a selector set)
    if (!customSel || customSel === '-') return null;
    return resolveSelectorLocator(page, customSel);
  }

  for (const n of names) {
    const loc = await resolveSelectorLocator(page, n);
    if (loc) return loc;
  }
  const fb = a === 'cancel'
    ? `button:has-text("キャンセル"), .btn-cancel, #cancelBtn, button:has-text("Cancel")`
    : `button[type="submit"], input[type="submit"], button:has-text("登録"), .btn-submit`;
  const loc = page.locator(fb).first();
  return (await loc.count()) ? loc : null;
}

function caseElements(testCase) {
  const raw = testCase.Elements !== undefined ? testCase.Elements : testCase.elements;
  let list = raw;
  if (typeof list === 'string' && list.trim()) {
    try { list = JSON.parse(list); } catch { return []; }
  }
  if (!Array.isArray(list)) return [];
  return list.filter(Boolean);
}

function attrSafe(v) {
  return String(v).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
}

async function resolveSelectorLocator(page, text) {
  const label = String(text || '').trim();
  if (!label) return null;
  const candidates = [
    () => page.locator(label),
    () => page.getByRole('button', { name: label, exact: true }),
    () => page.locator(`[name="${attrSafe(label)}"]`),
    /^[A-Za-z][\w:-]*$/.test(label) ? () => page.locator('#' + label) : null,
    () => page.getByLabel(label, { exact: true }),
    () => page.getByPlaceholder(label),
    () => page.getByText(label, { exact: true }),
    () => page.locator(`[aria-label="${attrSafe(label)}"]`),
  ].filter(Boolean);
  for (const make of candidates) {
    try {
      const loc = make().first();
      const count = await loc.count();
      if (count > 0 && await loc.isVisible().catch(() => false)) return loc;
    } catch { /* invalid selector for this engine — try next strategy */ }
  }
  return null;
}

async function resolveElementLocator(page, el) {
  return resolveSelectorLocator(page, el && el.label);
}

const CHECKED_TRUE_RE = /^(checked|true|yes|on|1)$/i;

async function fillOneElement(page, el) {
  const type = String(el.type || 'text').toLowerCase();
  const value = String(el.value === undefined || el.value === null ? '' : el.value);
  const loc = await resolveElementLocator(page, el);
  if (!loc) return `not found`;

  switch (type) {
    case 'checkbox': {
      await loc.setChecked(CHECKED_TRUE_RE.test(value));
      return `checked=${CHECKED_TRUE_RE.test(value)}`;
    }
    case 'radio': {
      if (!(await loc.isChecked().catch(() => false))) {
        try {
          await loc.check({ timeout: 2000 });
        } catch {
          // value semantics: pick the radio whose VALUE matches within the group
          const byValue = page.locator(`input[type="radio"][value="${attrSafe(value)}"]`).first();
          if ((await byValue.count()) > 0) await byValue.check({ timeout: 2000 });
          else throw new Error('radio not selectable');
        }
      }
      return `selected ${value}`;
    }
    case 'select': {
      try {
        await loc.selectOption({ label: value }, { timeout: 3000 });
      } catch {
        await loc.selectOption(value, { timeout: 3000 });
      }
      return `selected ${value}`;
    }
    case 'date': {
      const inputType = await loc.getAttribute('type').catch(() => '');
      const isNativeDate = (inputType || '').toLowerCase() === 'date';
      let fillValue = toNativeDateValue(value);
      if (isNativeDate && (!value || fillValue === '')) {
        const today = new Date();
        fillValue = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
      }
      if (isNativeDate && fillValue) {
        await loc.fill(fillValue, { timeout: 5000 });
        return `filled ${fillValue}`;
      }
      await loc.fill(value, { timeout: 5000 });
      return `filled`;
    }
    default: {
      // text, password, textarea, email, url, number, date, tel, search...
      await loc.fill(value, { timeout: 5000 });
      return `filled`;
    }
  }
}

async function fillCaseElements(page, testCase) {
  const els = caseElements(testCase);
  if (!els.length) return;
  console.log(`  Filling ${els.length} form element(s)...`);
  for (const el of els) {
    if (!String(el.label || '').trim()) {
      console.warn(`  WARNING: form element with empty Label (${el.type || 'text'}) skipped — set Label to a CSS selector, name, label or placeholder text.`);
      continue;
    }
    try {
      const result = await fillOneElement(page, el);
      if (result === 'not found') {
        console.warn(`  WARNING: form element '${el.label}' (${el.type || 'text'}) not found on page — skipped.`);
      } else {
        console.log(`  Element '${el.label}' → ${result}`);
      }
    } catch (err) {
      console.warn(`  WARNING: failed to fill '${el.label}' (${el.type || 'text'}): ${(err.message || err).split('\n')[0]}`);
    }
  }
}

async function runBefore(testCase, page, browserStart) {
  const startTime = new Date();
  const entry = {
    testCase,
    startTime,
    browserStart: browserStart || null,
    beforePath: '',
    beforeAnnotPath: '',
    beforeHtmlPath: '',
    beforeDomPath: '',
    beforeRaw: '',
    beforeDom: '',
    beforeTextContent: '',
    beforeAnnotationBox: null,
    error: '',
  };

  try {
    await loginAndGoto(page, testCase);

    const gateText = testCase.BeforeText || testCase.Keyword || testCase.PartialText;
    if (!gateText || !(await hasText(page, gateText))) {
      throw new Error(`Required text '${gateText}' (BeforeText, Keyword or PartialText) was not found on the page.`);
    }

    const keywordOnly = isKeywordOnlyCase(testCase);
    const textCoverBefore = keywordOnly && !!testCase.BeforeText && !testCase.PartialText;
    let savedTarget = null;
    if (keywordOnly) {
      const beforeText = testCase.PartialText || testCase.Keyword;
      const autoSlices = testCase.PartialText && testCase.AfterPartialText
        ? sliceRange(testCase.PartialText, testCase.AfterPartialText)
        : null;
      const manualStart = toInt(testCase.SliceStart);
      const manualEnd = toInt(testCase.SliceEnd);
      savedTarget = await findElementTarget(page, beforeText, {
        partial: !!testCase.PartialText,
        sliceStart: manualStart !== undefined ? manualStart : (autoSlices ? autoSlices.start : undefined),
        sliceEnd: manualEnd !== undefined ? manualEnd : (autoSlices ? autoSlices.beforeEnd : undefined),
        keyword: testCase.Keyword || '',
      });
      if (!savedTarget) {
        throw new Error(`Could not locate element for '${beforeText}' on the page to remember its position.`);
      }
      warnWholeFallback(`${testCase.TestID} (${testCase.Browser}) before phase`, savedTarget);
      if (!isValidBox(savedTarget.box)) {
        throw new Error(`Located '${beforeText}' but its annotation box is degenerate (zero size); cannot remember its position.`);
      }
      const posPath = positionFilePath(testCase.TestID, testCase.Browser);
      fs.writeFileSync(posPath, JSON.stringify(savedTarget, null, 2), 'utf8');
    }

    const beforePath = path.join(SCREENSHOT_DIR, `${testCase.TestID}-${testCase.Browser}-before.png`);
    const beforeAnnotPath = path.join(ARTIFACT_DIR, `${testCase.TestID}-${testCase.Browser}-before-annotated.png`);
    const highlightLocator = keywordOnly && !textCoverBefore
      ? { type: 'target', value: savedTarget }
      : { type: 'text', value: gateText };
    entry.beforeViewport = await readViewport(page);
    fs.writeFileSync(viewportFilePath(testCase.TestID, testCase.Browser), JSON.stringify(entry.beforeViewport, null, 2), 'utf8');
    const beforeResult = await captureCleanAndAnnotated(testCase.Browser, browserStart || startTime, page, beforePath, beforeAnnotPath, highlightLocator, redBoxEnabled(testCase));
    entry.beforePath = beforeResult.cleanPath;
    entry.beforeAnnotPath = beforeResult.annotPath;
    if (redBoxEnabled(testCase) && beforeResult.annotationRect) {
      const coords = toScreenshotCoords(beforeResult.annotationRect);
      if (isValidBox(coords)) {
        entry.beforeAnnotationBox = coords;
        console.log(`    Position captured for ${testCase.TestID} (${testCase.Browser}): x=${Math.round(entry.beforeAnnotationBox.x)} y=${Math.round(entry.beforeAnnotationBox.y)} w=${Math.round(entry.beforeAnnotationBox.width)} h=${Math.round(entry.beforeAnnotationBox.height)}`);
      }
    }

    try {
      entry.beforeRaw = await captureRawSource(page.context(), page.url());
    } catch (error) {
      entry.beforeRaw = `<!-- raw source fetch failed: ${error.message} -->`;
    }
    entry.beforeHtmlPath = path.join(HTML_DIR, `${testCase.TestID}-${testCase.Browser}-before.html`);
    fs.writeFileSync(entry.beforeHtmlPath, entry.beforeRaw, 'utf8');

    entry.beforeDom = await capturePageDom(page);
    entry.beforeDomPath = path.join(HTML_DIR, `${testCase.TestID}-${testCase.Browser}-before.dom.html`);
    fs.writeFileSync(entry.beforeDomPath, entry.beforeDom, 'utf8');

    entry.beforeTextContent = await capturePageText(page);
    entry.beforeTextContentPath = path.join(HTML_DIR, `${testCase.TestID}-${testCase.Browser}-before.text.txt`);
    fs.writeFileSync(entry.beforeTextContentPath, entry.beforeTextContent, 'utf8');

    if (isValidBox(entry.beforeAnnotationBox)) {
      const beforeBoxPath = path.join(HTML_DIR, `${testCase.TestID}-${testCase.Browser}-before-box.json`);
      fs.writeFileSync(beforeBoxPath, JSON.stringify(entry.beforeAnnotationBox), 'utf8');
    }

    console.log(`[BEFORE] ${testCase.TestID} (${testCase.Browser}) captured.`);
  } catch (error) {
    entry.error = error.message || String(error);
  }

  return entry;
}

async function runAfter(entry, page) {
  const { testCase, startTime, browserStart } = entry;
  const result = {
    TestID: testCase.TestID,
    Browser: testCase.Browser,
    URL: testCase.URL,
    Navigation: describeNavigation(testCase),
    BeforeText: testCase.BeforeText || '',
    AfterText: testCase.AfterText || '',
    Keyword: testCase.Keyword || '',
    ExpectedResult: testCase.ExpectedResult || '',
    UserStatus: normalizeManualStatus(testCase.ManualStatus),
    Description: testCase.Description || '',
    Status: 'FAILED',
    Message: '',
    Screenshots: [entry.beforePath].filter(Boolean),
    Annotated: [entry.beforeAnnotPath].filter(Boolean),
    HtmlBefore: entry.beforeHtmlPath,
    HtmlAfter: '',
    HtmlDomBefore: entry.beforeDomPath,
    HtmlDomAfter: '',
    DiffChanged: '',
    DomDiffChanged: '',
    TextContentDiffChanged: '',
    BeforeAnnotationBox: entry.beforeAnnotationBox || null,
    AfterAnnotationBox: null,
    Engine: '',
    ViewportBefore: entry.beforeViewport || null,
    ViewportAfter: null,
  };

  let keywordComparison = null;

  try {
    const afterText = testCase.AfterText || '';
    const keywordText = testCase.Keyword || testCase.BeforeText || '';
    const keywordChanged = afterText && keywordText && afterText !== keywordText;
    const isKeywordOnlyMode = afterText && keywordText && afterText === keywordText;
    await loginAndGoto(page, testCase, { relaxKeyword: isKeywordOnlyCase(testCase) || keywordChanged || isKeywordOnlyMode });

    let afterLocator;
    if (testCase.AfterText) {
      if (!(await hasText(page, testCase.AfterText))) {
        throw new Error(`AfterText '${testCase.AfterText}' was not found on the after page. Please update the AfterText value in ut_cases.md to match the actual modified text.`);
      }
      afterLocator = { type: 'text', value: testCase.AfterText || testCase.Keyword || testCase.BeforeText };
    } else if (isKeywordOnlyCase(testCase)) {
      let target;
      let savedKeywordText = testCase.Keyword || '';
      try {
        target = resolvePositionFromFile(testCase);
        savedKeywordText = target ? (target.matchedText || testCase.Keyword || '') : savedKeywordText;
        if (target && !target.partial && testCase.PartialText) {
          target = await upgradeStaleTargetToPartial(page, target, testCase) || target;
        }
        if (target && !target.partial) {
          const box = await resolveFreshTargetBox(page, target);
          if (box) {
            target = { ...target, box };
          }
        }
      } catch (_) { /* ignore */ }

      let effectiveAfterPartialText = testCase.AfterPartialText;
      if (!effectiveAfterPartialText && testCase.ExpectedResult) {
        const beforeText = testCase.PartialText || testCase.Keyword || testCase.BeforeText || '';
        const autoSlices = sliceRange(beforeText, testCase.ExpectedResult);
        effectiveAfterPartialText = testCase.ExpectedResult.slice(autoSlices.start, autoSlices.afterEnd).trim();

        if (effectiveAfterPartialText) {
          console.log(`  Auto-derived AfterPartialText from ExpectedResult: '${effectiveAfterPartialText}'`);
        }
      }

      if (effectiveAfterPartialText) {
        const autoSlices = sliceRange(testCase.PartialText, effectiveAfterPartialText);
        const afterStart = toInt(testCase.AfterSliceStart) ?? toInt(testCase.SliceStart) ?? autoSlices.start;
        const afterEnd = toInt(testCase.AfterSliceEnd) ?? toInt(testCase.SliceEnd) ?? autoSlices.afterEnd;
        const fresh = await findElementTarget(page, effectiveAfterPartialText, {
          partial: true,
          sliceStart: afterStart,
          sliceEnd: afterEnd,
          keyword: testCase.Keyword || '',
        });
        if (fresh && fresh.box) {
          target = fresh;
        }
      } else if (target && target.partial && target.matchedText) {
        const selector = target.stableSelector || target.stableId;
        if (selector) {
          const currentText = await page.evaluate((sel) => {
            const el = document.querySelector(sel);
            return el ? el.textContent.trim() : null;
          }, selector);
          if (currentText) {
            const autoSlices = sliceRange(target.matchedText, currentText);
            const changedSlice = currentText.slice(autoSlices.start, autoSlices.afterEnd).trim();
            if (changedSlice) {
              const fresh = await findElementTarget(page, changedSlice, { partial: true, keyword: testCase.Keyword || '' });
              if (fresh && fresh.box) {
                target = fresh;
              }
            }
          }
        }
      }

      if (!target || !target.box) {
        target = await findElementTarget(page, testCase.PartialText || testCase.Keyword, { partial: !!testCase.PartialText, keyword: testCase.Keyword || '' });
      }
      if (!target || !target.box) {
        throw new Error(`Could not resolve a fresh annotation box for '${testCase.PartialText || testCase.Keyword}'.`);
      }
      warnWholeFallback(`${testCase.TestID} (${testCase.Browser}) after phase`, target);
      afterLocator = { type: 'target', value: target };

      const kwSelector = target.stableSelector || target.stableId;
      let currentKeywordText = null;
      if (kwSelector) {
        currentKeywordText = await page.evaluate((sel) => {
          const el = document.querySelector(sel);
          return el ? el.textContent.trim() : null;
        }, kwSelector);
      }
      if (currentKeywordText === null) {
        currentKeywordText = target.matchedText || null;
      }
      keywordComparison = { before: savedKeywordText, after: currentKeywordText };
    } else {
      afterLocator = { type: 'text', value: testCase.AfterText || testCase.Keyword || testCase.BeforeText };
    }

    let afterRaw;
    try {
      afterRaw = await captureRawSource(page.context(), page.url());
    } catch (error) {
      afterRaw = `<!-- raw source fetch failed: ${error.message} -->`;
    }
    result.HtmlAfter = path.join(HTML_DIR, `${testCase.TestID}-${testCase.Browser}-after.html`);
    fs.writeFileSync(result.HtmlAfter, afterRaw, 'utf8');

    const afterDom = await capturePageDom(page);
    result.HtmlDomAfter = path.join(HTML_DIR, `${testCase.TestID}-${testCase.Browser}-after.dom.html`);
    fs.writeFileSync(result.HtmlDomAfter, afterDom, 'utf8');

    const afterTextContent = await page.evaluate(() => document.body.innerText);

    const afterPath = path.join(SCREENSHOT_DIR, `${testCase.TestID}-${testCase.Browser}-after.png`);
    const afterAnnotPath = path.join(ARTIFACT_DIR, `${testCase.TestID}-${testCase.Browser}-after-annotated.png`);
    result.ViewportAfter = await readViewport(page);
    const afterResult = await captureCleanAndAnnotated(testCase.Browser, browserStart || startTime, page, afterPath, afterAnnotPath, afterLocator, redBoxEnabled(testCase));
    result.Screenshots.push(afterResult.cleanPath);
    result.Annotated.push(afterResult.annotPath);
    if (redBoxEnabled(testCase) && afterResult.annotationRect) {
      const coords = toScreenshotCoords(afterResult.annotationRect);
      if (isValidBox(coords)) {
        result.AfterAnnotationBox = coords;
      }
    }

    const diff = computeDiff(normalizeHtml(entry.beforeRaw), normalizeHtml(afterRaw));
    result.DiffChanged = diff.changed ? 'YES' : 'NO';

    const domDiff = computeDiff(prettyHtml(normalizeHtml(entry.beforeDom)), prettyHtml(normalizeHtml(afterDom)));
    result.DomDiffChanged = domDiff.changed ? 'YES' : 'NO';

    if (isKeywordOnlyCase(testCase)) {
      const keywordChanged = keywordComparison && keywordComparison.after !== keywordComparison.before;
      result.TextContentDiffChanged = keywordChanged ? 'YES' : 'NO';

      if (!keywordChanged) {
        const beforeKw = keywordComparison ? keywordComparison.before : '(unknown)';
        console.warn(`  ERROR: ${testCase.TestID} (${testCase.Browser}) keyword text is identical before/after ('${beforeKw}') - no real-code change detected.`);
        result.Status = 'ERROR';
        result.Message = `Error: keyword text '${beforeKw}' is identical before/after - real code was not modified or the app was not re-served. This case failed, but remaining cases continue and Excel evidence is generated.`;
        return result;
      }
    } else {
      const textDiff = computeDiff(entry.beforeTextContent, afterTextContent);
      result.TextContentDiffChanged = textDiff.changed ? 'YES' : 'NO';

      if (!textDiff.changed) {
        console.warn(`  ERROR: ${testCase.TestID} (${testCase.Browser}) visible text content is identical before/after - no real-code change detected.`);
        result.Status = 'ERROR';
        result.Message = 'Error: before and after visible text are identical - real code was not modified or the app was not re-served. This case failed, but remaining cases continue and Excel evidence is generated.';
        return result;
      }
    }

    if (testCase.ExpectedResult && !(await hasText(page, testCase.ExpectedResult))) {
      result.Status = 'FAILED';
      result.Message = `ExpectedResult '${testCase.ExpectedResult}' was not found on the after screen. Update the ExpectedResult value in ut_cases.md or fix the app.`;
      return result;
    }

    result.Status = 'PASS';
    result.Message = `Real-code change flow. Raw HTML diff: ${diff.changed ? 'changes found' : 'no changes'}; DOM diff: ${domDiff.changed ? 'changes found' : 'no changes'}.${testCase.ExpectedResult ? ' ExpectedResult verified.' : ''}`;
  } catch (error) {
    try {
      const failPath = path.join(SCREENSHOT_DIR, `${testCase.TestID}-${testCase.Browser}-error.png`);
      await captureEvidence(testCase.Browser, browserStart || startTime, page, failPath);
      result.Screenshots.push(failPath);
    } catch (screenshotError) {
      // ignore
    }
    result.Status = 'ERROR';
    result.Message = error.message || String(error);
  }

  return result;
}

async function openCasePage(browser) {
  const context = await browser.newContext({ viewport: { width: 1440, height: 900 } });
  const page = await context.newPage();
  return { context, page };
}

async function runBeforeAll(cases, browsers) {
  const activeBrowsers = browsers || BROWSERS;
  console.log('\n=== BEFORE: capturing all before evidence ===');

  async function runForBrowser(browserName) {
    const browser = await launchRealBrowser(browserName);
    const browserStart = new Date();
    let { context, page } = await openCasePage(browser);
    try {
      for (const testCase of cases) {
        try {
          const entry = await runBefore({ ...testCase, Browser: browserName }, page, browserStart);
          if (entry.error) {
            console.warn(`  WARNING: ${testCase.TestID} (${browserName}) before capture failed: ${entry.error}`);
          }
        } catch (error) {
          console.warn(`  WARNING: ${testCase.TestID} (${browserName}) before capture crashed: ${error.message || error}`);
          try {
            await context.close().catch(() => {});
          } catch (_) { /* ignore */ }
          ({ context, page } = await openCasePage(browser));
        }
      }
    } finally {
      await context.close().catch(() => {});
      await browser.close();
    }
  }

  for (const b of activeBrowsers) {
    await runForBrowser(b);
  }
}

async function runAfterAll(cases, browsers) {
  const activeBrowsers = browsers || BROWSERS;
  console.log('\n=== AFTER: capturing all after evidence and comparing ===');
  const allResults = [];

  async function runForBrowser(browserName) {
    const browser = await launchRealBrowser(browserName);
    const browserStart = new Date();
    const browserResults = [];
    let { context, page } = await openCasePage(browser);
    try {
      for (const testCase of cases) {
        try {
          const id = `${testCase.TestID}-${browserName}`;
          const beforePath = path.join(SCREENSHOT_DIR, `${id}-before.png`);
          const beforeAnnotPath = path.join(ARTIFACT_DIR, `${id}-before-annotated.png`);
          const beforeHtmlPath = path.join(HTML_DIR, `${id}-before.html`);
          const beforeDomPath = path.join(HTML_DIR, `${id}-before.dom.html`);
          const positionPath = positionFilePath(testCase.TestID, browserName);
          const requiresSavedPosition = !testCase.AfterText && (!!testCase.Keyword || !!testCase.PartialText);

          if (!fs.existsSync(beforeHtmlPath) || !fs.existsSync(beforeDomPath) || !fs.existsSync(beforePath) || !fs.existsSync(beforeAnnotPath) || (requiresSavedPosition && !fs.existsSync(positionPath))) {
            const result = {
              TestID: testCase.TestID,
              Browser: browserName,
              URL: testCase.URL,
              BeforeText: testCase.BeforeText || '',
              AfterText: testCase.AfterText || '',
              Keyword: testCase.Keyword || '',
              ExpectedResult: testCase.ExpectedResult || '',
              UserStatus: normalizeManualStatus(testCase.ManualStatus),
              Description: testCase.Description || '',
              Status: 'ERROR',
              Message: 'Before evidence missing - run npm run ut first.',
              Screenshots: [],
              Annotated: [],
              HtmlBefore: beforeHtmlPath,
              HtmlAfter: '',
              HtmlDomBefore: beforeDomPath,
              HtmlDomAfter: '',
              DiffChanged: '',
              DomDiffChanged: '',
            };
            browserResults.push(result);
            console.log(JSON.stringify(result, null, 2));
            continue;
          }

          const beforeTextContentPath = path.join(HTML_DIR, `${id}-before.text.txt`);
          const beforeBoxPath = path.join(HTML_DIR, `${id}-before-box.json`);
          const beforeViewportPath = viewportFilePath(testCase.TestID, browserName);
          const entry = {
            testCase: { ...testCase, Browser: browserName },
            startTime: new Date(),
            browserStart,
            beforePath,
            beforeAnnotPath,
            beforeHtmlPath,
            beforeDomPath,
            beforeRaw: fs.readFileSync(beforeHtmlPath, 'utf8'),
            beforeDom: fs.readFileSync(beforeDomPath, 'utf8'),
            beforeTextContent: fs.existsSync(beforeTextContentPath) ? fs.readFileSync(beforeTextContentPath, 'utf8') : '',
            beforeAnnotationBox: fs.existsSync(beforeBoxPath) ? JSON.parse(fs.readFileSync(beforeBoxPath, 'utf8')) : null,
            beforeViewport: fs.existsSync(beforeViewportPath) ? JSON.parse(fs.readFileSync(beforeViewportPath, 'utf8')) : null,
            error: '',
          };

          const result = await runAfter(entry, page);
          browserResults.push(result);
          console.log(JSON.stringify(result, null, 2));
        } catch (error) {
          console.warn(`  WARNING: ${testCase.TestID} (${browserName}) after run crashed: ${error.message || error}`);
          browserResults.push({
            TestID: testCase.TestID,
            Browser: browserName,
            URL: testCase.URL,
            BeforeText: testCase.BeforeText || '',
            AfterText: testCase.AfterText || '',
            Keyword: testCase.Keyword || '',
            ExpectedResult: testCase.ExpectedResult || '',
            UserStatus: normalizeManualStatus(testCase.ManualStatus),
            Description: testCase.Description || '',
            Status: 'ERROR',
            Message: `After run crashed: ${error.message || error}`,
            Screenshots: [],
            Annotated: [],
            HtmlBefore: '',
            HtmlAfter: '',
            HtmlDomBefore: '',
            HtmlDomAfter: '',
            DiffChanged: '',
            DomDiffChanged: '',
          });
          try {
            await context.close().catch(() => {});
          } catch (_) { /* ignore */ }
          ({ context, page } = await openCasePage(browser));
        }
      }
    } finally {
      await context.close().catch(() => {});
      await browser.close();
    }
    return browserResults;
  }

  for (const b of activeBrowsers) {
    const set = await runForBrowser(b);
    allResults.push(...set);
  }
  for (const r of allResults) {
    const info = ENGINE_INFO[r.Browser];
    if (!r.Engine && info) {
      r.Engine = info.label;
    }
  }
  return allResults;
}

function describeNavigation(testCase) {
  if (!testCase || !testCase.TargetScreen) return '';
  try {
    const entry = loadNavCache(REPORT_DIR, testCase.TargetScreen, () => {});
    if (!entry || !entry.foundUrl) return '';
    const steps = Array.isArray(entry.steps) ? entry.steps : [];
    if (!steps.length) return `Direct jump → ${entry.foundUrl}`;
    return steps.map((st, i) => (
      st && st.kind === 'goto'
        ? `Step ${i + 1}: goto ${st.url}`
        : `Step ${i + 1}: click "${(st && st.text) || '?'}" → ${(st && st.landedAt) || (st && st.href) || ''}`
    )).join(' | ').slice(0, 300);
  } catch {
    return '';
  }
}

function writeReport(results) {
  const reportMarkdown = [
    '# UT Browser Evidence Report',
    '',
    ...results.map(item => [
      `## ${item.TestID}`,
      `- Browser: ${item.Browser}`,
      `- Engine: ${item.Engine || ''}`,
      `- URL: ${item.URL}`,
      ...(item.Navigation ? [`- Navigation: ${item.Navigation}`] : []),
      `- BeforeText: ${item.BeforeText}`,
      `- AfterText: ${item.AfterText}`,
      `- Status: ${item.Status}`,
      `- ExpectedResult: ${item.ExpectedResult || ''}`,
      `- UserStatus: ${item.UserStatus || ''}`,
      `- Message: ${item.Message}`,
      `- HtmlBefore: ${item.HtmlBefore}`,
      `- HtmlAfter: ${item.HtmlAfter}`,
      `- HtmlDomBefore: ${item.HtmlDomBefore}`,
      `- HtmlDomAfter: ${item.HtmlDomAfter}`,
      `- Screenshots: ${item.Screenshots.join(', ')}`,
      '',
    ].join('\n')),
  ].join('\n');

  fs.writeFileSync(path.join(REPORT_DIR, 'ut_report.md'), reportMarkdown, 'utf8');
  fs.writeFileSync(path.join(REPORT_DIR, 'ut_report.json'), JSON.stringify(results, null, 2), 'utf8');

  console.log(`\nUT report saved to ${path.join(REPORT_DIR, 'ut_report.md')}`);
}

function parseBrowsersFlag(args) {
  const idx = args.indexOf('--browsers');
  if (idx === -1) return null;
  const val = args[idx + 1];
  if (!val) return null;
  return val.split(',').map(b => b.trim()).filter(Boolean);
}

function parseCaseFlag(args) {
  const idx = args.indexOf('--case');
  if (idx === -1) return [];
  const val = args[idx + 1];
  if (!val) return [];
  return val.split(',').map(b => b.trim()).filter(Boolean);
}

async function main() {
  const args = process.argv.slice(2);
  const phase = (args[0] || '').toLowerCase();
  if (phase !== 'before' && phase !== 'after') {
    console.error('Usage: node run-ut.js <before|after> [--browsers Chrome,Edge,Firefox] [--case UT-002,UT-003]');
    console.error('  before - capture before evidence for all cases (run first)');
    console.error('  after  - capture after evidence, compare with before, write the report');
    console.error('  --browsers - comma-separated list of browsers to run (default: all)');
    console.error('  --case     - comma-separated list of TestIDs to run (default: all cases in ut_cases.md)');
    process.exit(1);
  }

  const filterBrowsers = parseBrowsersFlag(args);
  const activeBrowsers = filterBrowsers || BROWSERS;
  const filterIds = parseCaseFlag(args);

  ensureDirs();

  if (!fs.existsSync(CASE_FILE)) {
    console.error(`UT case file not found: ${CASE_FILE}`);
    process.exit(1);
  }

  const content = fs.readFileSync(CASE_FILE, 'utf8');
  const allCases = parseCases(content);

  if (!allCases.length) {
    console.error('No UT cases found in ut_cases.md.');
    process.exit(1);
  }

  const cases = filterIds.length
    ? allCases.filter(c => filterIds.includes(c.TestID))
    : allCases;

  if (filterIds.length && !cases.length) {
    console.error(`No cases matched TestIDs: ${filterIds.join(', ')}. Available: ${allCases.map(c => c.TestID).join(', ')}`);
    process.exit(1);
  }

  if (filterBrowsers) {
    console.log(`Running only: ${activeBrowsers.join(', ')}`);
  }
  if (filterIds.length) {
    console.log(`Running only cases: ${cases.map(c => c.TestID).join(', ')}`);
  }

  if (phase === 'before') {
    await runBeforeAll(cases, activeBrowsers);
    console.log('\nBefore evidence captured. Modify the real code now, then run: npm run modified');
  } else {
    const results = await runAfterAll(cases, activeBrowsers);
    const hasError = results.some(r => r.Status === 'ERROR');
    if (hasError) {
      console.error('\nOne or more cases ended with ERROR. Report and Excel generation stopped; fix + re-serve the code, then run: npm run modified');
      process.exit(1);
    }
    writeReport(results);
  }
}

main().catch(error => {
  console.error('UT runner failed:', error);
  process.exit(1);
});
