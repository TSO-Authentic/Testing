/**
 * nav-gen.js — generates nav-routes.json by statically scanning project sources.
 *
 * READ-ONLY: this tool never writes inside the scanned projects.
 *
 * Usage:
 *   npm run nav:generate                 # uses paths from nav-sources.json
 *   node nav-gen.js C:\proj1 C:\proj2    # explicit roots override/extend the file
 *
 * Generic-first extractors:
 *   - web.xml / jboss-web.xml        servlet mappings, welcome file, context root
 *   - .jsp/.html/.xhtml/.htm         <a href>, <form action>, Struts/JSTL tags
 *   - JS/TS router configs           path:/name: pairs, JSX <Route path=...>
 *   - Next/Nuxt page directories     app dir "page." files and pages dirs (file routing)
 *   - Java controllers               @RequestMapping/@GetMapping/@PostMapping
 *   - XML/properties screen maps     screen-id-like keys -> path values
 */

const fs = require('fs');
const path = require('path');

const {
  normalizeForMatch,
  buildSearchTokens,
  diceSimilarity,
  scoreLink,
  upsertRouteEntry,
  loadRouteConfig,
  saveRouteConfig,
  DANGEROUS_TEXT_RE,
} = require('./nav-find');

const ROOT = __dirname;
const SOURCES_FILE = path.join(ROOT, 'nav-sources.json');
const CASE_FILE = path.join(ROOT, 'ut_cases.md');

const SKIP_DIRS = new Set([
  'node_modules', '.git', '.svn', 'dist', 'build', 'target', 'out', '__pycache__',
  '.next', '.nuxt', 'coverage', '.idea', '.vscode', 'ut-report', 'artifacts',
]);
const MARKUP_EXTS = new Set(['.jsp', '.jspf', '.html', '.htm', '.xhtml', '.jspx']);
const CODE_EXTS = new Set(['.js', '.jsx', '.ts', '.tsx', '.vue', '.mjs']);
const JAVA_EXTS = new Set(['.java']);
const MAP_EXTS = new Set(['.xml', '.properties']);

const ASSET_RE = /\.(png|jpe?g|gif|svg|webp|ico|css|js|mjs|json|xml|zip|pdf|docx?|xlsx?|pptx?|mp[34]|wav|ogg|woff2?|ttf|eot)(?:[?#].*)?$/i;
const SCREEN_ID_RE = /^[A-Z]{2,5}[-_]?\d{2,6}$/;

// ---------------------------------------------------------------------------
// Small helpers
// ---------------------------------------------------------------------------

function stripTags(html) {
  return String(html || '')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/\s+/g, ' ')
    .trim();
}

function walk(dir, cb, depth = 0) {
  let entries;
  try {
    entries = fs.readdirSync(dir, { withFileTypes: true });
  } catch {
    return;
  }
  for (const ent of entries) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) {
      if (SKIP_DIRS.has(ent.name) || depth > 14) continue;
      walk(full, cb, depth + 1);
    } else if (ent.isFile()) {
      cb(full);
    }
  }
}

function readText(file) {
  try {
    return fs.readFileSync(file, 'utf8');
  } catch {
    return '';
  }
}

function toPosix(p) {
  return String(p || '').replace(/\\/g, '/');
}

function joinRel(root, file) {
  return toPosix(path.relative(root, file));
}

// Find a WEB-INF/web.xml anywhere under the project root (tomcat apps put it at
// src/main/webapp/WEB-INF/web.xml, but other layouts nest it deeper). Prefers
// the conventional path first, then scans shallow directories.
function findWebXml(projectRoot) {
  const conventionals = ['src/main/webapp/WEB-INF/web.xml', 'WEB-INF/web.xml', 'web/WEB-INF/web.xml', 'main/webapp/WEB-INF/web.xml']
    .map(rel => path.join(projectRoot, rel))
    .find(p => fs.existsSync(p));
  if (conventionals) return conventionals;
  let found = '';
  walk(projectRoot, (f) => {
    if (found) return;
    if (/[\\/]WEB-INF[\\/]web\.xml$/i.test(f)) found = f;
  }, 4);
  return found;
}

function looksLikeMenu(el) {
  return !!el.inMenu;
}

function absUrl(base, ctxRoot, raw) {
  if (!raw) return '';
  let p = String(raw).trim();
  if (/^(https?:)?\/\//i.test(p) || /^(mailto:|tel:|javascript:|#)/i.test(p)) {
    return /^https?:\/\//i.test(p) ? p : '';
  }
  // Strip query-only fragments for landing purposes but keep path
  if (!p.startsWith('/')) p = '/' + p;
  if (ctxRoot && ctxRoot !== '/' && !p.startsWith(ctxRoot)) {
    p = ctxRoot.replace(/\/$/, '') + p;
  }
  try {
    return new URL(p, base).href.split('#')[0];
  } catch {
    return '';
  }
}

// ---------------------------------------------------------------------------
// Extractors
// ---------------------------------------------------------------------------

function extractWebXmlBits(projectRoot) {
  const bits = { contextRoot: '', welcome: '' };
  const jbossWeb = ['src/main/webapp/WEB-INF/jboss-web.xml', 'WEB-INF/jboss-web.xml', 'main/webapp/WEB-INF/jboss-web.xml']
    .map(rel => path.join(projectRoot, rel))
    .find(p => fs.existsSync(p));
  if (jbossWeb) {
    const m = readText(jbossWeb).match(/<context-root>([^<]+)<\/context-root>/i);
    if (m) bits.contextRoot = '/' + m[1].trim().replace(/^\/+/, '');
  }
  const webXml = findWebXml(projectRoot);
  if (webXml) {
    const text = readText(webXml);
    const wm = text.match(/<welcome-file>([^<]+)<\/welcome-file>/i);
    if (wm) bits.welcome = '/' + wm[1].trim().replace(/^\/+/, '');
    const dm = text.match(/<display-name>([^<]+)<\/display-name>/i);
    if (dm && !bits.contextRoot) bits.contextRoot = '/' + dm[1].trim().replace(/^\/+/, '');
  }
  return bits;
}

function extractServletMappings(projectRoot) {
  // Returns Map<jspPath → urlPattern> so each JSP's served URL can be derived.
  // Two sources:
  //   1. web.xml <servlet><jsp-file> + <servlet-mapping> pairs.
  //   2. <servlet-class> apps: scan the servlet class files for their
  //      getRequestDispatcher("<page>.jsp") forward targets, then map the
  //      matching URL patterns to those JSPs.
  const jspToUrl = new Map();
  const webXml = findWebXml(projectRoot);
  if (!webXml) return jspToUrl;
  const text = readText(webXml);
  if (!text) return jspToUrl;

  // First, collect all servlet-mappings: name → pattern (these are reliable)
  const mappings = new Map();
  const mappingRe = /<servlet-mapping\b[^>]*>([\s\S]*?)<\/servlet-mapping>/gi;
  for (const m of text.matchAll(mappingRe)) {
    const body = m[1] || '';
    const name = (body.match(/<servlet-name>\s*([^<]+?)\s*<\/servlet-name>/i) || [])[1] || '';
    const pattern = (body.match(/<url-pattern>\s*([^<]+?)\s*<\/url-pattern>/i) || [])[1] || '';
    if (name && pattern) mappings.set(name, pattern);
  }

  // Parse <servlet> blocks by splitting on the opening tag
  const servlets = new Map(); // name → { jspFile, servletClass }
  // Use <servlet\s or <servlet> (not servlet-mapping)
  const servletChunks = text.split(/<servlet(?=\s|>)/i);
  for (let i = 1; i < servletChunks.length; i++) {
    const chunk = servletChunks[i];
    const endIdx = chunk.indexOf('</servlet>');
    if (endIdx < 0) continue;
    const body = chunk.substring(0, endIdx);
    const name = (body.match(/<servlet-name>\s*([^<]+?)\s*<\/servlet-name>/i) || [])[1] || '';
    if (!name || !mappings.has(name)) continue;
    const jspFile = (body.match(/<jsp-file>\s*([^<]+?)\s*<\/jsp-file>/i) || [])[1] || '';
    const servletClass = (body.match(/<servlet-class>\s*([^<]+?)\s*<\/servlet-class>/i) || [])[1] || '';
    servlets.set(name, {
      jspFile: jspFile ? (jspFile.startsWith('/') ? jspFile : '/' + jspFile) : '',
      servletClass,
    });
  }

  // Map servlet class simple names → their forwarded JSP file.
  const classToJsp = new Map();
  const javaFiles = [];
  walk(projectRoot, (f) => { if (/\.java$/i.test(f)) javaFiles.push(f); });
  for (const f of javaFiles) {
    const src = readText(f) || '';
    const m = src.match(/\bgetRequestDispatcher\(\s*["']([^"']*\.jsp)["']\s*\)/i);
    if (!m) continue;
    classToJsp.set(path.basename(f, '.java').toLowerCase(), m[1].startsWith('/') ? m[1] : '/' + m[1]);
  }

  function normJspKey(jspPath) {
    let rel = jspPath.replace(/^\/+/, '');
    const webIdx = rel.toLowerCase().indexOf('webapp/');
    if (webIdx >= 0) rel = rel.slice(webIdx + 'webapp/'.length);
    return ('/' + rel).toLowerCase();
  }

  // For each mapped servlet, resolve its pattern → JSP path
  for (const [name, pattern] of mappings) {
    const servlet = servlets.get(name);
    if (!servlet) continue;
    let jspPath = servlet.jspFile;
    if (!jspPath && servlet.servletClass) {
      const simple = servlet.servletClass.split('.').pop();
      jspPath = classToJsp.get(simple.toLowerCase()) || '';
    }
    if (jspPath) jspToUrl.set(normJspKey(jspPath), pattern);
  }

  return jspToUrl;
}

function extractStrutsForwards(projectRoot) {
  // Returns Map<actionPath, [{ name, forwardPath }]> from struts-config.xml
  const forwardMap = new Map();
  const searchPaths = [
    'WEB-INF/struts-config.xml',
    'src/main/webapp/WEB-INF/struts-config.xml',
  ];
  // Also search for struts-config subdirectory fragments
  const globDirs = ['WEB-INF/struts-config', 'src/main/webapp/WEB-INF/struts-config'];

  const files = [];
  for (const rel of searchPaths) {
    const p = path.join(projectRoot, rel);
    if (fs.existsSync(p)) files.push(p);
  }
  for (const dir of globDirs) {
    const dp = path.join(projectRoot, dir);
    if (!fs.existsSync(dp)) continue;
    walk(dp, (f) => { if (f.endsWith('.xml')) files.push(f); });
  }

  for (const file of files) {
    const text = readText(file);
    if (!text) continue;
    // Match <action path="/foo" ...> blocks and extract their nested <forward> children
    const actionRe = /<action\b[^>]*path\s*=\s*["']([^"']+)["'][^>]*>([\s\S]*?)<\/action>/gi;
    let am;
    while ((am = actionRe.exec(text)) !== null) {
      const actionPath = am[1];
      const body = am[2] || '';
      const forwards = [];
      const fwdRe = /<forward\b[^>]*name\s*=\s*["']([^"']+)["'][^>]*path\s*=\s*["']([^"']+)["'][^>]*\/?>/gi;
      let fm;
      while ((fm = fwdRe.exec(body)) !== null) {
        forwards.push({ name: fm[1], forwardPath: fm[2] });
      }
      if (forwards.length) forwardMap.set(actionPath, forwards);
    }
  }
  return forwardMap;
}

function extractFromMarkup(text) {
  const links = [];
  const seen = new Set();
  const push = (el) => {
    const key = `${el.hrefRaw}|${el.text}`;
    if (!el.hrefRaw || seen.has(key)) return;
    if (ASSET_RE.test(el.hrefRaw)) return;
    if (/^(mailto:|tel:|javascript:)/i.test(el.hrefRaw)) return;
    seen.add(key);
    links.push(el);
  };

  // Anchors with surrounding context; menu detection via container heuristics later.
  const anchorRe = /<a\b([^>]*)>([\s\S]{0,400}?)<\/a>/gi;
  let m;
  while ((m = anchorRe.exec(text)) !== null) {
    const attrs = m[1] || '';
    const inner = m[2] || '';
    const href = (attrs.match(/href\s*=\s*["']([^"']+)["']/i) || [])[1]
      || (attrs.match(/page\s*=\s*["']([^"']+)["']/i) || [])[1] // struts html:link page=
      || (attrs.match(/action\s*=\s*["']([^"']+)["']/i) || [])[1]; // struts link action=
    push({
      hrefRaw: href ? stripTags(href).trim() : '',
      text: stripTags(inner).slice(0, 80),
      title: (attrs.match(/title\s*=\s*["']([^"']*)["']/i) || [])[1] || '',
      inMenu: false,
      kind: 'anchor',
    });
  }

  // Forms
  const formRe = /<form\b[^>]*action\s*=\s*["']([^"']+)["'][^>]*>/gi;
  while ((m = formRe.exec(text)) !== null) {
    push({ hrefRaw: m[1], text: '', title: 'form', inMenu: false, kind: 'form' });
  }

  // JSTL c:url values used as targets
  const curlRe = /<c:url\b[^>]*value\s*=\s*["']([^"']+)["']/gi;
  while ((m = curlRe.exec(text)) !== null) {
    push({ hrefRaw: m[1], text: '', title: 'c:url', inMenu: false, kind: 'jstl' });
  }

  // Vue router-link
  const rlinkRe = /<router-link\b[^>]*to\s*=\s*["']([^"']+)["'][^>]*>([\s\S]{0,200}?)<\/router-link>/gi;
  while ((m = rlinkRe.exec(text)) !== null) {
    push({ hrefRaw: m[1], text: stripTags(m[2]).slice(0, 80), title: '', inMenu: true, kind: 'router-link' });
  }

  // Button / input onclick navigation: location.href, window.location, document.location
  // Use separate regexes for double-quoted (allows ' inside) and single-quoted (allows " inside) attrs
  const onclickReDQ = /<(button)\b([^>]*?)onclick\s*=\s*"([^"]*)"[^>]*>([\s\S]*?)<\/\1>|<(input)\b([^>]*?)onclick\s*=\s*"([^"]*)"[^>]*\/?>/gi;
  while ((m = onclickReDQ.exec(text)) !== null) {
    const isInput = !!m[5];
    const attrs = isInput ? (m[6] || '') : (m[2] || '');
    const handler = isInput ? (m[7] || '') : (m[3] || '');
    const innerText = isInput ? '' : stripTags(m[4] || '');
    const href = (handler.match(/(?:location(?:\.href)?)\s*[=(]\s*["']([^"']+)["']/i) || [])[1]
      || (handler.match(/navigate\s*\(\s*["']([^"']+)["']/i) || [])[1];
    if (!href) continue;
    const label = innerText.trim().slice(0, 80)
      || (attrs.match(/value\s*=\s*["']([^"']*)["']/i) || [])[1]
      || stripTags(handler).slice(0, 80);
    push({ hrefRaw: href, text: label, title: '', inMenu: false, kind: 'onclick' });
  }
  const onclickReSQ = /<(button)\b([^>]*?)onclick\s*=\s*'([^']*)'[^>]*>([\s\S]*?)<\/\1>|<(input)\b([^>]*?)onclick\s*=\s*'([^']*)'[^>]*\/?>/gi;
  while ((m = onclickReSQ.exec(text)) !== null) {
    const isInput = !!m[5];
    const attrs = isInput ? (m[6] || '') : (m[2] || '');
    const handler = isInput ? (m[7] || '') : (m[3] || '');
    const innerText = isInput ? '' : stripTags(m[4] || '');
    const href = (handler.match(/(?:location(?:\.href)?)\s*[=(]\s*["']([^"']+)["']/i) || [])[1]
      || (handler.match(/navigate\s*\(\s*["']([^"']+)["']/i) || [])[1];
    if (!href) continue;
    const label = innerText.trim().slice(0, 80)
      || (attrs.match(/value\s*=\s*["']([^"']*)["']/i) || [])[1]
      || stripTags(handler).slice(0, 80);
    push({ hrefRaw: href, text: label, title: '', inMenu: false, kind: 'onclick' });
  }

  return links;
}

function markMenuContainers(text, links) {
  // Flag links that sit inside menu-ish containers (nav/header/sidebar/menu).
  const containerRe = /<(nav|header|aside)\b[^>]*>([\s\S]*?)<\/\1>/gi;
  const menuChunks = [];
  let cm;
  while ((cm = containerRe.exec(text)) !== null) menuChunks.push(cm[2] || '');
  const idClassRe = /<(\w+)\b[^>]*(?:class|id)\s*=\s*["'][^"']*(?:menu|sidebar|global-nav|gnav|header)[^"']*["'][^>]*>([\s\S]*?)<\/\1>/gi;
  while ((cm = idClassRe.exec(text)) !== null) menuChunks.push(cm[2] || '');
  if (!menuChunks.length) return links;
  const haystack = menuChunks.join('\n');
  for (const link of links) {
    if (link.text && haystack.includes(link.text.slice(0, 40))) link.inMenu = true;
  }
  return links.filter(looksLikeMenu);
}

function extractRoutesFromCode(text) {
  const routes = [];
  const re = /path\s*:\s*["'`]([^"'`\s]+)["'`]([^}]{0,220}?)/g;
  let m;
  while ((m = re.exec(text)) !== null) {
    const tail = m[2] || '';
    const name = (tail.match(/\bname\s*:\s*["'`]([^"'`]+)["'`]/) || [])[1] || '';
    const title = (tail.match(/title\s*:\s*["'`]([^"'`]+)["'`]/) || [])[1]
      || (tail.match(/meta\s*:\s*\{[^}]*title\s*:\s*["'`]([^"`]+)["'`]/) || [])[1] || '';
    routes.push({ routePath: m[1], name: stripTags(name), title: stripTags(title), kind: 'route' });
  }
  // JSX <Route path="..." element={<X />} /> — element name as pseudo-title
  const jsxRe = /<Route\b[^>]*path\s*=\s*["'{]?([^"'\s}]+)["']?[^>]*element\s*=\s*\{?\s*<(\w+)/g;
  while ((m = jsxRe.exec(text)) !== null) {
    routes.push({ routePath: m[1], name: '', title: m[2], kind: 'jsx-route' });
  }
  return routes;
}

function extractPageDirRoutes(projectRoot) {
  const out = [];
  for (const base of ['src/app', 'app', 'src/pages', 'pages']) {
    const dir = path.join(projectRoot, base);
    if (!fs.existsSync(dir)) continue;
    walk(dir, (file) => {
      const base2 = path.basename(file);
      const ext = path.extname(file);
      if (!['.vue', '.tsx', '.ts', '.js', '.jsx'].includes(ext)) return;
      let rel = toPosix(path.relative(dir, file)).replace(/\.(vue|tsx|ts|js|jsx)$/i, '');
      if (base2.startsWith('page.') || base2.startsWith('index.')) {
        rel = toPosix(path.dirname(path.relative(dir, file)));
        if (rel === '.') rel = '';
      } else if (base === 'pages' || base === 'src/pages') {
        // Nuxt classic: file IS the route
      } else {
        return;
      }
      const routePath = '/' + rel;
      const text = readText(file);
      const title = deriveTitle(text);
      const name = path.basename(rel || 'index');
      out.push({ routePath, name, title, kind: 'file-route' });
    });
  }
  return out;
}

function extractJavaMappings(text, rel) {
  const out = [];
  const classLevel = [];
  const clsRe = /@RequestMapping\s*(?:\(\s*)?(?:value\s*=\s*)?["'`]([^"'`]+)["'`]/g;
  let m;
  // crude class-level vs method-level split: reset before each @Controller boundary is overkill;
  // treat every mapping as its own candidate combined with the nearest preceding one.
  const all = [];
  while ((m = clsRe.exec(text)) !== null) all.push(m[1]);
  const getRe = /@(Get|Post|Put|Delete)Mapping\s*(?:\(\s*)?(?:value\s*=\s*)?["'`]([^"'`]+)["'`]/g;
  while ((m = getRe.exec(text)) !== null) {
    all.push(m[2]);
  }
  for (let i = 0; i < all.length; i++) {
    out.push({
      routePath: all[i],
      name: '',
      title: path.basename(rel, '.java'),
      kind: 'java',
    });
  }
  return out;
}

function extractScreenMapPairs(text) {
  // XML <entry key="AA001">/pages/AA001.jsp</entry> style or properties AA001=/...
  const pairs = [];
  let m;
  const xmlKeyRe = /(?:key\s*=\s*["']|<key>|^)\s*([A-Z]{2,5}[-_]?\d{2,6})\s*(?:["'][^>]*>|<\/key>)\s*[,=:]?\s*(?:value\s*=\s*["'])?([^\s"'<>]+)(?:["'])?/gm;
  while ((m = xmlKeyRe.exec(text)) !== null) {
    const value = m[2].trim();
    if (!value || ASSET_RE.test(value) && !/\.(jsp|do|action|html)/i.test(value)) continue;
    pairs.push({ id: m[1], value });
  }
  const propRe = /^\s*([A-Z]{2,5}[-_]?\d{2,6})\s*=\s*(\/?[^\s#]+)\s*$/gm;
  while ((m = propRe.exec(text)) !== null) {
    pairs.push({ id: m[1], value: m[2] });
  }
  return pairs;
}

function deriveTitle(text) {
  const title = (text.match(/<title[^>]*>([\s\S]{0,200}?)<\/title>/i) || [])[1];
  if (title && stripTags(title)) return stripTags(title).slice(0, 80);
  for (const h of ['h1', 'h2', 'h3']) {
    const mh = text.match(new RegExp(`<${h}[^>]*>([\\s\\S]{0,300}?)</${h}>`, 'i'));
    if (mh && stripTags(mh[1])) return stripTags(mh[1]).slice(0, 80);
  }
  return '';
}

// ---------------------------------------------------------------------------
// Candidate building per project
// ---------------------------------------------------------------------------

function collectCandidates(projectRoot) {
  const candidates = [];
  const web = extractWebXmlBits(projectRoot);
  const servletMap = extractServletMappings(projectRoot);

  const forwardMap = extractStrutsForwards(projectRoot);
  const jspToAction = new Map();
  for (const [actionPath, forwards] of forwardMap) {
    for (const fwd of forwards) {
      const fwdPath = fwd.forwardPath.startsWith('/') ? fwd.forwardPath : '/' + fwd.forwardPath;
      jspToAction.set(fwdPath.toLowerCase(), actionPath);
    }
  }

  function resolveJspRoute(jspFile) {
    const rootAbs = path.resolve(projectRoot);
    const fileAbs = path.resolve(jspFile);
    let rel = toPosix(path.relative(rootAbs, fileAbs));
    const webIdx = rel.toLowerCase().indexOf('webapp/');
    if (webIdx >= 0) rel = rel.slice(webIdx + 'webapp/'.length);
    const normalized = '/' + rel;
    const lowerNorm = normalized.toLowerCase();
    if (jspToAction.has(lowerNorm)) return jspToAction.get(lowerNorm);
    for (const [jspKey, urlPattern] of servletMap) {
      if (lowerNorm.endsWith(jspKey.toLowerCase()) || jspKey.toLowerCase().endsWith(lowerNorm)) return urlPattern;
    }
    return null;
  }

  walk(projectRoot, (file) => {
    const ext = path.extname(file).toLowerCase();
    const rel = null; // computed lazily below via closure param
    void rel;

    if (MARKUP_EXTS.has(ext)) {
      const text = readText(file);
      if (!text) return;
      const title = deriveTitle(text);
      const menuLinks = markMenuContainers(text, extractFromMarkup(text));
      const allLinks = extractFromMarkup(text);
      const menuSet = new Set(menuLinks.map(l => l.text + '|' + l.hrefRaw));

      for (const link of allLinks) {
        candidates.push({
          routePath: link.hrefRaw,
          names: [link.text, link.title].filter(Boolean),
          titles: [title].filter(Boolean),
          source: file,
          inMenu: menuSet.has(link.text + '|' + link.hrefRaw),
          stepText: link.text || link.title || '',
          kind: link.kind,
        });
      }
      if (title && web.welcome && /\.x?html?$/i.test(file) === false) {
        const mappedPath = resolveJspRoute(file);
        candidates.push({
          routePath: mappedPath || null,
          jspFile: mappedPath ? null : file,
          names: [title],
          titles: [title],
          source: file,
          inMenu: false,
          stepText: '',
          kind: mappedPath ? 'screen' : 'screen',
        });
      } else if (title) {
        const mappedPath = resolveJspRoute(file);
        candidates.push({
          routePath: mappedPath || null,
          jspFile: mappedPath ? null : file,
          names: [title],
          titles: [title],
          source: file,
          inMenu: false,
          stepText: '',
          kind: 'screen',
        });
      }
      return;
    }

    if (CODE_EXTS.has(ext)) {
      const text = readText(file);
      if (!text) return;
      for (const r of extractRoutesFromCode(text)) {
        candidates.push({
          routePath: r.routePath,
          names: [r.name, r.title].filter(Boolean),
          titles: [],
          source: file,
          inMenu: false,
          stepText: r.title || r.name || '',
          kind: r.kind,
        });
      }
      return;
    }

    if (JAVA_EXTS.has(ext)) {
      const text = readText(file);
      if (!text) return;
      for (const r of extractJavaMappings(text, file)) {
        candidates.push({
          routePath: r.routePath,
          names: [r.title].filter(Boolean),
          titles: [],
          source: file,
          inMenu: false,
          stepText: r.title || '',
          kind: r.kind,
        });
      }
      return;
    }

    if (MAP_EXTS.has(ext)) {
      const text = readText(file);
      if (!text) return;
      for (const pair of extractScreenMapPairs(text)) {
        candidates.push({
          routePath: pair.value,
          names: [pair.id],
          titles: [],
          source: file,
          inMenu: false,
          stepText: '',
          kind: 'screen-map',
        });
      }
    }
  });

  for (const r of extractPageDirRoutes(projectRoot)) {
    candidates.push({
      routePath: r.routePath,
      names: [r.name, r.title].filter(Boolean),
      titles: r.title ? [r.title] : [],
      source: path.join(projectRoot, 'PAGES_DIR'),
      inMenu: false,
      stepText: r.title || r.name || '',
      kind: r.kind,
    });
  }

  // Dedup: if a jsx-route exists for the same component, prefer its path over file-route
  const jsxRouteMap = new Map();
  for (const c of candidates) {
    if (c.kind === 'jsx-route' && c.routePath) {
      const compName = c.names.find(n => n) || c.routePath.split('/').pop() || '';
      const key = normalizeForMatch(compName);
      const basePath = '/' + c.routePath.replace(/^\//, '').split('/').filter(s => !s.startsWith(':') && !s.startsWith('*')).join('/');
      const patched = { ...c, routePath: basePath };
      if (key) jsxRouteMap.set(key, patched);
      const seg = basePath.replace(/^\//, '').split('/')[0] || '';
      if (seg && seg !== key) jsxRouteMap.set(normalizeForMatch(seg), patched);
    }
  }
  if (jsxRouteMap.size) {
    for (const c of candidates) {
      if (c.kind !== 'file-route') continue;
      const cName = normalizeForMatch(c.names.find(n => n) || '');
      const match = jsxRouteMap.get(cName);
      if (match && match.routePath !== c.routePath) {
        c.routePath = match.routePath;
      }
    }
  }

  return { candidates, web, servletMap };
}

function normalizeCandidatePath(cand, projectRoot, ctxRoot) {
  let p = cand.routePath;
  if (p == null && cand.jspFile) {
    const rootAbs = path.resolve(projectRoot);
    const fileAbs = path.resolve(cand.jspFile);
    let rel = toPosix(path.relative(rootAbs, fileAbs));
    // Prefer path under webapp root
    const webIdx = rel.toLowerCase().indexOf('webapp/');
    if (webIdx >= 0) rel = rel.slice(webIdx + 'webapp/'.length);
    else {
      const webInfless = rel.replace(/^(web|public|www)\//i, '');
      rel = webInfless;
    }
    p = '/' + rel;
  }
  if (!p) return '';
  p = String(p).trim();
  if (/^(https?:\/\/|mailto:|tel:|javascript:|#)/i.test(p)) return p;
  if (ASSET_RE.test(p.split('?')[0]) && !/\.(jsp|xhtml|do|action)$/i.test(p)) return '';
  if (!p.startsWith('/')) p = '/' + p;
  if (ctxRoot && ctxRoot !== '/' && !p.toLowerCase().startsWith(ctxRoot.toLowerCase())) {
    p = ctxRoot.replace(/\/$/, '') + p;
  }
  return p;
}

// ---------------------------------------------------------------------------
// Runtime-URL resolution for JSP/Servlet apps
// ---------------------------------------------------------------------------

// Derive the deployed context root from baseUrl's path (e.g. baseUrl
// "http://host:8080/employee-app/login" → "/employee-app"). Empty for
// context-root-less apps like "http://localhost:5173/".
function contextRootFromBase(baseUrl) {
  try {
    const pathname = new URL(baseUrl).pathname.replace(/\/+$/, '');
    const segs = pathname.split('/').filter(Boolean);
    if (segs.length >= 2) return '/' + segs.slice(0, -1).join('/');
  } catch { }
  return '';
}

// Map a source JSP file (from the servlet url-pattern table) to its served
// path including the context root, e.g. employee-form.jsp → "/employee-app/employee/form".
function servedPagePathFor(source, jspUrlIndex, ctxRoot, projectRoot) {
  if (!source || !jspUrlIndex || !jspUrlIndex.size) return '';
  const rootAbs = path.resolve(projectRoot);
  const fileAbs = path.resolve(source);
  let rel = toPosix(path.relative(rootAbs, fileAbs));
  const webIdx = rel.toLowerCase().indexOf('webapp/');
  if (webIdx >= 0) rel = rel.slice(webIdx + 'webapp/'.length);
  const pattern = jspUrlIndex.get('/' + rel.toLowerCase());
  if (!pattern) return '';
  return pattern.startsWith(ctxRoot || '/') ? pattern : (ctxRoot || '') + pattern;
}

// Resolve a raw href the way the browser does: absolute / host-absolute kept,
// site-root kept with context root prepended, relative resolved against the
// directory of the source page's served path.
function resolveRelativeHref(basePath, raw, ctxRoot) {
  if (!raw) return '';
  if (/^(https?:)?\/\//i.test(raw)) return raw;
  if (raw.startsWith('/')) return (ctxRoot || '') + raw;
  if (/^(#|mailto:|tel:|javascript:)/i.test(raw)) return '';
  const baseDir = basePath.substring(0, basePath.lastIndexOf('/')) || '';
  const out = [];
  for (const seg of String(raw).split('/')) {
    if (!seg || seg === '.') continue;
    if (seg === '..') out.pop();
    else out.push(seg);
  }
  if (!out.length) return baseDir;
  return baseDir ? baseDir + '/' + out.join('/') : '/' + out.join('/');
}

// Best-effort resolution of a candidate's runtime URL path:
//   1. JSP "#Screen"/link candidates get their page's served path.
//   2. JSP link candidates resolve their raw href against the source page URL.
//   3. Everything else falls back to the legacy (site-root) normalization.
function resolveCandidatePath(cand, projectRoot, ctxRoot, jspUrlIndex, baseUrl) {
  if (cand.jspFile || (cand.kind === 'screen' && cand.source && /\.jsp$/i.test(cand.source))) {
    const served = servedPagePathFor(cand.source || cand.jspFile, jspUrlIndex, ctxRoot, projectRoot);
    if (served) return served;
  }
  if (cand.routePath && cand.source && /\.jsp$/i.test(cand.source)) {
    const src = servedPagePathFor(cand.source, jspUrlIndex, ctxRoot, projectRoot);
    if (src) {
      const resolved = resolveRelativeHref(src, cand.routePath, ctxRoot);
      if (resolved) return resolved;
    }
  }
  return normalizeCandidatePath(cand, projectRoot, ctxRoot);
}

// ---------------------------------------------------------------------------
// UT case parsing (mirrors parseCases in run-ut.js)
// ---------------------------------------------------------------------------

function parseCases(markdownText) {
  const cleaned = markdownText.replace(/<!--[\s\S]*?-->/g, '');
  const blocks = cleaned.split(/^##\s+/m).filter(Boolean);
  const cases = [];
  for (const block of blocks) {
    const lines = block.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
    const data = {};
    for (const line of lines) {
      if (line.includes(':')) {
        const norm = line.replace(/^-\s*/, '');
        const idx = norm.indexOf(':');
        data[norm.slice(0, idx).trim()] = norm.slice(idx + 1).trim();
      }
    }
    if (data.TestID) cases.push(data);
  }
  return cases;
}

// ---------------------------------------------------------------------------
// Matching + emission
// ---------------------------------------------------------------------------

function scoreCandidate(cand, ctx) {
  const surfaces = [
    ...cand.names.map(t => ({ text: t })),
    ...cand.titles.map(t => ({ text: t })),
    { hrefDecoded: decodeSafe(cand.routePath || '') },
  ];
  let best = -Infinity;
  for (const s of surfaces) {
    const score = scoreLink(Object.assign({ href: cand.routePath || '' }, s), ctx);
    if (score > best) best = score;
  }
  // Menu presence is a mild bonus (menus are how users actually navigate).
  if (cand.inMenu && best > 0) best += 10;
  return best;
}

function decodeSafe(v) {
  try { return decodeURIComponent(String(v)); } catch { return String(v); }
}

// ---------------------------------------------------------------------------
// Multi-step chain building (struts forwards + page-to-page links)
// ---------------------------------------------------------------------------

function buildChainForScreen(targetScreen, keyword, candidates, forwardMap, baseUrl, ctxRoot, projectName, projectRoot, jspUrlIndex) {
  const targetNorm = normalizeForMatch(targetScreen);
  // 1. Find the target page candidate (its name/title matches the TargetScreen)
  // Prefer screen/page candidates (kind='screen' or jspFile) over link candidates.
  // Also prefer candidates whose source file contains the keyword (the actual target page).
  const kwNorm = normalizeForMatch(keyword || '');
  let targetCand = null;
  let bestScore = 0;

  // Pass A: candidates whose source file contains the keyword (or whose name
  // matches) — strongest signal that this is the actual target page. Eligible
  // even if the candidate's surface doesn't substring-match the TargetScreen,
  // since titles often differ ("Add Employee" vs "Add New Employee").
  for (const c of candidates) {
    const isScreen = c.kind === 'screen' || c.jspFile;
    let hasKeyword = false;
    if (kwNorm && c.source) {
      try {
        const srcText = readText(c.source);
        hasKeyword = !!srcText && (srcText.toLowerCase().includes(keyword.toLowerCase()));
      } catch { }
    }
    const surfaces = [...c.names, ...c.titles];
    let surfScore = 0;
    for (const s of surfaces) {
      if (!s) continue;
      const sn = normalizeForMatch(s);
      if (sn === targetNorm || targetNorm.includes(sn) || sn.includes(targetNorm)) surfScore = Math.max(surfScore, sn === targetNorm ? 100 : 50);
    }
    if (isScreen && (hasKeyword || surfScore > 0)) {
      const sc = (hasKeyword ? 300 : 0) + (surfScore || 0) + (isScreen ? 10 : 0);
      if (sc > bestScore) { bestScore = sc; targetCand = c; }
    }
  }

  // Pass B: fall back to any (link) candidate whose surface matches the target.
  if (!targetCand) {
    for (const c of candidates) {
      const surfaces = [...c.names, ...c.titles];
      for (const s of surfaces) {
        if (!s) continue;
        const sn = normalizeForMatch(s);
        if (sn === targetNorm || targetNorm.includes(sn) || sn.includes(targetNorm)) {
          const sc = sn === targetNorm ? 100 : 50;
          if (sc > bestScore) { bestScore = sc; targetCand = c; }
        }
      }
    }
  }
  if (!targetCand) return null;

  const targetPath = resolveCandidatePath(targetCand, projectRoot, ctxRoot, jspUrlIndex, baseUrl)
    || targetCand.routePath;
  if (!targetPath) return null;

  // Helper: resolve a candidate's source file to a normalized URL path
  function sourcePagePath(cand) {
    if (!cand.source) return '';
    return servedPagePathFor(cand.source, jspUrlIndex, ctxRoot || '', projectRoot)
      || normalizeCandidatePath({ routePath: null, jspFile: cand.source }, projectRoot, ctxRoot) || '';
  }

  // Helper: resolve a candidate's href to a normalized URL path
  function hrefPath(cand) {
    return resolveCandidatePath(cand, projectRoot, ctxRoot, jspUrlIndex, baseUrl) || cand.routePath || '';
  }

  // 2. Build a map: pageUrl → [candidates whose href points to that page]
  //    This lets us look up "who links TO page X" efficiently.
  const linksTo = new Map(); // normalized target page URL → [candidate]
  // Also build a set of all page URLs (resolved from candidate sources)
  const pageUrls = new Set();
  for (const c of candidates) {
    const src = sourcePagePath(c);
    if (src) pageUrls.add(src);
    const href = hrefPath(c);
    if (!href || href === src) continue;
    // Check if href points to a known page (exact match or struts forward)
    if (!linksTo.has(href)) linksTo.set(href, []);
    linksTo.get(href).push(c);
  }
  // Add target page to pageUrls
  pageUrls.add(targetPath);

  // Also add struts forward mappings: action href → forward target page
  if (forwardMap.size) {
    for (const [actionPath, forwards] of forwardMap) {
      for (const fwd of forwards) {
        const fwdPath = (fwd.forwardPath.startsWith('/') ? fwd.forwardPath : '/' + fwd.forwardPath);
        const fwdNorm = normalizeForMatch(path.basename(fwdPath));
        // Find candidates linking to this action (with or without .do/.action suffix)
        for (const c of candidates) {
          const hp = hrefPath(c).toLowerCase();
          const aLower = actionPath.toLowerCase().replace(/^\//, '');
          if (hp.endsWith('/' + aLower) || hp.endsWith('/' + aLower + '.do') || hp.endsWith('/' + aLower + '.action')) {
            // This candidate links to the action → it effectively goes to fwdPath
            const resolvedTarget = normalizeCandidatePath({ routePath: fwdPath }, projectRoot, ctxRoot) || fwdPath;
            if (!linksTo.has(resolvedTarget)) linksTo.set(resolvedTarget, []);
            linksTo.get(resolvedTarget).push(c);
          }
        }
      }
    }
  }

  // 3. Walk backwards from target: find a chain of pages leading to target
  const chain = [];
  let currentTarget = targetPath;
  const visitedPages = new Set();

  for (let depth = 0; depth < 3; depth++) {
    if (visitedPages.has(currentTarget)) break;
    visitedPages.add(currentTarget);

    // Find candidates that link TO currentTarget
    const parents = linksTo.get(currentTarget) || [];
    let parentCand = null;
    let parentSourcePage = '';
    // Multiple links from the same page may reach the same target (parallel
    // menu items). Prefer the one whose text best matches the target screen,
    // so the replayed click lands on the intended screen.
    let parentScore = 0;
    for (const c of parents) {
      if (c.kind === 'form' || c.kind === 'jstl') continue;
      const rawStepText = c.stepText || c.names[0] || '';
      if (!isJsxStepText(rawStepText) && !rawStepText) continue;
      const srcPage = sourcePagePath(c);
      if (!srcPage || srcPage === currentTarget || visitedPages.has(srcPage)) continue;
      let score = 1;
      const surfaces = [...c.names, ...c.titles, ...(c.stepText ? [c.stepText] : [])];
      for (const s of surfaces) {
        if (!s) continue;
        const sn = normalizeForMatch(s);
        if (sn === targetNorm) { score = 100; break; }
        if (sn.includes(targetNorm) || targetNorm.includes(sn)) { score = Math.max(score, 50); }
      }
      if (score > parentScore || (score === parentScore && c.inMenu && parentCand && !parentCand.inMenu)) {
        parentScore = score; parentCand = c; parentSourcePage = srcPage;
      }
    }

    if (!parentCand) break;

    // Build step for parentCand
    const rawStepText = parentCand.stepText || parentCand.names[0] || path.basename(hrefPath(parentCand), path.extname(hrefPath(parentCand)));
    const stepText = isJsxStepText(rawStepText) ? '' : rawStepText;
    const directUrl = absUrl(baseUrl, ctxRoot, hrefPath(parentCand));
    chain.unshift({
      kind: 'click',
      from: baseUrl || '',
      href: directUrl || hrefPath(parentCand),
      text: stepText.slice(0, 80),
      tag: parentCand.kind === 'onclick' ? 'button' : 'a',
      index: -1,
      inMenu: parentCand.inMenu || false,
    });

    // Move to the source page of this link
    currentTarget = parentSourcePage;
  }

  if (!chain.length) return null;

  // Add the final step (reaching the target) only when the walk-back chain does
  // not already land on the target page — otherwise the final hop is redundant
  // (a parallel link to the same page is not clickable after the first one).
  const finalDirectUrl = absUrl(baseUrl, ctxRoot, targetPath);
  const lastHref = chain.length ? chain[chain.length - 1].href : '';
  if (chain.length && lastHref && finalDirectUrl && lastHref.split('#')[0] === finalDirectUrl.split('#')[0]) {
    // last chain step already reaches the target page
  } else {
    const rawTargetStepText = targetCand.stepText || targetCand.names[0] || targetScreen;
    const targetStepText = isJsxStepText(rawTargetStepText) ? targetScreen : rawTargetStepText;
    chain.push({
      kind: 'click',
      from: baseUrl || '',
      href: finalDirectUrl || targetPath,
      text: targetStepText.slice(0, 80),
      tag: targetCand.kind === 'onclick' ? 'button' : 'a',
      index: -1,
      inMenu: targetCand.inMenu || false,
    });
  }

  return {
    project: projectName,
    domain: safeOrigin(baseUrl) ? hostnameOf(baseUrl) : '',
    targetScreen,
    normalizedScreen: normalizeForMatch(targetScreen),
    keyword: keyword || '',
    startUrl: baseUrl || '',
    directUrl: finalDirectUrl || targetPath,
    routePath: targetPath,
    steps: chain,
    inMenu: chain.some(s => s.inMenu),
    source: toPosix(path.relative(projectRoot || '', targetCand.source || '')),
    extractedKind: targetCand.kind,
    score: 0,
    generatedAt: new Date().toISOString(),
    chained: true,
  };
}

// Keep only cases whose URL/BaseURL points at the same host+port as this
// project's baseUrl, so no case bleeds into an unrelated project's routes.
function filterCasesForProject(cases, sourceCfg) {
  const base = sourceCfg.baseUrl || '';
  let key = '';
  try {
    const u = new URL(base);
    key = `${u.hostname}|${u.port || (u.protocol === 'https:' ? '443' : '80')}`.toLowerCase();
  } catch { }
  if (!key) return cases.slice();
  return cases.filter(c => {
    for (const f of ['URL', 'BaseURL']) {
      const val = c[f] || '';
      if (!val) continue;
      try {
        const u = new URL(val);
        const k = `${u.hostname}|${u.port || (u.protocol === 'https:' ? '443' : '80')}`.toLowerCase();
        if (k === key) return true;
      } catch { }
    }
    return false;
  });
}

// Remove generated (non-verified, non-recorded) routes of a project whose
// target screen is no longer produced by that project in this run.
function pruneProjectRoutes(rootDir, projectName, keepScreens) {
  if (!projectName) return;
  const config = loadRouteConfig(rootDir);
  if (!config || !Array.isArray(config.routes)) return;
  const keep = new Set(keepScreens);
  const before = config.routes.length;
  config.routes = config.routes.filter(r =>
    (r.project || '') !== projectName || r.verified || r.recorded || keep.has(r.targetScreen));
  if (config.routes.length !== before) {
    config.updatedAt = new Date().toISOString();
    saveRouteConfig(rootDir, config);
    const removed = before - config.routes.length;
    console.log(`  Pruned ${removed} stale route(s) from "${projectName}".`);
  }
}

function generateForProject(sourceCfg, cases, log) {
  const projectRoot = path.resolve(sourceCfg.path);
  if (!fs.existsSync(projectRoot)) {
    log(`project path not found: ${projectRoot}`, 'warn');
    return { matched: [], unmatchedScreens: [] };
  }
  const baseUrl = sourceCfg.baseUrl || '';
  const projectName = sourceCfg.name || path.basename(projectRoot);

  const { candidates, web, servletMap } = collectCandidates(projectRoot);
  const forwardMap = extractStrutsForwards(projectRoot);
  // Prefer the context root implied by baseUrl (deployed apps like
  // ".../employee-app/login"); fall back to web.xml/jboss-web when present and sane.
  const ctxRoot = contextRootFromBase(baseUrl)
    || (web.contextRoot && web.contextRoot.indexOf(' ') < 0 ? web.contextRoot : '');
  log(`${projectName}: ${candidates.length} navigation candidate(s) from sources`);

  const matched = [];
  const unmatchedScreens = [];

  for (const testCase of cases) {
    const targetScreen = testCase.TargetScreen;
    if (!targetScreen) continue;
    const keyword = testCase.Keyword || '';

    const ctx = {
      origin: baseUrl ? safeOrigin(baseUrl) : '',
      tokens: buildSearchTokens(targetScreen, keyword),
      targetNorm: normalizeForMatch(targetScreen),
      kwNorm: normalizeForMatch(keyword),
    };

    let best = null;
    let bestScore = 0;
    for (const cand of candidates) {
      const normPath = resolveCandidatePath(cand, projectRoot, ctxRoot, servletMap, baseUrl);
      if (!normPath) continue;
      const scored = Object.assign({}, cand, { routePath: normPath });
      const score = scoreCandidate(scored, ctx);
      if (score > bestScore) {
        bestScore = score;
        best = scored;
      }
    }

    if (!best || bestScore <= 0) {
      // Try building a multi-step chain via page-to-page links or struts forwards
      const chain = buildChainForScreen(targetScreen, keyword, candidates, forwardMap, baseUrl, ctxRoot, projectName, projectRoot, servletMap);
      if (chain) {
        matched.push(chain);
        const stepCount = chain.steps.length;
        log(`  "${targetScreen}" → ${chain.directUrl} (${stepCount}-step chain, chained)`);
      } else {
        unmatchedScreens.push(targetScreen);
      }
      continue;
    }

    const directUrl = absUrl(baseUrl, ctxRoot, best.routePath);
    const startUrl = baseUrl || '';
    const steps = [];
    if (best.inMenu && best.stepText) {
      const cleanStepText = isJsxStepText(best.stepText) ? '' : best.stepText;
      if (cleanStepText) {
        steps.push({
          kind: 'click',
          from: startUrl,
          href: directUrl,
          text: cleanStepText.slice(0, 80),
          tag: 'a',
          index: -1,
        });
        if (DANGEROUS_TEXT_RE.test(cleanStepText)) {
          log(`"${targetScreen}": step text "${cleanStepText.slice(0, 40)}" matches safety filter — check "Allow Dangerous Clicks" in the UI or set DangerousOk: true in ut_cases.md`, 'warn');
        }
      }
    }

    // If no steps (target found by title/screen match but not reachable via menu),
    // try building a multi-step chain to reach it from the start URL.
    if (!steps.length) {
      const chain = buildChainForScreen(targetScreen, keyword, candidates, forwardMap, baseUrl, ctxRoot, projectName, projectRoot, servletMap);
      if (chain && chain.steps.length) {
        matched.push(chain);
        log(`  "${targetScreen}" → ${chain.directUrl} (${chain.steps.length}-step chain, chained)`);
        continue;
      }
    }

    matched.push({
      project: projectName,
      domain: safeOrigin(baseUrl) ? hostnameOf(baseUrl) : '',
      targetScreen,
      normalizedScreen: normalizeForMatch(targetScreen),
      keyword,
      startUrl,
      directUrl,
      routePath: best.routePath,
      steps,
      inMenu: best.inMenu || false,
      source: toPosix(path.relative(projectRoot, best.source)),
      extractedKind: best.kind,
      score: Math.round(bestScore),
      generatedAt: new Date().toISOString(),
    });
    log(`  "${targetScreen}" → ${directUrl || best.routePath} (${best.kind}, score ${Math.round(bestScore)})`);
    if (!baseUrl) {
      log(`"${targetScreen}": no baseUrl for project "${projectName}" in ${path.basename(SOURCES_FILE)} — route stored as path only and cannot be navigated until you add it.`, 'warn');
    }  }

  return { matched, unmatchedScreens };
}

function safeOrigin(url) {
  try { return new URL(url).origin; } catch { return ''; }
}
function hostnameOf(url) {
  try { return new URL(url).hostname; } catch { return ''; }
}

function loadSources() {
  if (!fs.existsSync(SOURCES_FILE)) return [];
  try {
    const data = JSON.parse(fs.readFileSync(SOURCES_FILE, 'utf8'));
    if (Array.isArray(data)) return data;
    if (Array.isArray(data.sources)) return data.sources;
  } catch (err) {
    console.error(`WARNING: could not parse ${SOURCES_FILE}: ${err.message}`);
  }
  return [];
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

const JSXExpr_RE = /\{[^}]*\}|\$\{[^}]*\}|<[A-Z][^>]*>|useState|useEffect|useRef|v-if|v-for|@click/i;

function isJsxStepText(text) {
  return JSXExpr_RE.test(text || '');
}

function sanitizeRouteSteps(entry) {
  if (!entry.steps || !entry.steps.length) return;
  const hasBad = entry.steps.some(s => isJsxStepText(s.text));
  if (hasBad) {
    const cleanSteps = entry.steps.filter(s => !isJsxStepText(s.text));
    if (cleanSteps.length > 0) {
      entry.steps = cleanSteps;
    } else {
      entry.steps = [];
    }
  }
}

async function main() {
  const rawArgs = process.argv.slice(2);
  let filterProject = '';
  const pjIdx = rawArgs.indexOf('--project');
  if (pjIdx !== -1 && rawArgs[pjIdx + 1]) {
    filterProject = rawArgs[pjIdx + 1].trim();
  }
  const ignored = new Set(pjIdx === -1 ? [] : [pjIdx, pjIdx + 1]);
  const argPaths = rawArgs.filter((a, i) => !ignored.has(i) && !a.startsWith('-'));
  const fileSources = loadSources();

  // CLI paths extend the configured sources (deduped by resolved path).
  const byPath = new Map();
  for (const src of fileSources) {
    if (src && src.path) byPath.set(toPosix(path.resolve(src.path)), src);
  }
  for (const p of argPaths) {
    const key = toPosix(path.resolve(p));
    if (!byPath.has(key)) byPath.set(key, { name: path.basename(key), path: key });
  }
  let sources = Array.from(byPath.values());

  // --project filters sources by configured project name (case-insensitive, substring match).
  if (filterProject) {
    const fp = filterProject.toLowerCase();
    const hit = sources.filter(s => (s.name || '').toLowerCase().includes(fp));
    if (!hit.length) {
      console.error(`No project matches "${filterProject}". Available projects:`);
      for (const s of sources) console.error(`  - ${s.name || path.basename(s.path)}  (${s.path})`);
      console.error(`Pass a project name: node nav-gen.js --project my-app`);
      process.exit(1);
    }
    sources = hit;
    console.log(`Filtering to project(s) matching "${filterProject}".`);
  }

  if (!sources.length) {
    console.error('No project sources configured.');
    console.error(`Add entries to ${path.basename(SOURCES_FILE)}:`);
    console.error('  [ { "name": "my-app", "path": "C:/work/my-app", "baseUrl": "http://localhost:8080/my-app" } ]');
    console.error('Or pass paths: node nav-gen.js C:\\work\\my-app');
    console.error('Or filter configured projects: node nav-gen.js --project employee-app');
    process.exit(1);
  }

  const cases = fs.existsSync(CASE_FILE) ? parseCases(fs.readFileSync(CASE_FILE, 'utf8')) : [];
  const targetScreens = Array.from(new Set(cases.map(c => c.TargetScreen).filter(Boolean)));
  if (!targetScreens.length) {
    console.log('No TargetScreen fields found in ut_cases.md — generating full candidate dump is skipped; nothing to match.');
  }

  const log = (msg, type) => console.log(type === 'warn' ? `WARNING: ${msg}` : msg);

  let totalMatched = 0;
  const allUnmatched = new Set(targetScreens);

  for (const src of sources) {
    log(`\n=== Scanning ${src.name || src.path}: ${src.path} ===`);
    // Only run cases whose URL/BaseURL host+port matches this project's baseUrl,
    // so one case does not produce false-positive routes in unrelated apps.
    const projectCases = filterCasesForProject(cases, src);
    const { matched, unmatchedScreens } = generateForProject(src, projectCases, log);
    for (const entry of matched) {
      sanitizeRouteSteps(entry);
      upsertRouteEntry(ROOT, entry);
      totalMatched++;
      allUnmatched.delete(entry.targetScreen);
    }
    // Prune previously generated routes for this project whose screen is no
    // longer produced by it (e.g. after case→project filtering changes). Keeps
    // verified/browser-recorded routes untouched.
    pruneProjectRoutes(ROOT, src.name, matched.map(m => m.targetScreen));
    for (const screen of unmatchedScreens) {
      // keep only screens no earlier project already matched
    }
  }

  // Second pass: drop unmatched screens that some other project did match.
  const config = loadRouteConfig(ROOT);
  const matchedScreens = new Set((config ? config.routes : []).map(r => r.targetScreen));
  const stillMissing = targetScreens.filter(s => !matchedScreens.has(s));

  // Build a jsx-route map across ALL sources for fixing stale routes
  const globalJsxBasePaths = new Map();
  for (const src of sources) {
    const srcRoot = path.resolve(src.path);
    if (!fs.existsSync(srcRoot)) continue;
    const { candidates } = collectCandidates(srcRoot);
    for (const c of candidates) {
      if (c.kind !== 'jsx-route' || !c.routePath) continue;
      const basePath = '/' + c.routePath.replace(/^\//, '').split('/').filter(s => !s.startsWith(':') && !s.startsWith('*')).join('/');
      const compName = c.names.find(n => n) || '';
      if (basePath && basePath !== '/') {
        const lower = basePath.toLowerCase();
        if (!globalJsxBasePaths.has(lower)) globalJsxBasePaths.set(lower, basePath);
      }
      if (compName) {
        const kn = normalizeForMatch(compName);
        if (kn && !globalJsxBasePaths.has(kn)) globalJsxBasePaths.set(kn, basePath);
      }
    }
    for (const c of candidates) {
      if (c.kind !== 'file-route' || !c.routePath) continue;
      const norm = normalizeForMatch(c.names.find(n => n) || '');
      if (norm && !globalJsxBasePaths.has(norm)) globalJsxBasePaths.set(norm, c.routePath);
    }
  }

  // Post-process: sanitize ALL routes (including previously saved ones)
  let sanitized = 0;
  let fixedUrls = 0;
  if (config && config.routes) {
    for (const route of config.routes) {
      if (route.steps && route.steps.length && route.steps.some(s => isJsxStepText(s.text))) {
        const before = route.steps.length;
        sanitizeRouteSteps(route);
        if (route.steps.length !== before) sanitized++;
      }
      // Fix stale directUrl using jsx-route map.
      // Never touch browser-recorded routes — they are ground truth.
      // Tier 1 (first-segment match) only applies to single-segment paths so
      // deep links like /kanji/n5/lesson-3 are never downgraded to /kanji.
      if (route.directUrl && !route.recorded) {
        try {
          const u = new URL(route.directUrl);
          const urlPath = u.pathname;
          const segs = urlPath.split('/').filter(Boolean);
          let match = null;
          if (segs.length <= 1) {
            match = globalJsxBasePaths.get('/' + (segs[0] || '').toLowerCase());
          }
          if (!match && route.targetScreen) {
            match = globalJsxBasePaths.get(normalizeForMatch(route.targetScreen));
          }
          if (!match && segs.length) {
            match = globalJsxBasePaths.get(normalizeForMatch(segs[segs.length - 1]));
          }
          if (match && match !== urlPath) {
            const oldOrigin = u.origin;
            u.pathname = match;
            route.directUrl = u.toString();
            route.routePath = match;
            if (route.steps) {
              for (const step of route.steps) {
                if (step.href && step.href.startsWith(oldOrigin + urlPath)) {
                  step.href = route.directUrl;
                } else if (step.href && step.href.includes(urlPath)) {
                  step.href = step.href.replace(urlPath, match);
                }
              }
            }
            route.updatedAt = new Date().toISOString();
            fixedUrls++;
          }
        } catch {}
      }
    }
    if (sanitized > 0 || fixedUrls > 0) saveRouteConfig(ROOT, config);
  }

  console.log(`\n=== Summary ===`);
  console.log(`Routes written for ${totalMatched} screen(s) across ${sources.length} project(s).`);
  if (sanitized) console.log(`Sanitized ${sanitized} route(s) with broken JSX step text.`);
  if (fixedUrls) console.log(`Fixed ${fixedUrls} stale route URL(s) using <Route> definitions.`);
  if (stillMissing.length) {
    console.log(`Target screens WITHOUT a generated route:`);
    for (const s of stillMissing) console.log(`  - ${s}`);
    console.log(`Add baseUrl/menu hints or extend the extractors, then re-run: npm run nav:generate`);
  }
  console.log(`Output: ${path.join(ROOT, 'nav-routes.json')}`);
}

main().catch(err => {
  console.error('nav-gen failed:', err.message || err);
  process.exit(1);
});
