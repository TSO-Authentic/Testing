const fs = require('fs');
const path = require('path');

// ---------------------------------------------------------------------------
// Tunables
// ---------------------------------------------------------------------------
const CACHE_MATCH_SIMILARITY = 0.85;

const ASSET_EXT_RE = /\.(png|jpe?g|gif|svg|webp|ico|css|js|mjs|json|xml|zip|pdf|docx?|xlsx?|pptx?|mp[34]|wav|ogg|woff2?|ttf|eot)(?:[?#]|$)/i;
const WORD_SPLIT_RE = /[\s\u3000.,.:：;；、。!！?？'"()[\]{}<>【】「」『』\/\\|_\-·・~〜]+/;
const NON_WORD_RE = /[^a-z0-9\u3040-\u30ff\u31f0-\u31ff\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]/g;

// Keep this literal IN SYNC inside every page.evaluate that queries clickable
// controls (replay locator).
const CLICKABLE_SELECTORS_DOC = 'a[href], button:not([disabled]), [role="link"], [role="button"]:not([disabled]), [data-href], [data-to], [data-url]';

// Controls matching this are never recorded into navigation history and never
// replay-clicked. NOTE: ログイン is deliberately absent — login must stay usable.
const DANGEROUS_TEXT_RE = new RegExp([
  'logout', 'log\\s?out', 'sign\\s?out', 'delete', 'remove', 'destroy',
  'pay', 'purchase', 'checkout',
  'ログアウト', 'ログアウトする', '削除', '消去', '退会', '解約',
  '購入', '注文', '支払', '決済', '有料', '配信停止', '登録解除', 'キャンセル',
].join('|'), 'i');

// ---------------------------------------------------------------------------
// Auto-login helper for route replay
// ---------------------------------------------------------------------------
// When a generated route's startUrl is a login page, tierReplay cannot click
// its steps (they live on the post-login screen). If credentials are supplied
// via opts, detect the password field, fill in the form and submit BEFORE any
// step is replayed.
async function autoLoginOnPage(page, opts) {
  if (!opts || !opts.loginId) return false;
  const looksLikeLogin = await page.evaluate(() => !!document.querySelector('input[type="password"]'));
  if (!looksLikeLogin) return false;

  const idSel = (opts.loginIdSelector || '').trim();
  const pwSel = (opts.passwordSelector || '').trim();
  const btnSel = (opts.loginButtonSelector || '').trim();

  async function findInput(pref, fallbackSel) {
    if (pref) {
      const direct = page.locator(pref).first();
      if (await direct.count().catch(() => 0)) return direct;
      const byName = page.locator(`input[name="${pref}"]`).first();
      if (await byName.count().catch(() => 0)) return byName;
      const byPlaceholder = page.locator(`input[placeholder="${pref}"]`).first();
      if (await byPlaceholder.count().catch(() => 0)) return byPlaceholder;
      const byLabel = page.getByLabel(pref, { exact: false }).first();
      if (await byLabel.count().catch(() => 0)) return byLabel;
    }
    const loc = page.locator(fallbackSel).first();
    return (await loc.count().catch(() => 0)) ? loc : null;
  }

  const idEl = await findInput(idSel, 'input[type="text"], input[type="email"]');
  const pwEl = await findInput(pwSel, 'input[type="password"]');
  if (!idEl || !pwEl) return false;

  await idEl.fill(opts.loginId).catch(() => {});
  await pwEl.fill(opts.loginPassword || '').catch(() => {});

  let btn = null;
  if (btnSel) {
    const b = page.locator(btnSel).first();
    if (await b.count().catch(() => 0)) btn = b;
    else {
      const byRole = page.getByRole('button', { name: btnSel, exact: false }).first();
      if (await byRole.count().catch(() => 0)) btn = byRole;
    }
  }
  if (!btn) {
    const fallback = page.locator('button[type="submit"], input[type="submit"]').first();
    if (await fallback.count().catch(() => 0)) btn = fallback;
  }
  if (btn) await btn.click().catch(() => {});
  else await pwEl.press('Enter').catch(() => {});

  await page.waitForLoadState('load', { timeout: 30000 }).catch(() => {});
  await page.waitForTimeout(1200).catch(() => {});
  return true;
}

// ---------------------------------------------------------------------------
// Pure text normalization / fuzzy matching helpers
// ---------------------------------------------------------------------------

function normalizeForMatch(text) {
  return String(text == null ? '' : text)
    .normalize('NFKC')
    .toLowerCase()
    .replace(/[\s\u3000]+/g, '')
    .replace(/[.,.:：;；、。!！?？'"()[\]{}<>【】「」『』\/\\|_\-·・~〜％%＆&@＠#＃*＊=＝^＾`´’‘“”]/g, '');
}

function stripToWordChars(text) {
  return normalizeForMatch(text).replace(NON_WORD_RE, '');
}

function bigramsOf(text) {
  const s = normalizeForMatch(text);
  if (!s) return [];
  if (s.length === 1) return [s];
  const grams = [];
  for (let i = 0; i < s.length - 1; i++) grams.push(s.slice(i, i + 2));
  return grams;
}

function diceSimilarity(a, b) {
  const ga = bigramsOf(a);
  const gb = bigramsOf(b);
  if (!ga.length || !gb.length) return 0;
  const counts = new Map();
  for (const g of ga) counts.set(g, (counts.get(g) || 0) + 1);
  let overlap = 0;
  for (const g of gb) {
    const n = counts.get(g) || 0;
    if (n > 0) {
      overlap++;
      counts.set(g, n - 1);
    }
  }
  return (2 * overlap) / (ga.length + gb.length);
}

function buildSearchTokens(targetScreen, keyword) {
  const sources = [targetScreen, keyword].filter(v => v && String(v).trim());
  const tokens = new Set();
  for (const src of sources) {
    const norm = normalizeForMatch(src);
    if (norm.length >= 2) tokens.add(norm);
    for (const part of String(src).split(WORD_SPLIT_RE)) {
      const p = normalizeForMatch(part);
      if (p.length >= 2) tokens.add(p);
    }
  }
  return Array.from(tokens);
}

function decodeSafe(value) {
  try {
    return decodeURIComponent(String(value));
  } catch {
    return String(value);
  }
}

function safeOrigin(url) {
  try {
    return new URL(url).origin;
  } catch {
    return '';
  }
}

function hostnameOf(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return '';
  }
}

function normalizeUrlKey(url) {
  return String(url || '').split('#')[0].replace(/\/+$/, '') || '/';
}

// ---------------------------------------------------------------------------
// Link scoring (pure) — reused by nav-gen.js to rank extracted candidates
// ---------------------------------------------------------------------------

// Weights: text +60, aria/title +45, href slug +35, surrounding context +10,
// distinct-token hits x15 (cap 30), CJK-bigram fuzzy similarity up to +25,
// cross-origin -100, asset/protocol links rejected outright.
function scoreLink(link, ctx) {
  const href = String((link && link.href) || '');
  const pathOnly = href.split('#')[0];
  if (ASSET_EXT_RE.test(pathOnly)) return -Infinity;
  if (/^\s*(mailto:|tel:|javascript:)/i.test(href)) return -Infinity;

  const textN = normalizeForMatch(link.text);
  const ariaRaw = [link.ariaLabel, link.title].filter(Boolean).join(' ');
  const ariaN = normalizeForMatch(ariaRaw);
  const hrefSurface = String(link.hrefDecoded || link.href || '');
  const hrefN = stripToWordChars(hrefSurface);
  const contextN = normalizeForMatch(link.context);

  const phrases = [];
  if (ctx.targetNorm) phrases.push(ctx.targetNorm);
  if (ctx.kwNorm && ctx.kwNorm !== ctx.targetNorm) phrases.push(ctx.kwNorm);

  let score = 0;
  let directHit = false;
  for (const ph of phrases) {
    const phSlug = stripToWordChars(ph);
    if (ph && textN.includes(ph)) { score += 60; directHit = true; }
    if (ph && ariaN.includes(ph)) { score += 45; directHit = true; }
    if (ph && phSlug && hrefN.includes(phSlug)) { score += 35; directHit = true; }
    if (ph && contextN.includes(ph)) { score += 10; directHit = true; }
  }

  let tokenHits = 0;
  for (const tok of ctx.tokens || []) {
    if (phrases.includes(tok)) continue;
    if (tok.length < 3) continue;
    const tokSlug = stripToWordChars(tok);
    if (
      textN.includes(tok) ||
      ariaN.includes(tok) ||
      (tokSlug && hrefN.includes(tokSlug)) ||
      contextN.includes(tok)
    ) {
      tokenHits++;
    }
  }
  score += Math.min(tokenHits * 15, 30);

  if (!directHit && phrases.length) {
    const surfaces = [link.text, ariaRaw, link.hrefDecoded || decodeSafe(href), link.context];
    let bestSim = 0;
    for (const ph of phrases) {
      for (const surf of surfaces) {
        if (surf) bestSim = Math.max(bestSim, diceSimilarity(surf, ph));
      }
    }
    if (bestSim >= 0.6) {
      score += Math.min(25, Math.round(((bestSim - 0.6) / 0.4) * 25));
    }
  }

  if (ctx.origin && /^https?:\/\//i.test(href)) {
    try {
      if (new URL(href).origin !== ctx.origin) score -= 100;
    } catch { /* malformed href: no penalty */ }
  }

  return score;
}

function pageConfidence(signals) {
  const s = signals || {};
  const headingHit = s.headingHit ? 1 : 0;
  const keywordHit = s.keywordHit ? 1 : 0;
  const coverage = Math.max(0, Math.min(1, Number(s.tokenCoverage) || 0));
  return 0.5 * headingHit + 0.3 * keywordHit + 0.2 * coverage;
}

// ---------------------------------------------------------------------------
// Navigation knowledge base (navigation-path.json, schema v2)
// ---------------------------------------------------------------------------

function navPathFile(reportDir) {
  return path.join(reportDir, 'navigation-path.json');
}

function readKnowledgeBase(reportDir) {
  const file = navPathFile(reportDir);
  if (!fs.existsSync(file)) return null;
  try {
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (data && data.version === 2 && Array.isArray(data.entries)) return data;
    if (data && data.targetScreen && data.foundUrl) {
      return {
        version: 2,
        entries: [{
          domain: '',
          targetScreen: data.targetScreen,
          normalizedScreen: normalizeForMatch(data.targetScreen),
          keyword: '',
          foundUrl: data.foundUrl,
          path: Array.isArray(data.path) ? data.path : [],
          visited: [],
          totalSteps: data.totalSteps || 0,
          hits: 1,
          updatedAt: data.foundAt || new Date().toISOString(),
        }],
        updatedAt: new Date().toISOString(),
      };
    }
  } catch { /* corrupt file treated as empty */ }
  return null;
}

function matchKbEntry(entry, targetScreen) {
  if (!entry || !entry.foundUrl) return 0;
  if (entry.targetScreen === targetScreen) return 1;
  const entryNorm = normalizeForMatch(entry.normalizedScreen || entry.targetScreen);
  const wantedNorm = normalizeForMatch(targetScreen);
  if (entryNorm && entryNorm === wantedNorm) return 0.95;
  if (entryNorm && wantedNorm) {
    const sim = diceSimilarity(entryNorm, wantedNorm);
    if (sim >= CACHE_MATCH_SIMILARITY) return sim;
  }
  return 0;
}

function loadNavCache(reportDir, targetScreen, send = () => {}) {
  const file = navPathFile(reportDir);
  if (!fs.existsSync(file)) return null;
  let saved = null;
  try {
    saved = JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
  if (!saved) return null;

  if (saved.version === 2 && Array.isArray(saved.entries)) {
    let best = null;
    let bestScore = 0;
    for (const entry of saved.entries) {
      const score = matchKbEntry(entry, targetScreen);
      if (score > bestScore) {
        bestScore = score;
        best = entry;
      }
    }
    if (best) {
      send(`Found saved navigation path for "${best.targetScreen}" — reusing ${best.foundUrl} (${best.hits || 1} previous hit(s))`, 'success');
      return Object.assign({}, best, { version: 2 });
    }
    send(`No trusted cached route for "${targetScreen}".`, 'info');
    return null;
  }

  if (saved.targetScreen === targetScreen && saved.foundUrl) {
    send(`Found saved navigation path for "${targetScreen}" — reusing ${saved.foundUrl}`, 'success');
    return saved;
  }
  if (saved.targetScreen !== targetScreen) {
    send(`Target screen changed ("${saved.targetScreen}" → "${targetScreen}") — ignoring cached navigation path.`, 'warn');
  }
  return null;
}

function saveNavCache(reportDir, data) {
  fs.mkdirSync(reportDir, { recursive: true });
  fs.writeFileSync(navPathFile(reportDir), JSON.stringify(data, null, 2), 'utf8');
}

function upsertKbEntry(kb, entry) {
  const idx = kb.entries.findIndex(e =>
    (e.domain || '') === (entry.domain || '') &&
    matchKbEntry(e, entry.targetScreen) > 0);

  if (idx >= 0) {
    const prev = kb.entries[idx];
    kb.entries[idx] = Object.assign({}, entry, {
      hits: prev.foundUrl === entry.foundUrl ? (prev.hits || 1) + 1 : 1,
    });
  } else {
    kb.entries.push(Object.assign({ hits: 1 }, entry));
  }
  kb.updatedAt = new Date().toISOString();
  return kb;
}

// ---------------------------------------------------------------------------
// Static routes config (nav-routes.json) — generated by nav-gen.js, hand-editable
// ---------------------------------------------------------------------------

function routesFile(rootDir) {
  return path.join(rootDir, 'nav-routes.json');
}

function loadRouteConfig(rootDir) {
  const file = routesFile(rootDir);
  if (!fs.existsSync(file)) return null;
  try {
    const data = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (data && Array.isArray(data.routes)) return data;
  } catch { /* corrupt file treated as empty */ }
  return null;
}

function saveRouteConfig(rootDir, data) {
  fs.writeFileSync(routesFile(rootDir), JSON.stringify(data, null, 2), 'utf8');
}

function matchRouteEntry(entry, targetScreen, wantDomain = '') {
  if (!entry || !(entry.directUrl || entry.foundUrl || entry.routePath)) return 0;
  if (wantDomain) {
    const host = hostnameOf(entry.directUrl || entry.foundUrl || '');
    const port = safeOrigin(entry.startUrl || '');
    const domainHaystack = `${host} ${port ? hostnameOf(port) : ''}`;
    if (domainHaystack && !domainHaystack.includes(String(wantDomain))) return 0;
  }
  if (entry.targetScreen === targetScreen) return 1;
  const entryNorm = normalizeForMatch(entry.normalizedScreen || entry.targetScreen);
  const wantedNorm = normalizeForMatch(targetScreen);
  if (entryNorm && entryNorm === wantedNorm) return 0.95;
  if (entryNorm && wantedNorm) {
    const sim = diceSimilarity(entryNorm, wantedNorm);
    if (sim >= CACHE_MATCH_SIMILARITY) return sim;
  }
  return 0;
}

function findRouteEntry(rootDir, targetScreen, wantDomain = '') {
  const config = loadRouteConfig(rootDir);
  if (!config || !Array.isArray(config.routes)) return null;
  // Recorded routes are ground truth: any matching recorded entry with actual
  // click steps beats all generated ones (they describe HOW to navigate).
  // A bare recorded entry (no steps) is just a URL bookmark, so a generated
  // route with a working click path is preferred over it.
  let best = null;
  let bestScore = 0;
  let bestRecordedSteps = null;
  let bestRecordedStepsScore = 0;
  let bestRecordedBare = null;
  let bestRecordedBareScore = 0;
  for (const entry of config.routes) {
    const score = matchRouteEntry(entry, targetScreen, wantDomain);
    if (score <= 0) continue;
    if (entry.recorded) {
      const steps = Array.isArray(entry.steps) ? entry.steps : [];
      if (steps.length) {
        if (score > bestRecordedStepsScore) {
          bestRecordedStepsScore = score;
          bestRecordedSteps = entry;
        }
      } else if (score > bestRecordedBareScore) {
        bestRecordedBareScore = score;
        bestRecordedBare = entry;
      }
    } else if (score > bestScore) {
      bestScore = score;
      best = entry;
    }
  }
  return bestRecordedSteps || best || bestRecordedBare;
}

/**
 * Merge a generated entry into nav-routes.json.
 * Hand-edited fields survive regeneration: unknown screens are appended,
 * known screens get URL/steps/source refreshed but keep any extra keys
 * (e.g. notes, custom aliases) that generation did not produce.
 */
function upsertRouteEntry(rootDir, entry) {
  const config = loadRouteConfig(rootDir) || { version: 1, updatedAt: '', sources: [], routes: [] };
  const idx = config.routes.findIndex(e =>
    (e.project || '') === (entry.project || '') &&
    matchRouteEntry(e, entry.targetScreen) > 0);

  if (idx >= 0) {
    const prev = config.routes[idx];
    config.routes[idx] = Object.assign({}, prev, entry, {
      verified: prev.directUrl === entry.directUrl ? !!prev.verified : false,
      updatedAt: new Date().toISOString(),
    });
  } else {
    config.routes.push(Object.assign({ verified: false }, entry, { updatedAt: new Date().toISOString() }));
  }
  config.updatedAt = new Date().toISOString();
  saveRouteConfig(rootDir, config);
  return config;
}

// ---------------------------------------------------------------------------
// resolveTargetScreen — cache lookup, then a SINGLE direct goto (no crawling).
// The blind continuous click-search phases were removed by design: navigation
// knowledge lives in nav-routes.json (generated) and navigation-path.json.
// ---------------------------------------------------------------------------

async function resolveTargetScreen(page, reportDir, url, targetScreen, keyword, send = () => {}, opts = {}) {
  // ----- knowledge base lookup (zero navigation on a trusted hit) -----------
  if (!opts.skipCacheLookup) {
    const cachedRoute = loadNavCache(reportDir, targetScreen, send);
    if (cachedRoute && cachedRoute.foundUrl) {
      bumpEntryHits(reportDir, cachedRoute);
      send('Reusing cached route — 0 clicks needed.', 'success');
      return cachedRoute.foundUrl;
    }
  }

  // ----- single direct visit: verify heading + keyword on this one page -----
  try {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: 60000 });
  } catch (err) {
    send(`Start URL unreachable: ${(err.message || String(err)).split('\n')[0]}`, 'warn');
    return null;
  }
  await page.waitForTimeout(2000).catch(() => {});
  await dismissModalOnPage(page, send);

  const startUrl = page.url();

  if (!(await verifyTargetOnPage(page, targetScreen))) {
    send(`Target screen "${targetScreen}" heading not found on ${startUrl}.`, 'warn');
    return null;
  }
  send(`Target screen "${targetScreen}" found in heading`);
  if (!(await verifyKeywordOnPage(page, keyword || ''))) {
    send(`Keyword "${keyword}" not visible on this page.`, 'warn');
    return null;
  }

  const foundUrl = page.url();
  send(`FOUND: "${targetScreen}" + keyword at ${foundUrl}`, 'success');

  try {
    const kb = readKnowledgeBase(reportDir) || { version: 2, entries: [] };
    upsertKbEntry(kb, {
      domain: hostnameOf(foundUrl),
      targetScreen,
      normalizedScreen: normalizeForMatch(targetScreen),
      keyword,
      foundUrl,
      startUrl,
      path: [startUrl, foundUrl],
      steps: [],
      visited: [startUrl],
      totalSteps: 1,
      updatedAt: new Date().toISOString(),
    });
    kb.targetScreen = targetScreen;
    kb.foundUrl = foundUrl;
    saveNavCache(reportDir, kb);
    send(`Navigation path saved (direct visit, no clicks).`, 'success');
  } catch { /* KB bookkeeping is non-fatal */ }

  return foundUrl;
}

// ---------------------------------------------------------------------------
// History reuse: verify saved routes and replay recorded click steps
// ---------------------------------------------------------------------------

function normalizeUrlKeyExport(url) {
  return normalizeUrlKey(url);
}

async function verifyTargetOnPage(page, targetScreen) {
  try {
    return await page.evaluate((target) => {
      const selectors = ['h1', 'h2', 'h3', 'h4', 'h5', 'h6', '[role="heading"]'];
      for (const sel of selectors) {
        const els = document.querySelectorAll(sel);
        for (const el of els) {
          if (el.textContent.trim().toLowerCase().includes(target.toLowerCase())) {
            return true;
          }
        }
      }
      return false;
    }, targetScreen);
  } catch {
    return false;
  }
}

async function verifyKeywordOnPage(page, keyword) {
  try {
    return await page.evaluate((kw) => {
      const normalized = kw.replace(/\s+/g, '');
      return document.body.textContent.replace(/\s+/g, '').includes(normalized);
    }, keyword);
  } catch {
    return false;
  }
}

async function gotoSettled(page, url, timeoutMs = 30000) {
  try {
    await page.goto(url, { waitUntil: 'domcontentloaded', timeout: timeoutMs });
  } catch { /* unreachable / bad URL — stay put */ }
  await page.waitForTimeout(800).catch(() => {});
}

function lowercaseUrlPath(url) {
  try {
    const u = new URL(url);
    u.pathname = u.pathname.split('/').map((seg, i) => i === 0 ? seg : seg.toLowerCase()).join('/');
    return u.href;
  } catch { return url; }
}

async function settleAfterClick(page, prevUrl, maxMs = 4000, settleMs = 400) {
  const deadline = Date.now() + maxMs;
  while (Date.now() < deadline) {
    if (page.url() !== prevUrl) break;
    await page.waitForTimeout(120).catch(() => {});
  }
  await page.waitForTimeout(settleMs).catch(() => {});
}

async function dismissModalOnPage(page, send = () => {}) {
  let modalExists = false;
  try {
    modalExists = await page.evaluate(() => !!(
      document.querySelector('[role="dialog"]') ||
      document.querySelector('[aria-modal="true"]')
    ));
  } catch {
    return false;
  }
  if (!modalExists) return false;

  send(`  Modal detected — dismissing...`);
  await page.keyboard.press('Escape').catch(() => {});
  await page.waitForTimeout(800).catch(() => {});

  for (let stage = 0; stage < 3; stage++) {
    let stillOpen = true;
    try {
      stillOpen = await page.evaluate(() => !!(
        document.querySelector('[role="dialog"]') ||
        document.querySelector('[aria-modal="true"]')
      ));
    } catch {
      return false;
    }
    if (!stillOpen) break;

    await page.evaluate((stageIdx) => {
      const q = (sel) => Array.from(document.querySelectorAll(sel));
      if (stageIdx === 0) {
        const skipBtn = q('button, a').find(el =>
          el.textContent.trim().toLowerCase().includes('skip')
        );
        if (skipBtn) { skipBtn.click(); return; }
      }
      if (stageIdx === 1) {
        const n5Btn = q('button').find(el => el.textContent.includes('N5'));
        if (n5Btn) { n5Btn.click(); return; }
      }
      const closer = q('[role="dialog"] button, [role="dialog"] a, [aria-modal="true"] button, [aria-modal="true"] a').find(el =>
        /^(ok|ok!|はい|close|閉じる|agree|同意|accept|start|開始|later|後で)$/i.test(el.textContent.trim()) ||
        /close|閉じる/i.test(el.getAttribute('aria-label') || '') ||
        el.classList.contains('modal-close') ||
        el.getAttribute('data-dismiss') === 'modal'
      );
      if (closer) closer.click();
    }, stage).catch(() => {});
    await page.waitForTimeout(800).catch(() => {});
  }

  try {
    modalExists = await page.evaluate(() => !!(
      document.querySelector('[role="dialog"]') ||
      document.querySelector('[aria-modal="true"]')
    ));
  } catch {
    return false;
  }

  if (!modalExists) {
    send(`  Modal dismissed`);
    return true;
  }
  return false;
}

async function replayClickStep(page, descriptor, dangerSource, allowDangerous = false) {
  // Playwright's page.evaluate accepts exactly ONE argument — pass a payload object.
  const payload = { desc: descriptor, dangerSource, allowDangerous };
  try {
    return await page.evaluate((input) => {
      // nav-replay-locator
      const desc = input.desc || {};
      const DANGER = new RegExp(input.dangerSource, 'i');
    const selectors = 'a[href], button:not([disabled]), [role="link"], [role="button"]:not([disabled]), [data-href], [data-to], [data-url]';
    const els = document.querySelectorAll(selectors);
    const norm = (t) => String(t || '').split(/\s+/).filter(Boolean).join(' ').toLowerCase();
    const canon = (raw) => { try { return new URL(raw, window.location.href).href; } catch { return ''; } };
    const rawHrefOf = (el) => el.getAttribute('href')
      || el.getAttribute('data-href')
      || el.getAttribute('data-to')
      || el.getAttribute('data-url')
      || '';
    const labelOf = (el) => {
      const a = el.closest('a') || el;
      return [
        a.textContent,
        a.getAttribute('aria-label'),
        a.getAttribute('title'),
        a.getAttribute('value'),
      ].join(' ');
    };

    let wantCanon = '';
    let wantPath = '';
    if (desc.href) {
      wantCanon = canon(desc.href);
      wantPath = wantCanon.split('#')[0].split('?')[0];
    }

    let pick = null;

    if (wantCanon) {
      for (const el of els) {
        const c = canon(rawHrefOf(el));
        if (c && c === wantCanon) { pick = el; break; }
      }
    }
    if (!pick && wantPath) {
      for (const el of els) {
        const c = canon(rawHrefOf(el));
        if (c && c.split('#')[0].split('?')[0] === wantPath) { pick = el; break; }
      }
    }
    if (!pick && wantCanon) {
      let wantDecoded = wantCanon;
      try { wantDecoded = decodeURIComponent(wantCanon); } catch { }
      for (const el of els) {
        const c = canon(rawHrefOf(el));
        if (!c) continue;
        let d = c;
        try { d = decodeURIComponent(c); } catch { }
        if (d === wantDecoded) { pick = el; break; }
      }
    }
    if (!pick && desc.text && desc.text !== '(no text)') {
      for (const el of els) {
        if (norm(labelOf(el)) === norm(desc.text)) { pick = el; break; }
      }
    }
    if (!pick && Number.isInteger(desc.index) && desc.index >= 0) {
      pick = els[desc.index] || null;
    }

    if (!pick) return false;
    if (!input.allowDangerous && DANGER.test(labelOf(pick))) return false;
    pick.click();
    return true;
    }, payload);
  } catch {
    // Locator quirks must degrade to "step missing" so the caller can heal.
    return false;
  }
}

function bumpEntryHits(reportDir, entry) {
  try {
    const kb = readKnowledgeBase(reportDir);
    if (!kb || !Array.isArray(kb.entries)) return;
    const target = kb.entries.find(e =>
      e.foundUrl === entry.foundUrl && e.targetScreen === entry.targetScreen);
    if (!target) return;
    target.hits = (target.hits || 1) + 1;
    target.updatedAt = new Date().toISOString();
    kb.updatedAt = target.updatedAt;
    saveNavCache(reportDir, kb);
  } catch { /* hit-count bookkeeping is non-fatal */ }
}

/**
 * Reuse a saved navigation history for targetScreen.
 * Strategies:
 *   auto   - direct jump to foundUrl, verify; on mismatch replay recorded steps.
 *   direct - direct jump + verification only.
 *   replay - execute recorded steps from startUrl (falls back to direct if none).
 * Returns entry.foundUrl when the history was reused successfully, else null.
 */
async function resolveFromCache(page, reportDir, targetScreen, keyword, send = () => {}, opts = {}) {
  const strategy = ['auto', 'direct', 'replay'].includes(opts.strategy) ? opts.strategy : 'auto';
  const entry = loadNavCache(reportDir, targetScreen, send);
  if (!entry || !entry.foundUrl) {
    send(`No saved navigation history for "${targetScreen}" yet.`);
    return null;
  }
  const steps = Array.isArray(entry.steps) ? entry.steps : [];

  async function verifyHere() {
    if (!(await verifyTargetOnPage(page, targetScreen))) return false;
    if (!keyword) return true;
    return verifyKeywordOnPage(page, keyword);
  }

  async function markReused(message) {
    bumpEntryHits(reportDir, entry);
    send(message, 'success');
  }

  async function tierDirect() {
    send(`History reuse [${strategy}] tier 1: direct jump → ${entry.foundUrl}`);
    await gotoSettled(page, entry.foundUrl);
    await autoLoginOnPage(page, opts);
    await dismissModalOnPage(page, send);
    if (await verifyHere()) {
      await markReused('Direct jump verified against target screen.');
      return true;
    }
    const lowerUrl = lowercaseUrlPath(entry.foundUrl);
    if (lowerUrl !== entry.foundUrl) {
      send(`  Tier 1b: case-insensitive retry → ${lowerUrl}`);
      await gotoSettled(page, lowerUrl);
      await autoLoginOnPage(page, opts);
      await dismissModalOnPage(page, send);
      if (await verifyHere()) {
        await markReused('Direct jump verified via case-insensitive URL.');
        return true;
      }
    }
    send('Direct jump did not match the saved target screen.', 'warn');
    return false;
  }

  async function tierReplay() {
    if (!steps.length) {
      send('Saved history has no recorded click steps — replay unavailable.');
      return false;
    }
    const begin = entry.startUrl
      || (Array.isArray(entry.path) && entry.path.length ? entry.path[0] : '')
      || entry.foundUrl;
    send(`History reuse [${strategy}] tier 2: replaying ${steps.length} step(s) from ${begin}`);
    await gotoSettled(page, begin);
    await autoLoginOnPage(page, opts);
    if (!entry.recorded) await dismissModalOnPage(page, send);

    for (let i = 0; i < steps.length; i++) {
      const st = steps[i] || {};
      const prevUrl = page.url();
      if (st.kind === 'goto' && st.url) {
        await gotoSettled(page, st.url);
      } else {
        const clicked = await replayClickStep(page, {
          href: st.href || '',
          text: st.text || '',
          tag: st.tag || 'a',
          index: typeof st.index === 'number' ? st.index : -1,
        }, DANGEROUS_TEXT_RE.source, opts.allowDangerous);
        if (!clicked) {
          send(`Replay stopped at step ${i + 1}/${steps.length} ("${st.text}") — element missing or unsafe.`, 'warn');
          return false;
        }
        await settleAfterClick(page, prevUrl);
      }
      await dismissModalOnPage(page, send);
      if (await verifyHere()) {
        send(`History verified at step ${i + 1}/${steps.length} — stopping early.`, 'success');
        await markReused(`Replayed history verified (${steps.length} step(s)) at step ${i + 1} — stopping early.`);
        return true;
      }
    }

    if (await verifyHere()) {
      await markReused(`Replayed history verified (${steps.length} step(s)).`);
      return true;
    }
    send('Replayed route did not land on the saved target screen.', 'warn');
    return false;
  }

  let reused = false;
  if (strategy === 'direct') {
    reused = await tierDirect();
  } else if (strategy === 'replay') {
    reused = steps.length ? await tierReplay() : await tierDirect();
  } else {
    reused = entry.recorded
      ? (await tierReplay()) || (await tierDirect())
      : (await tierDirect()) || (await tierReplay());
  }

  if (!reused) {
    send(`Saved navigation history unusable for "${targetScreen}".`, 'warn');
    return null;
  }
  return entry.foundUrl;
}

/**
 * Resolve a target screen from the GENERATED routes config (nav-routes.json).
 * Same tier model as resolveFromCache: direct jump to directUrl/foundUrl,
 * fallback replay of the recorded click steps. Never crawls: on failure the
 * caller is expected to surface an error telling the user to regenerate.
 * Marks the matched entry verified=true on success.
 */
async function resolveRouteConfig(page, rootDir, targetScreen, keyword, send = () => {}, opts = {}) {
  const strategy = ['auto', 'direct', 'replay'].includes(opts.strategy) ? opts.strategy : 'auto';
  const entry = findRouteEntry(rootDir, targetScreen, opts.domain || '');
  if (!entry) {
    send(`No generated route for "${targetScreen}" in nav-routes.json.`);
    return null;
  }

  const landingUrl = entry.directUrl || entry.foundUrl || '';
  if (!landingUrl) {
    send(`Generated route for "${targetScreen}" has no URL.`, 'warn');
    return null;
  }
  const steps = Array.isArray(entry.steps) ? entry.steps : [];

  async function verifyHere() {
    if (!(await verifyTargetOnPage(page, targetScreen))) return false;
    if (!keyword) return true;
    return verifyKeywordOnPage(page, keyword);
  }

  function persistVerified(message) {
    try {
      const config = loadRouteConfig(rootDir);
      if (!config) return;
      const idx = config.routes.findIndex(e => e === entry ||
        ((e.project || '') === (entry.project || '') && matchRouteEntry(e, entry.targetScreen) > 0));
      if (idx < 0) return;
      config.routes[idx].verified = true;
      config.routes[idx].foundUrl = page.url();
      config.routes[idx].hits = (config.routes[idx].hits || 0) + 1;
      config.routes[idx].updatedAt = new Date().toISOString();
      config.updatedAt = config.routes[idx].updatedAt;
      saveRouteConfig(rootDir, config);
    } catch { /* verification bookkeeping is non-fatal */ }
    send(message, 'success');
  }

  async function tierDirect() {
    send(`Generated route [${strategy}] tier 1: direct jump → ${landingUrl}`);
    await gotoSettled(page, landingUrl);
    await autoLoginOnPage(page, opts);
    await dismissModalOnPage(page, send);
    if (await verifyHere()) {
      persistVerified('Generated route verified against target screen.');
      return true;
    }
    const lowerUrl = lowercaseUrlPath(landingUrl);
    if (lowerUrl !== landingUrl) {
      send(`  Tier 1b: case-insensitive retry → ${lowerUrl}`);
      await gotoSettled(page, lowerUrl);
      await autoLoginOnPage(page, opts);
      await dismissModalOnPage(page, send);
      if (await verifyHere()) {
        persistVerified('Generated route verified via case-insensitive URL.');
        return true;
      }
    }
    send('Generated route direct URL did not match the target screen.', 'warn');
    return false;
  }

  async function tierReplay() {
    if (!steps.length) {
      send('Generated route has no recorded click steps — replay unavailable.');
      return false;
    }
    const begin = entry.startUrl || landingUrl;
    send(`Generated route [${strategy}] tier 2: replaying ${steps.length} step(s) from ${begin}`);
    await gotoSettled(page, begin);
    await autoLoginOnPage(page, opts);
    if (!entry.recorded) await dismissModalOnPage(page, send);

    for (let i = 0; i < steps.length; i++) {
      const st = steps[i] || {};
      const prevUrl = page.url();
      if (st.kind === 'goto' && st.url) {
        await gotoSettled(page, st.url);
      } else {
        const clicked = await replayClickStep(page, {
          href: st.href || '',
          text: st.text || '',
          tag: st.tag || 'a',
          index: typeof st.index === 'number' ? st.index : -1,
        }, DANGEROUS_TEXT_RE.source, opts.allowDangerous);
        if (!clicked) {
          send(`Route replay stopped at step ${i + 1}/${steps.length} ("${st.text}") — element missing or unsafe.`, 'warn');
          return false;
        }
        await settleAfterClick(page, prevUrl);
      }
      await dismissModalOnPage(page, send);
      if (await verifyHere()) {
        send(`Generated route verified at step ${i + 1}/${steps.length} — stopping early.`, 'success');
        persistVerified(`Generated route verified at step ${i + 1}/${steps.length}.`);
        return true;
      }
    }

    if (await verifyHere()) {
      persistVerified(`Generated route verified via replayed steps (${steps.length}).`);
      return true;
    }
    send('Generated route replay did not land on the target screen.', 'warn');
    return false;
  }

  let ok = false;
  if (strategy === 'direct') {
    ok = await tierDirect();
  } else if (strategy === 'replay') {
    ok = steps.length ? await tierReplay() : await tierDirect();
  } else {
    ok = entry.recorded
      ? (await tierReplay()) || (await tierDirect())
      : (await tierDirect()) || (await tierReplay());
  }

  if (!ok) {
    const src = entry.source ? ` (extracted from ${entry.source})` : '';
    send(`Generated route unusable for "${targetScreen}"${src} — regenerate with: npm run nav:generate`, 'warn');
    return null;
  }
  // The verified landing spot wins over the (possibly stale) configured URL —
  // replayed steps may end somewhere different from directUrl.
  return page.url();
}

module.exports = {
  navPathFile,
  routesFile,
  DANGEROUS_TEXT_RE,
  loadNavCache,
  saveNavCache,
  loadRouteConfig,
  saveRouteConfig,
  findRouteEntry,
  matchRouteEntry,
  upsertRouteEntry,
  resolveTargetScreen,
  resolveFromCache,
  resolveRouteConfig,
  normalizeForMatch,
  buildSearchTokens,
  diceSimilarity,
  scoreLink,
  pageConfidence,
  normalizeUrlKey: normalizeUrlKeyExport,
};
