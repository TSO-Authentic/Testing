import json
import re
import sys
import zipfile
from datetime import datetime
from pathlib import Path

import xlsxwriter
from PIL import Image, ImageChops
from xlsxwriter.exceptions import FileCreateError

ROOT = Path(__file__).resolve().parent
REPORT_DIR = ROOT / 'ut-report'
SCREENSHOT_DIR = REPORT_DIR / 'screenshots'
REPORT_JSON = REPORT_DIR / 'ut_report.json'
CASE_FILE = ROOT / 'ut_cases.md'
BROWSERS = ['Chrome', 'Edge', 'Firefox']

DISPLAY_WIDTH = 1414
DISPLAY_HEIGHT = 868
VIEWPORT_WIDTH = 1440
VIEWPORT_HEIGHT = 900
BOX_SHADOW_PX = 3

ANNOTATION_COLOR = '#C00000'
ANNOTATION_LINE_WIDTH = 2.25  # 2¼ pt (per ai.txt)
PADDING = 5

RED_MIN = 140
MAX_OTHER = 80
MIN_PIXELS = 300

# Layout A: one case per section on a 16-column grid (~180 px per column).
GRID_COLS = 16
GRID_COL_WIDTH = 25            # ≈ 180 px -> ~2880 px canvas
HALF_SPLIT_COL = 8             # left half cols 0-7 | right half cols 8-15
LEFT_IMG_X = 10                # px offset of before screenshot inside col 0
RIGHT_IMG_X = 14               # px offset of after screenshot inside col 8
IMG_Y_PAD = 4                  # px padding above screenshots in the band
BAND_ROWS = 11                 # rows reserved for the screenshot band
BAND_ROW_PT = 60               # band row height in points (~80 px)


def load_results():
    if not REPORT_JSON.exists():
        raise FileNotFoundError(f'Results file not found: {REPORT_JSON}. Run `node run-ut.js` first.')
    with open(REPORT_JSON, 'r', encoding='utf-8') as fh:
        return json.load(fh)


def _strip_html_comments(text):
    return re.sub(r'<!--[\s\S]*?-->', '', text)


CASE_FIELDS = ('Keyword', 'TargetScreen', 'PartialText', 'AfterPartialText', 'BeforeText', 'AfterText', 'ExpectedResult')


def load_case_fields():
    if not CASE_FILE.exists():
        return {}
    case_fields = {}
    with open(CASE_FILE, 'r', encoding='utf-8') as fh:
        content = fh.read()
    content = _strip_html_comments(content)
    test_id = None
    for line in content.splitlines():
        stripped = line.strip()
        if stripped.startswith('## '):
            test_id = stripped[3:].strip()
        elif stripped.startswith('- TestID:'):
            test_id = stripped[len('- TestID:'):].strip()
        elif test_id:
            for field in CASE_FIELDS:
                prefix = f'- {field}:'
                if stripped.startswith(prefix):
                    case_fields.setdefault(test_id, {})[field] = stripped[len(prefix):].strip()
    return case_fields


def _red_mask(img):
    r = img.getchannel('R').point(lambda p: 255 if p >= RED_MIN else 0)
    g = img.getchannel('G').point(lambda p: 255 if p <= MAX_OTHER else 0)
    b = img.getchannel('B').point(lambda p: 255 if p <= MAX_OTHER else 0)
    return ImageChops.multiply(ImageChops.multiply(r, g), b)


def detect_box(clean_path, annot_path, clean_img=None, annot_img=None):
    """Locate the red annotation outline in native screenshot pixels.

    Returns (x, y, width, height) or None. The annotated screenshot differs
    from the clean one only by the boxShadow highlight, so the diff of the
    red masks isolates exactly the outline.
    """
    try:
        clean = clean_img if clean_img is not None else Image.open(clean_path).convert('RGB')
        annot = annot_img if annot_img is not None else Image.open(annot_path).convert('RGB')
    except OSError as exc:
        print(f'  WARNING: could not open screenshots for detection: {exc}')
        return None

    try:
        return _detect_box_impl(clean, annot)
    finally:
        if clean_img is None:
            clean.close()
        if annot_img is None:
            annot.close()


def _detect_box_impl(clean, annot):
    if annot.size != clean.size:
        # Layout width differs (classic scrollbar toggled between captures).
        # Left-align: the page margins are fixed, so the left edge matches and
        # the diff still isolates the outline. Resizing would distort positions.
        w = min(clean.width, annot.width)
        h = min(clean.height, annot.height)
        annot = annot.crop((0, 0, w, h))
        clean = clean.crop((0, 0, w, h))

    m_clean = _red_mask(clean)
    m_annot = _red_mask(annot)
    diff = ImageChops.subtract(m_annot, m_clean)

    if diff.histogram()[255] < MIN_PIXELS:
        return None

    bbox = diff.getbbox()
    if not bbox:
        return None

    x0, y0, x1, y1 = bbox
    width, height = annot.size
    if (x1 - x0) > width * 0.9 or (y1 - y0) > height * 0.9:
        return None

    x = max(0, x0 - PADDING)
    y = max(0, y0 - PADDING)
    w = min(width - x, (x1 - x0) + 2 * PADDING)
    h = min(height - y, (y1 - y0) + 2 * PADDING)
    return x, y, w, h


def _red_mask(rgb_img):
    r = rgb_img.getchannel('R').point(lambda p: 255 if p >= 140 else 0)
    g = rgb_img.getchannel('G').point(lambda p: 255 if p <= 80 else 0)
    b = rgb_img.getchannel('B').point(lambda p: 255 if p <= 80 else 0)
    return ImageChops.multiply(ImageChops.multiply(r, g), b)


def _calibrate_offset(annot_img, clean_img, runner_box, naive_cx, naive_cy):
    """Localize the red annotation outline near the expected position
    and return the corrected (chrome_offset_x, chrome_offset_y).

    Uses runner_box + naive offsets to predict where the outline should be,
    then searches only in a narrow band (±40 px vertically).
    Falls back to naive values if detection fails.
    """
    expected_outline_top = runner_box['y'] + naive_cy - BOX_SHADOW_PX
    expected_outline_left = runner_box['x'] + naive_cx - BOX_SHADOW_PX
    box_h = runner_box.get('height', 20)
    band_top = max(0, int(expected_outline_top - 40))
    band_bot = min(annot_img.height, int(expected_outline_top + box_h + 40 + 2 * BOX_SHADOW_PX))
    band_left = max(0, int(expected_outline_left - 40))
    band_right = min(annot_img.width, int(expected_outline_left + runner_box.get('width', 60) + 40 + 2 * BOX_SHADOW_PX))

    if annot_img.size != clean_img.size:
        w = min(clean_img.width, annot_img.width)
        h = min(clean_img.height, annot_img.height)
        ac = annot_img.crop((0, 0, w, h)).convert('RGB')
        cc = clean_img.crop((0, 0, w, h)).convert('RGB')
    else:
        ac = annot_img.convert('RGB')
        cc = clean_img.convert('RGB')

    diff = ImageChops.subtract(_red_mask(ac), _red_mask(cc))
    ac.close()
    cc.close()

    full_bbox = diff.getbbox()
    if not full_bbox:
        return naive_cx, naive_cy

    dx0, dy0, dx1, dy1 = full_bbox
    outline_h = dy1 - dy0
    outline_w = dx1 - dx0
    exp_w = runner_box.get('width', 60) + 2 * BOX_SHADOW_PX
    exp_h = runner_box.get('height', 20) + 2 * BOX_SHADOW_PX
    tol_w = max(exp_w * 0.75, 40)
    tol_h = max(exp_h * 1.5, 30)
    if abs(outline_w - exp_w) > tol_w or abs(outline_h - exp_h) > tol_h:
        return naive_cx, naive_cy
    if outline_w > annot_img.width * 0.95 or outline_h > annot_img.height * 0.95:
        return naive_cx, naive_cy

    if dy0 < band_top or dy0 > band_bot:
        return naive_cx, naive_cy
    if dx0 < band_left or dx0 > band_right:
        return naive_cx, naive_cy

    return dx0 - runner_box['x'] + BOX_SHADOW_PX, dy0 - runner_box['y'] + BOX_SHADOW_PX


def _viewport_chrome_offsets(img_width, img_height, viewport):
    try:
        vw = int(viewport.get('innerWidth'))
        vh = int(viewport.get('innerHeight'))
    except (TypeError, ValueError, AttributeError):
        vw, vh = VIEWPORT_WIDTH, VIEWPORT_HEIGHT
    if vw <= 0 or vh <= 0 or vw > img_width or vh > img_height:
        vw, vh = VIEWPORT_WIDTH, VIEWPORT_HEIGHT
    return img_width - vw, img_height - vh


def _viewport_for(case, idx):
    vp = case.get('ViewportAfter') if idx == 1 else None
    if not vp:
        vp = case.get('ViewportBefore')
    return vp or {}


def draw_case_images(ws, case, band_row):
    """Insert before/after screenshots side by side inside the image band
    that starts at `band_row`, and draw the red annotation boxes on top."""
    screenshots = case.get('Screenshots', [])
    annotated = case.get('Annotated', [])
    runner_boxes = [case.get('BeforeAnnotationBox'), case.get('AfterAnnotationBox')]
    anchors = [(0, LEFT_IMG_X), (HALF_SPLIT_COL, RIGHT_IMG_X)]
    shots = [screenshots[0] if len(screenshots) > 0 else None,
             screenshots[1] if len(screenshots) > 1 else None]
    annots = [annotated[0] if len(annotated) > 0 else None,
              annotated[1] if len(annotated) > 1 else None]

    for idx, ((col, x_off), shot, annot, runner_box) in enumerate(zip(anchors, shots, annots, runner_boxes)):
        if not shot or not Path(shot).exists():
            continue

        img = Image.open(shot)
        x_scale = DISPLAY_WIDTH / img.width
        y_scale = DISPLAY_HEIGHT / img.height

        ws.insert_image(band_row, col, str(shot), {
            'x_offset': x_off,
            'y_offset': IMG_Y_PAD,
            'x_scale': x_scale,
            'y_scale': y_scale,
        })

        naive_cx, naive_cy = _viewport_chrome_offsets(img.width, img.height, _viewport_for(case, idx))

        chrome_offset_x = naive_cx
        chrome_offset_y = naive_cy
        if runner_box and annot and Path(annot).exists():
            annot_img = Image.open(annot)
            clean_img = Image.open(shot)
            chrome_offset_x, chrome_offset_y = _calibrate_offset(annot_img, clean_img, runner_box, naive_cx, naive_cy)
            annot_img.close()
            clean_img.close()

        box = None
        if runner_box and 'x' in runner_box and 'width' in runner_box:
            box = (runner_box['x'] + chrome_offset_x - BOX_SHADOW_PX,
                   runner_box['y'] + chrome_offset_y - BOX_SHADOW_PX,
                   runner_box['width'] + 2 * BOX_SHADOW_PX,
                   runner_box['height'] + 2 * BOX_SHADOW_PX)
        elif annot and Path(annot).exists():
            box = detect_box(shot, annot)

        if box:
            x, y, w, h = box
            ws.insert_textbox(band_row, col, '', {
                'x_offset': x_off + int(x * x_scale),
                'y_offset': IMG_Y_PAD + int(y * y_scale),
                'width': int(max(1, w * x_scale)),
                'height': int(max(1, h * y_scale)),
                'line': {'color': ANNOTATION_COLOR, 'width': ANNOTATION_LINE_WIDTH},
                'fill': {'none': True},
            })
        else:
            print(f'  WARNING: no annotation box for {Path(shot).name}')
        img.close()


def _patch_shape_types(file_path):
    """Convert the rectangle shapes from TextBox-style into native Rectangle
    autoshapes (xlsxwriter's insert_textbox API marks them as text boxes)."""
    with zipfile.ZipFile(file_path, 'r') as zin:
        entries = zin.namelist()
        blobs = {name: zin.read(name) for name in entries}
    for name in entries:
        if re.match(r'xl/drawings/drawing\d+\.xml$', name):
            xml = blobs[name].decode('utf-8')
            xml = re.sub(r'<xdr:cNvSpPr txBox="1"/>', '<xdr:cNvSpPr/>', xml)
            xml = re.sub(r'name="TextBox ', 'name="Rectangle ', xml)
            blobs[name] = xml.encode('utf-8')
    with zipfile.ZipFile(file_path, 'w', zipfile.ZIP_DEFLATED) as zout:
        for name in entries:
            zout.writestr(name, blobs[name])


def build_workbook(browser_name, cases):
    file_path = ROOT / f'画面エビデンス_{browser_name}.xlsx'
    wb = xlsxwriter.Workbook(str(file_path))
    ws = wb.add_worksheet(browser_name)
    ws.hide_gridlines(2)
    ws.set_zoom(85)

    for col_idx in range(GRID_COLS):
        ws.set_column(col_idx, col_idx, GRID_COL_WIDTH)

    title = wb.add_format({
        'font_size': 16, 'bold': 1, 'align': 'center', 'valign': 'vcenter',
        'bg_color': '#D9EAF7',
    })
    date_fmt = wb.add_format({
        'italic': 1, 'align': 'right', 'valign': 'vcenter',
    })
    label_fmt = wb.add_format({
        'bold': 1, 'align': 'left', 'valign': 'vcenter', 'indent': 1,
        'bg_color': '#D9EAF7', 'border': 1, 'border_color': '#BFBFBF',
    })
    value_fmt = wb.add_format({
        'align': 'left', 'valign': 'vcenter', 'text_wrap': 1, 'indent': 1,
        'border': 1, 'border_color': '#BFBFBF',
    })
    section_hdr = wb.add_format({
        'bold': 1, 'align': 'center', 'valign': 'vcenter',
        'bg_color': '#E2F0D9', 'border': 1, 'border_color': '#BFBFBF',
    })
    caption_fmt = wb.add_format({
        'italic': 1, 'align': 'left', 'valign': 'vcenter', 'indent': 1,
        'border': 1, 'border_color': '#BFBFBF',
    })
    note_fmt = wb.add_format({
        'align': 'left', 'valign': 'top', 'text_wrap': 1,
        'border': 1, 'border_color': '#BFBFBF',
    })
    red_text = wb.add_format({'font_color': ANNOTATION_COLOR, 'bold': 1})
    pass_fmt = wb.add_format({
        'bold': 1, 'font_color': '#006100', 'bg_color': '#C6EFCE',
        'align': 'center', 'valign': 'vcenter', 'border': 1, 'border_color': '#BFBFBF',
    })
    error_fmt = wb.add_format({
        'bold': 1, 'font_color': '#9C0006', 'bg_color': '#FFC7CE',
        'align': 'center', 'valign': 'vcenter', 'border': 1, 'border_color': '#BFBFBF',
    })

    date_str = datetime.now().strftime('%Y/%m/%d')

    ws.set_row(0, 30)
    ws.merge_range(0, 0, 0, GRID_COLS - 1, f'UT画面エビデンス_{browser_name}', title)
    ws.set_row(1, 18)
    ws.merge_range(1, GRID_COLS - 4, 1, GRID_COLS - 1, f'作成日: {date_str}', date_fmt)

    case_fields = load_case_fields()

    def write_meta_row(r, l1, v1, l2, v2, v2_fmt=value_fmt):
        ws.merge_range(r, 0, r, 1, l1, label_fmt)
        ws.merge_range(r, 2, r, 6, v1, value_fmt)
        ws.merge_range(r, 7, r, 8, l2, label_fmt)
        ws.merge_range(r, 9, r, GRID_COLS - 1, v2, v2_fmt)
        ws.set_row(r, 22)

    row = 3
    for case in cases:
        fields = case_fields.get(case.get('TestID', ''), {})
        status = case.get('Status', '')
        status_fmt = pass_fmt if status == 'PASS' else (error_fmt if status == 'ERROR' else value_fmt)

        kw_before = fields.get('PartialText') or fields.get('BeforeText') or fields.get('Keyword') or ''
        kw_after = fields.get('AfterPartialText') or fields.get('AfterText') or ''
        is_partial_pair = bool(kw_before) and bool(kw_after) and kw_before != kw_after

        # --- metadata grid ---
        write_meta_row(row, 'Test ID', case.get('TestID', ''), 'Browser', case.get('Browser', ''))
        row += 1
        write_meta_row(row, 'Target Screen', fields.get('TargetScreen', ''),
                       '確認項目 / Verification Item', 'Text change verification')
        row += 1
        write_meta_row(row, '修正内容 / Modification', case.get('Description', ''), 'Keyword', '')
        if is_partial_pair:
            ws.write_rich_string(row, 9, red_text, kw_before, ' → ', red_text, kw_after, value_fmt)
        else:
            ws.write(row, 9, kw_after or kw_before, value_fmt)
        row += 1
        write_meta_row(row, '判定 / Result', status, '実施日 / Date', date_str, v2_fmt=value_fmt)
        ws.write(row, 2, status, status_fmt)
        row += 1

        expected = case.get('ExpectedResult') or fields.get('ExpectedResult', '')
        user_status = case.get('UserStatus', '')
        user_fmt = pass_fmt if user_status == 'PASS' else (error_fmt if user_status == 'FAIL' else value_fmt)
        write_meta_row(row, '期待結果 / Expected Result', expected,
                       'ユーザー判定 / User Verdict', user_status, v2_fmt=user_fmt)
        row += 1

        # --- section headers ---
        ws.merge_range(row, 0, row, HALF_SPLIT_COL - 1, '修正前画面 (Before)', section_hdr)
        ws.merge_range(row, HALF_SPLIT_COL, row, GRID_COLS - 1, '修正後画面 (After)', section_hdr)
        ws.set_row(row, 20)
        row += 1

        # --- image band (screenshots + red boxes float over these rows) ---
        band_top = row
        draw_case_images(ws, case, band_top)
        for i in range(BAND_ROWS):
            ws.set_row(band_top + i, BAND_ROW_PT)
        row = band_top + BAND_ROWS

        # --- captions under each screen ---
        cap_left = f'変更前: "{kw_before}"' if kw_before else ''
        cap_right = f'変更後: "{kw_after}"' if kw_after else ''
        ws.merge_range(row, 0, row, HALF_SPLIT_COL - 1, cap_left, caption_fmt)
        ws.merge_range(row, HALF_SPLIT_COL, row, GRID_COLS - 1, cap_right, caption_fmt)
        ws.set_row(row, 18)
        row += 1

        # --- notes ---
        engine_label = case.get('Engine') or ''
        notes_text = f'備考 / Notes: Captured with {engine_label}.' if engine_label else '備考 / Notes:'
        ws.merge_range(row, 0, row, GRID_COLS - 1, notes_text, note_fmt)
        ws.set_row(row, 24)
        row += 1

        # gap between cases
        ws.set_row(row, 12)
        row += 1

    wb.close()
    _patch_shape_types(file_path)
    return file_path


def main():
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')

    results = load_results()
    grouped = {browser: [] for browser in BROWSERS}
    for case in results:
        browser = case.get('Browser', '')
        if browser in grouped:
            grouped[browser].append(case)

    for browser in BROWSERS:
        if not grouped[browser]:
            print(f'Skipped {browser}: no results in {REPORT_JSON}')
            continue
        try:
            output = build_workbook(browser, grouped[browser])
        except (PermissionError, FileCreateError) as exc:
            print(f'WARNING: {exc}. Close the workbook in Excel and re-run `python generate_evidence.py`.')
            continue
        print(f'Created: {output}')


if __name__ == '__main__':
    main()
