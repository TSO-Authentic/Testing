param(
    [Parameter(Mandatory = $true)][string]$ProcessName,
    [Parameter(Mandatory = $false)][string]$StartTime,
    [Parameter(Mandatory = $false)][int]$ExpectedX,
    [Parameter(Mandatory = $false)][int]$ExpectedY,
    [Parameter(Mandatory = $true)][string]$OutFile
)

$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class Win32Capture {
    [DllImport("user32.dll")]
    public static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);
    [DllImport("user32.dll")]
    public static extern bool PrintWindow(IntPtr hWnd, IntPtr hdcBlt, uint nFlags);
    [DllImport("user32.dll")]
    public static extern bool IsWindowVisible(IntPtr hWnd);
    [DllImport("user32.dll")]
    public static extern bool IsIconic(IntPtr hWnd);
    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);
    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
    [DllImport("user32.dll")]
    public static extern bool BringWindowToTop(IntPtr hWnd);
    [DllImport("user32.dll")]
    public static extern uint GetWindowThreadProcessId(IntPtr hWnd, out uint lpdwProcessId);
    [DllImport("user32.dll")]
    public static extern bool EnumWindows(EnumWindowsProc lpEnumFunc, IntPtr lParam);
    [DllImport("dwmapi.dll")]
    public static extern int DwmGetWindowAttribute(IntPtr hwnd, int dwAttribute, out RECT pvAttribute, int cbAttribute);
    public delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);
    [StructLayout(LayoutKind.Sequential)]
    public struct RECT {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }
}
"@

$sw = [System.Diagnostics.Stopwatch]::StartNew()

try {
$script:minStartTime = $null
if ($StartTime) {
    $script:minStartTime = [datetime]::Parse($StartTime).AddSeconds(-15)
}

# Pre-fetch the owning processes once. This avoids a Get-Process -Id call per
# top-level window, which on a busy desktop takes many seconds and pushed this
# script past the Node.js execFile timeout (killing it with no error output).
$script:targetStartTimes = @{}
$script:targetPids = New-Object 'System.Collections.Generic.HashSet[uint32]'
foreach ($procInfo in @(Get-Process -Name $ProcessName -ErrorAction SilentlyContinue)) {
    if ($procInfo -and $procInfo.Id -gt 0) {
        [void]$script:targetPids.Add([uint32]$procInfo.Id)
        if ($procInfo.StartTime) {
            $script:targetStartTimes[[uint32]$procInfo.Id] = $procInfo.StartTime
        }
    }
}

$script:bestWindow = [IntPtr]::Zero
$script:bestDist = [int]::MaxValue
$script:bestArea = 0
$usePosition = ($ExpectedX -ne 0 -or $ExpectedY -ne 0)

$callback = [Win32Capture+EnumWindowsProc]{
    param($hWnd, $lParam)
    $windowPid = [uint32]0
    [Win32Capture]::GetWindowThreadProcessId($hWnd, [ref]$windowPid) | Out-Null
    if ($windowPid -eq 0 -or -not $script:targetPids.Contains($windowPid)) {
        return $true
    }
    if (-not [Win32Capture]::IsWindowVisible($hWnd)) {
        return $true
    }
    if ($script:minStartTime) {
        $startTime = $null
        if ($script:targetStartTimes.ContainsKey($windowPid)) {
            $startTime = $script:targetStartTimes[$windowPid]
        }
        if ($startTime -and $startTime -lt $script:minStartTime) {
            return $true
        }
    }

    $r = New-Object Win32Capture+RECT
    [Win32Capture]::GetWindowRect($hWnd, [ref]$r) | Out-Null
    $w = $r.Right - $r.Left
    $h = $r.Bottom - $r.Top
    if ($w -gt 200 -and $h -gt 100) {
        if ($usePosition) {
            $dist = [Math]::Abs($r.Left - $ExpectedX) + [Math]::Abs($r.Top - $ExpectedY)
            if ($dist -lt $script:bestDist) {
                $script:bestDist = $dist
                $script:bestWindow = $hWnd
            }
        } else {
            $area = $w * $h
            if ($area -gt $script:bestArea) {
                $script:bestArea = $area
                $script:bestWindow = $hWnd
            }
        }
    }
    return $true
}

$hwnd = [IntPtr]::Zero
while ($sw.Elapsed.TotalSeconds -lt 10 -and $hwnd -eq [IntPtr]::Zero) {
    [Win32Capture]::EnumWindows($callback, [IntPtr]::Zero) | Out-Null
    $hwnd = $script:bestWindow
    if ($hwnd -eq [IntPtr]::Zero) {
        Start-Sleep -Milliseconds 300
    }
}

if ($hwnd -eq [IntPtr]::Zero) {
    throw "No matching window found for process '$ProcessName'"
}

if ([Win32Capture]::IsIconic($hwnd)) {
    [Win32Capture]::ShowWindow($hwnd, 9) | Out-Null
}
[Win32Capture]::SetForegroundWindow($hwnd) | Out-Null
[Win32Capture]::BringWindowToTop($hwnd) | Out-Null
Start-Sleep -Milliseconds 900

$rect = New-Object Win32Capture+RECT
$dwmResult = [Win32Capture]::DwmGetWindowAttribute($hwnd, 9, [ref]$rect, 16)
if ($dwmResult -ne 0) {
    [Win32Capture]::GetWindowRect($hwnd, [ref]$rect) | Out-Null
}

# Clamp to the virtual screen so CopyFromScreen does not throw
$vs = [System.Windows.Forms.SystemInformation]::VirtualScreen
$x0 = $rect.Left
$y0 = $rect.Top
$x1 = [Math]::Min($rect.Right, $vs.Right)
$y1 = [Math]::Min($rect.Bottom, $vs.Bottom)
$width = $x1 - $x0
$height = $y1 - $y0
if ($width -le 0 -or $height -le 0) {
    throw "Invalid window rect for '$ProcessName' (${x0},${y0} ${width}x${height})"
}

function Test-BitmapHasContent($bmp) {
    $rect = New-Object System.Drawing.Rectangle 0, 0, $bmp.Width, $bmp.Height
    $data = $bmp.LockBits($rect, [System.Drawing.Imaging.ImageLockMode]::ReadOnly, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
    try {
        $stride = $data.Stride
        $bytes = New-Object byte[] ($stride * $bmp.Height)
        [System.Runtime.InteropServices.Marshal]::Copy($data.Scan0, $bytes, 0, $bytes.Length)
        $stepX = [Math]::Max(1, [int]($bmp.Width / 16))
        $stepY = [Math]::Max(1, [int]($bmp.Height / 16))
        $samples = 0
        $nonBlack = 0
        for ($y = 0; $y -lt $bmp.Height; $y += $stepY) {
            for ($x = 0; $x -lt $bmp.Width; $x += $stepX) {
                $i = $y * $stride + $x * 4
                $samples++
                if ($bytes[$i + 2] -gt 8 -or $bytes[$i + 1] -gt 8 -or $bytes[$i] -gt 8) {
                    $nonBlack++
                }
            }
        }
        return ($samples -gt 0) -and ($nonBlack -gt 0)
    } finally {
        $bmp.UnlockBits($data)
    }
}

$bmp = New-Object System.Drawing.Bitmap $width, $height
$g = [System.Drawing.Graphics]::FromImage($bmp)
$copyError = $null
try {
    $g.CopyFromScreen($x0, $y0, 0, 0, (New-Object System.Drawing.Size $width, $height))
} catch {
    $copyError = $_.Exception.Message
}
$g.Dispose()

if ($copyError) {
    # CopyFromScreen needs the interactive desktop (it fails from a service /
    # non-interactive window station with "The handle is invalid"). Fall back to
    # rendering the window straight into the bitmap via PrintWindow, which also
    # works when the window is occluded or not on the visible desktop.
    $pwResult = $false
    $pwGraphics = [System.Drawing.Graphics]::FromImage($bmp)
    $hdc = $pwGraphics.GetHdc()
    try {
        $pwResult = [Win32Capture]::PrintWindow($hwnd, $hdc, 2)
    } finally {
        $pwGraphics.ReleaseHdc($hdc)
        $pwGraphics.Dispose()
    }
    if (-not $pwResult -or -not (Test-BitmapHasContent $bmp)) {
        $bmp.Dispose()
        throw "Window capture failed for '$ProcessName' (rect ${x0},${y0} ${width}x${height}). CopyFromScreen: $copyError ; PrintWindow fallback also failed. Run 'npm run evidence' from a normal, unlocked desktop terminal."
    }
    [Console]::Error.WriteLine("capture-window.ps1: CopyFromScreen unavailable ($copyError) - captured via PrintWindow fallback.")
}

$dir = Split-Path -Parent $OutFile
if (-not (Test-Path $dir)) {
    New-Item -ItemType Directory -Path $dir -Force | Out-Null
}
$bmp.Save($OutFile, [System.Drawing.Imaging.ImageFormat]::Png)
$bmp.Dispose()

Write-Output "Captured: $OutFile"
} catch {
    [Console]::Error.WriteLine("capture-window.ps1 ERROR: $($_.Exception.Message) (line $($_.InvocationInfo.ScriptLineNumber)) after $([Math]::Round($sw.Elapsed.TotalSeconds,1))s")
    exit 1
}
