function classifyKeywordChange(beforeKw, afterKw) {
  const a = String(beforeKw || '').trim();
  const b = String(afterKw || '').trim();
  if (!a || !b) return { kind: 'entire', beforeFragment: '', afterFragment: '' };
  if (a === b) return { kind: 'identical', beforeFragment: '', afterFragment: '' };

  const aw = a.split(/\s+/);
  const bw = b.split(/\s+/);

  let prefix = 0;
  while (prefix < aw.length && prefix < bw.length && aw[prefix] === bw[prefix]) prefix++;

  let suffix = 0;
  while (suffix < aw.length - prefix && suffix < bw.length - prefix
    && aw[aw.length - 1 - suffix] === bw[bw.length - 1 - suffix]) suffix++;

  const beforeFragment = aw.slice(prefix, aw.length - suffix).join(' ');
  const afterFragment = bw.slice(prefix, bw.length - suffix).join(' ');

  if ((prefix > 0 || suffix > 0) && beforeFragment && afterFragment) {
    return { kind: 'partial', beforeFragment, afterFragment };
  }
  return { kind: 'entire', beforeFragment: '', afterFragment: '' };
}

module.exports = { classifyKeywordChange };
