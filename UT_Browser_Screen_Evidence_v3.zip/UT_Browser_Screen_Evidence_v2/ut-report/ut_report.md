# UT Browser Evidence Report

## UT-004
- Browser: Chrome
- Engine: Chrome 151.0.7922.175 (system chrome)
- URL: http://localhost:8080/employee-app/employee/form
- BeforeText: Fill in the employee details below
- AfterText: Enter the employee information below.
- Status: FAILED
- ExpectedResult: Fill in the employee details data below
- UserStatus: 
- Message: ExpectedResult 'Fill in the employee details data below' was not found on the after screen. Update the ExpectedResult value in ut_cases.md or fix the app.
- HtmlBefore: C:\Users\25-00392\Desktop\MYO MIN MYAT\node_demo\UT_Browser_Screen_Evidence_v2\ut-report\html\UT-004-Chrome-before.html
- HtmlAfter: C:\Users\25-00392\Desktop\MYO MIN MYAT\node_demo\UT_Browser_Screen_Evidence_v2\ut-report\html\UT-004-Chrome-after.html
- HtmlDomBefore: C:\Users\25-00392\Desktop\MYO MIN MYAT\node_demo\UT_Browser_Screen_Evidence_v2\ut-report\html\UT-004-Chrome-before.dom.html
- HtmlDomAfter: C:\Users\25-00392\Desktop\MYO MIN MYAT\node_demo\UT_Browser_Screen_Evidence_v2\ut-report\html\UT-004-Chrome-after.dom.html
- Screenshots: C:\Users\25-00392\Desktop\MYO MIN MYAT\node_demo\UT_Browser_Screen_Evidence_v2\ut-report\screenshots\UT-004-Chrome-before.png, C:\Users\25-00392\Desktop\MYO MIN MYAT\node_demo\UT_Browser_Screen_Evidence_v2\ut-report\screenshots\UT-004-Chrome-after.png
