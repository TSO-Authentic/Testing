﻿# UT Cases





































































## UT-001
- TestID: UT-001
- URL: http://localhost:5173/saved
- BaseURL: http://localhost:5173/
- LoginId: (not applicable)
- Password: (not applicable)
- LoginIdSelector: -
- PasswordSelector: -
- LoginButtonSelector: -
- TargetScreen: Saved Items
- Keyword: I want to know saved items
- BeforeText: No saved items yet
- AfterText: I want to know saved items
- Description: Saved Items - I want to know saved items verification
- NavReplay: replay
- Browsers: Edge
- RedBox: false














































## UT-002
- TestID: UT-002
- URL: http://localhost:8080/employee-app/login
- BaseURL: http://localhost:8080/employee-app/login
- LoginId: admin
- Password: admin123
- LoginIdSelector: input[type="text"]
- PasswordSelector: input[type="password"]
- LoginButtonSelector: button[type="submit"]
- TargetScreen: Add New Employee
- Keyword: Fill in the employee details below
- BeforeText: Fill in the employee details below
- Description: Add New Employee - Fill in the employee details below verification
- NavReplay: replay
- Browsers: Chrome
- Elements: [{"type":"text","label":"Full Name","value":"Myo"},{"type":"text","label":"Email","value":"mjirre@gmail.coms"},{"type":"text","label":"Phone","value":"09748456752"},{"type":"select","label":"Department","value":"HR"},{"type":"text","label":"Position","value":"IT Support Technician"},{"type":"date","label":"Join Date","value":"08/27/2026"}]
- RedBox: true
































## UT-003
- TestID: UT-003
- URL: https://www.nhk.or.jp/saiyo/?cid=orjp-noltop-navi-saiyo
- BaseURL: https://www.nhk.or.jp/
- LoginId: (not applicable)
- Password: (not applicable)
- LoginIdSelector: -
- PasswordSelector: -
- LoginButtonSelector: -
- TargetScreen: 誰かのために、
- Keyword: 誰かのために、社会のために。
- BeforeText: 誰かのために、社会のために。
- Description: 誰かのために、 - 誰かのために、社会のために。 verification
- NavReplay: replay
- Browsers: Chrome
- RedBox: false
































## UT-004
- TestID: UT-004
- URL: http://localhost:8080/employee-app/employee/form
- BaseURL: http://localhost:8080/employee-app/login
- LoginId: admin
- Password: admin123
- LoginIdSelector: Username
- PasswordSelector: Password
- LoginButtonSelector: Login
- TargetScreen: Add New Employee
- Keyword: Enter the employee information below.
- BeforeText: Fill in the employee details below
- AfterText: Enter the employee information below.
- Description: Add New Employee - Enter the employee information below. verification
- NavReplay: replay
- Browsers: Chrome
- Elements: [{"type":"text","label":"Full Name","value":"Myo"},{"type":"text","label":"Email","value":"mlyand@gmail.coms"},{"type":"text","label":"Phone","value":"09748456752"},{"type":"select","label":"Department","value":"HR"},{"type":"text","label":"Position","value":"IT Support Technician"},{"type":"date","label":"Join Date","value":"08/27/2026"}]
- RedBox: true
- AfterFillAction: custom
- SubmitButtonSelector: Save
- ExpectedResult: Fill in the employee details data below
