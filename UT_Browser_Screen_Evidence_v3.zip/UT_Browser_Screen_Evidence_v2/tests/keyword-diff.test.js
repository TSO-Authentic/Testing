const { classifyKeywordChange } = require('../keyword-diff');

const failures = [];
const expect = (name, cond, detail) => {
  console.log(`${cond ? 'PASS' : 'FAIL'}: ${name}${detail ? ' -> ' + detail : ''}`);
  if (!cond) failures.push(name);
};

const cases = [
  {
    name: 'identical keywords',
    before: 'click any item to view details', after: 'click any item to view details',
    check: r => r.kind === 'identical',
  },
  {
    name: 'middle word changed (user example)',
    before: 'click any item to view details', after: 'click every item to view details',
    check: r => r.kind === 'partial' && r.beforeFragment === 'any' && r.afterFragment === 'every',
  },
  {
    name: 'start changed, end shared',
    before: 'any item details', after: 'every item details',
    check: r => r.kind === 'partial' && r.beforeFragment === 'any' && r.afterFragment === 'every',
  },
  {
    name: 'end changed, start shared',
    before: 'start at N5', after: 'start at N6',
    check: r => r.kind === 'partial' && r.beforeFragment === 'N5' && r.afterFragment === 'N6',
  },
  {
    name: 'multi-word fragment with shared end',
    before: 'start at N5', after: 'begin with N5',
    check: r => r.kind === 'partial' && r.beforeFragment === 'start at' && r.afterFragment === 'begin with',
  },
  {
    name: 'nothing shared at edges -> entire',
    before: 'Login', after: 'Sign in',
    check: r => r.kind === 'entire',
  },
  {
    name: 'both edges changed, middle shared -> entire',
    before: 'alpha beta gamma', after: 'delta beta epsilon',
    check: r => r.kind === 'entire',
  },
  {
    name: 'word deleted (empty fragment) -> entire',
    before: 'click any item', after: 'click item',
    check: r => r.kind === 'entire',
  },
  {
    name: 'empty before -> entire',
    before: '', after: 'anything',
    check: r => r.kind === 'entire',
  },
  {
    name: 'whitespace differences normalized',
    before: 'click  any   item', after: 'click every item',
    check: r => r.kind === 'partial' && r.beforeFragment === 'any' && r.afterFragment === 'every',
  },
];

for (const c of cases) {
  const r = classifyKeywordChange(c.before, c.after);
  expect(c.name, c.check(r), JSON.stringify(r));
}

if (failures.length) { console.error('FAILED: ' + failures.join(', ')); process.exit(1); }
console.log('ALL KEYWORD-DIFF CHECKS PASSED');
