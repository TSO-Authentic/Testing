const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync } = require('child_process');
const {
  loadRouteConfig,
  saveRouteConfig,
  upsertRouteEntry,
  findRouteEntry,
  normalizeForMatch,
  resolveRouteConfig,
  normalizeUrlKey,
} = require('../nav-find');

const failures = [];
const expect = (name, cond, detail) => {
  console.log(`${cond ? 'PASS' : 'FAIL'}: ${name}${detail !== undefined ? ' -> ' + detail : ''}`);
  if (!cond) failures.push(name);
};

function newDir(label) {
  return fs.mkdtempSync(path.join(os.tmpdir(), `navcfg-${label}-`));
}

function writeFixture(dir, file, text) {
  const full = path.join(dir, file);
  fs.mkdirSync(path.dirname(full), { recursive: true });
  fs.writeFileSync(full, text, 'utf8');
}

function runGen(projectRoots, cwd) {
  const args = [path.join(cwd, 'nav-gen.js'), ...projectRoots];
  return execFileSync(process.execPath, args, { cwd, timeout: 30000, encoding: 'utf8' });
}

// ---------------------------------------------------------------------------
// Fake page (reuse minimal shape from nav-find.test.js for replay checks)
// ---------------------------------------------------------------------------
function makeSite(pageSpecs, siteOpts = {}) {
  const counters = { gotos: 0, clicks: 0 };
  const rootUrl = siteOpts.rootUrl || pageSpecs[0].url;
  let cur = pageSpecs[0];
  return {
    counters,
    page: {
      keyboard: { async press() {} },
      async waitForTimeout() {},
      url() { return cur.url; },
      async goto(u) {
        if (siteOpts.deepGotoBlocked && u !== rootUrl) throw new Error('net::ERR_BLOCKED');
        counters.gotos++;
        const next = pageSpecs.find(s => s.url === u);
        if (!next) throw new Error('net::ERR_NAME_NOT_RESOLVED ' + u);
        cur = next;
      },
      async evaluate(fn, argA) {
        const s = fn.toString();
        if (s.includes('[role="dialog"]')) return false;
        if (s.includes('role="heading"')) return !!cur.hasTarget;
        if (s.includes('replace(/\\s+/g')) return String(cur.bodyText || '').replace(/\s+/g, '').includes(String(argA).replace(/\s+/g, ''));
        if (s.includes('nav-replay-locator')) {
          const desc = (argA || {}).desc || {};
          const links = cur.links || [];
          let idx = -1;
          if (desc.text) idx = links.findIndex(l => String(l.text) === desc.text);
          if (idx < 0 && Number.isInteger(desc.index) && desc.index >= 0 && links[desc.index]) idx = desc.index;
          if (idx < 0) return false;
          const link = links[idx];
          if (link && link.to) { const n = pageSpecs.find(s => s.url === link.to); if (n) cur = n; }
          counters.clicks++;
          return !!link;
        }
        return false;
      },
    },
  };
}

(async () => {
// -------------------------------------------------------------------------
// Save original state of root files (restored at end)
// -------------------------------------------------------------------------
const rootRoutes = path.join(__dirname, '..', 'nav-routes.json');
const rootCases = path.join(__dirname, '..', 'ut_cases.md');
const origRoutes = fs.existsSync(rootRoutes) ? fs.readFileSync(rootRoutes, 'utf8') : null;
const origCases = fs.readFileSync(rootCases, 'utf8');

// -------------------------------------------------------------------------
// Unit: matching + merge semantics
// -------------------------------------------------------------------------
const dirMerge = newDir('merge');
saveRouteConfig(dirMerge, {
  version: 1, updatedAt: '', sources: [],
  routes: [{
    project: 'wolf', domain: 'app', targetScreen: 'Screen A', keyword: 'k',
    startUrl: 'http://app/', directUrl: 'http://app/a', steps: [],
    source: 'a.jsp', verified: false,
  }],
});

upsertRouteEntry(dirMerge, {
  project: 'wolf', targetScreen: 'Screen A', keyword: 'k',
  startUrl: 'http://app/', directUrl: 'http://app/a-v2', source: 'a2.jsp',
});
expect('upsert refreshes URL and resets verified on change',
  loadRouteConfig(dirMerge).routes[0].directUrl === 'http://app/a-v2' &&
  loadRouteConfig(dirMerge).routes[0].verified === false);

upsertRouteEntry(dirMerge, {
  project: 'wolf', targetScreen: 'Screen A', keyword: 'k',
  startUrl: 'http://app/', directUrl: 'http://app/a-v2', source: 'a2.jsp',
});
expect('upsert keeps entry count stable across repeated merges',
  loadRouteConfig(dirMerge).routes.length === 1);

// preserve hand-edited extra key
const manualDir = newDir('manualkey');
saveRouteConfig(manualDir, {
  version: 1, updatedAt: '', sources: [],
  routes: [{ project: 'x', targetScreen: 'S1', directUrl: 'http://app/s1', notes: 'keep me', verified: true }],
});
upsertRouteEntry(manualDir, { project: 'x', targetScreen: 'S1', directUrl: 'http://app/s1' });
expect('upsert preserves manually added extra keys', loadRouteConfig(manualDir).routes[0].notes === 'keep me');

// -------------------------------------------------------------------------
// nav-gen.js end-to-end against synthetic JSP + web.xml + jboss-web.xml
// -------------------------------------------------------------------------
// Write clean nav-routes.json to avoid orphans from previous test runs
saveRouteConfig(path.join(__dirname, '..'), { version: 1, updatedAt: '', sources: [], routes: [] });
const fixtureDir = newDir('fixture');
writeFixture(fixtureDir, 'src/main/webapp/WEB-INF/web.xml',
  '<web-app><display-name>xtrade</display-name><welcome-file>index.jsp</welcome-file></web-app>');
writeFixture(fixtureDir, 'src/main/webapp/WEB-INF/jboss-web.xml',
  '<jboss-web><context-root>/wolf2app</context-root></jboss-web>');
writeFixture(fixtureDir, 'src/main/webapp/index.jsp',
  `<nav><a href="flashcards/list.jsp">Flashcards</a></nav>
   <a href="assets/banner.png">img</a>
   <form action="search.do"><input></form>`);
writeFixture(fixtureDir, 'src/main/webapp/pages/list.jsp',
  '<html><head><title>Flashcards List</title></head><body><h1>All in</h1></body></html>');

fs.writeFileSync(rootCases,
  '## Fixture\n- TestID: FT-001\n- TargetScreen: Flashcards\n- Keyword: All in\n', 'utf8');

const genOut = runGen([fixtureDir], path.join(__dirname, '..'));
expect('generator exits 0 on valid fixture', genOut !== undefined);

const genRoutes = loadRouteConfig(path.join(__dirname, '..'));
expect('generator produced at least one route', genRoutes && genRoutes.routes.length >= 1);
const r = genRoutes.routes.find(e => e.routePath && e.routePath.includes('flashcards'));
expect('flashcards route found with context root prefix',
  !!r && r.routePath === '/wolf2app/flashcards/list.jsp' &&
  r.steps.length === 1 && r.steps[0].kind === 'click' && r.steps[0].text === 'Flashcards' &&
  r.extractedKind === 'anchor',
  JSON.stringify({ routePath: r && r.routePath, steps: r && r.steps.length }));

expect('generator marks in-menu step for anchor inside nav-like container',
  r && r.inMenu === true, JSON.stringify(r ? r.inMenu : null));

// Re-run: entry count unchanged (upsert, no duplicates)
runGen([fixtureDir], path.join(__dirname, '..'));
const genRoutesAfter = loadRouteConfig(path.join(__dirname, '..'));
expect('re-generation does not duplicate entries',
  genRoutesAfter && genRoutesAfter.routes.filter(e => e.routePath && e.routePath.includes('flashcards')).length === 1);

// -------------------------------------------------------------------------
// resolveRouteConfig verified-flag flip using generated fixture route
// -------------------------------------------------------------------------
const dirVerified = newDir('verified');
const routeUrl = r && r.routePath ? `http://localhost${r.routePath}` : 'http://localhost/wolf2app/flashcards/list.jsp';
saveRouteConfig(dirVerified, {
  version: 1, updatedAt: '', sources: [],
  routes: [{
    project: 'fixture', domain: 'localhost', targetScreen: 'Flashcards', keyword: 'All in',
    startUrl: 'http://localhost/', directUrl: routeUrl,
    steps: [{ kind: 'click', from: 'http://localhost/', href: routeUrl, text: 'Flashcards', tag: 'a', index: 0 }],
    source: 'src/main/webapp/index.jsp', verified: false,
  }],
});
const siteVerified = makeSite([
  { url: routeUrl, hasTarget: true, bodyText: 'All in page content', links: [] },
]);
const gotVerified = await resolveRouteConfig(siteVerified.page, dirVerified, 'Flashcards', 'All in', () => {}, { strategy: 'auto' });
const afterVerified = loadRouteConfig(dirVerified).routes[0];
expect('resolved route flips verified=true and records landed URL',
  gotVerified === routeUrl && afterVerified.verified === true,
  JSON.stringify({ got: gotVerified, verified: afterVerified.verified }));

// -------------------------------------------------------------------------
// CLI help / invalid usage (just smoke: no args, bad path)
// -------------------------------------------------------------------------
try {
  execFileSync(process.execPath, [path.join(__dirname, '..', 'nav-gen.js')], { cwd: path.join(__dirname, '..'), timeout: 10000, encoding: 'utf8' });
  // if it exits 0 that's a warning, which is fine (missing ut_cases.md is handled)
} catch (err) {
  expect('generator prints guidance when no sources configured', err.stderr.includes('No project sources configured'), err.stderr.slice(0, 300));
}

// -------------------------------------------------------------------------
// Onclick extraction from markup
// -------------------------------------------------------------------------

const onclickFixture = newDir('onclick');
writeFixture(onclickFixture, 'src/main/webapp/WEB-INF/web.xml',
  '<web-app><display-name>myapp</display-name><welcome-file>index.jsp</welcome-file></web-app>');
writeFixture(onclickFixture, 'src/main/webapp/index.jsp',
  '<h1>Home</h1>\n' +
  '   <a href="menu.jsp">Menu</a>\n' +
  '   <button onclick="location.href=\'profile/update.jsp\'">Profile Update</button>\n' +
  '   <input type="button" onclick="window.location=\'settings.jsp\'" value="Settings">\n' +
  '   <button onclick="doSomething()">No Location</button>');
writeFixture(onclickFixture, 'src/main/webapp/profile/update.jsp',
  '<html><head><title>Profile Update</title></head><body><h1>Profile Update</h1></body></html>');
writeFixture(onclickFixture, 'src/main/webapp/settings.jsp',
  '<html><head><title>Settings</title></head><body><h1>Settings</h1></body></html>');

fs.writeFileSync(rootCases,
  '## Case 1\n- TestID: T001\n- TargetScreen: Profile Update\n- Keyword: Profile\n\n' +
  '## Case 2\n- TestID: T002\n- TargetScreen: Settings\n- Keyword: Settings\n', 'utf8');

runGen([onclickFixture], path.join(__dirname, '..'));
const onclickRoutes = loadRouteConfig(path.join(__dirname, '..'));

const profileRoute = onclickRoutes.routes.find(e => e.targetScreen === 'Profile Update');
const settingsRoute = onclickRoutes.routes.find(e => e.targetScreen === 'Settings');

expect('onclick: Profile Update route found',
  !!profileRoute, JSON.stringify(profileRoute ? { path: profileRoute.routePath, steps: profileRoute.steps.length } : null));
expect('onclick: Profile Update has extractedKind=onclick or chained',
  profileRoute && (profileRoute.extractedKind === 'onclick' || profileRoute.chained === true));
expect('onclick: Settings route found',
  !!settingsRoute, JSON.stringify(settingsRoute ? { path: settingsRoute.routePath, steps: settingsRoute.steps.length } : null));

// -------------------------------------------------------------------------
// Struts forward chain extraction
// -------------------------------------------------------------------------
const strutsFixture = newDir('struts');
writeFixture(strutsFixture, 'src/main/webapp/WEB-INF/web.xml',
  '<web-app><display-name>wolf2</display-name><welcome-file>index.jsp</welcome-file></web-app>');
writeFixture(strutsFixture, 'src/main/webapp/WEB-INF/jboss-web.xml',
  '<jboss-web><context-root>/wolf2app</context-root></jboss-web>');
writeFixture(strutsFixture, 'src/main/webapp/WEB-INF/struts-config.xml',
  '<struts-config>\n' +
  '    <action-mappings>\n' +
  '      <action path="/profile" type="com.app.ProfileAction">\n' +
  '        <forward name="success" path="/profile.jsp"/>\n' +
  '      </action>\n' +
  '      <action path="/profileUpdate" type="com.app.UpdateAction">\n' +
  '        <forward name="success" path="/profile/update.jsp"/>\n' +
  '        <forward name="input" path="/profile/input.jsp"/>\n' +
  '      </action>\n' +
  '    </action-mappings>\n' +
  '  </struts-config>');
writeFixture(strutsFixture, 'src/main/webapp/index.jsp',
  '<nav><a href="profile.do">Profile</a></nav>');
writeFixture(strutsFixture, 'src/main/webapp/profile.jsp',
  '<html><head><title>Profile</title></head><body><h1>Profile</h1><a href="profileUpdate.do">Update Profile</a></body></html>');
writeFixture(strutsFixture, 'src/main/webapp/profile/update.jsp',
  '<html><head><title>Profile Update</title></head><body><h1>Profile Update</h1></body></html>');

fs.writeFileSync(rootCases,
  '## Case 1\n- TestID: S001\n- TargetScreen: Profile Update\n- Keyword: Profile\n', 'utf8');

runGen([strutsFixture], path.join(__dirname, '..'));
const strutsRoutes = loadRouteConfig(path.join(__dirname, '..'));
const chainedRoute = strutsRoutes.routes.find(e => e.targetScreen === 'Profile Update' && e.chained === true);

expect('struts: Profile Update route found via chain',
  !!chainedRoute, JSON.stringify(chainedRoute ? { path: chainedRoute.routePath, steps: chainedRoute.steps.length, chained: chainedRoute.chained } : null));
expect('struts: chain has multiple steps',
  chainedRoute && chainedRoute.steps.length >= 2,
  JSON.stringify(chainedRoute ? chainedRoute.steps.map(s => s.text) : null));
expect('struts: chain starts with Profile menu click',
  chainedRoute && chainedRoute.steps[0] && chainedRoute.steps[0].text === 'Profile');

// -------------------------------------------------------------------------
// Chain building with page-to-page links (no struts-config)
// -------------------------------------------------------------------------
const chainFixture = newDir('chain');
writeFixture(chainFixture, 'src/main/webapp/WEB-INF/web.xml',
  '<web-app><display-name>app</display-name><welcome-file>index.jsp</welcome-file></web-app>');
writeFixture(chainFixture, 'src/main/webapp/index.jsp',
  '<nav><a href="admin/dashboard.jsp">Admin Dashboard</a></nav>');
writeFixture(chainFixture, 'src/main/webapp/admin/dashboard.jsp',
  '<html><head><title>Admin Dashboard</title></head><body><h1>Dashboard</h1><a href="admin/users.jsp">Manage Users</a></body></html>');
writeFixture(chainFixture, 'src/main/webapp/admin/users.jsp',
  '<html><head><title>User Management</title></head><body><h1>User Management</h1></body></html>');

fs.writeFileSync(rootCases,
  '## Case 1\n- TestID: C001\n- TargetScreen: User Management\n- Keyword: Users\n', 'utf8');

runGen([chainFixture], path.join(__dirname, '..'));
const chainRoutes = loadRouteConfig(path.join(__dirname, '..'));
const userMgmtRoute = chainRoutes.routes.find(e => e.targetScreen === 'User Management');

expect('chain: User Management route found',
  !!userMgmtRoute, JSON.stringify(userMgmtRoute ? { path: userMgmtRoute.routePath, steps: userMgmtRoute.steps.length, chained: userMgmtRoute.chained } : null));
expect('chain: has 2+ steps',
  userMgmtRoute && userMgmtRoute.steps.length >= 2,
  JSON.stringify(userMgmtRoute ? userMgmtRoute.steps.map(s => s.text) : null));

// -------------------------------------------------------------------------
// Restore original state
// -------------------------------------------------------------------------
if (origRoutes !== null) fs.writeFileSync(rootRoutes, origRoutes, 'utf8');
else if (fs.existsSync(rootRoutes)) fs.unlinkSync(rootRoutes);
fs.writeFileSync(rootCases, origCases, 'utf8');
// leave nav-routes.json intact; user may need it. Tests are self-contained otherwise.

if (failures.length) {
  console.error('FAILED: ' + failures.join(', '));
  process.exit(1);
}
console.log('ALL NAV-ROUTES-CONFIG CHECKS PASSED');
})().catch(err => {
  console.error('ERR', err && err.message);
  process.exit(1);
});
