const fs = require('fs');
const os = require('os');
const path = require('path');
const {
  loadNavCache,
  saveNavCache,
  resolveTargetScreen,
  resolveFromCache,
  resolveRouteConfig,
  findRouteEntry,
  upsertRouteEntry,
  loadRouteConfig,
  navPathFile,
  routesFile,
  normalizeForMatch,
  buildSearchTokens,
  diceSimilarity,
  scoreLink,
  pageConfidence,
  normalizeUrlKey,
} = require('../nav-find');

const failures = [];
const expect = (name, cond, detail) => {
  console.log(`${cond ? 'PASS' : 'FAIL'}: ${name}${detail !== undefined ? ' -> ' + detail : ''}`);
  if (!cond) failures.push(name);
};

function newDir(label) {
  return fs.mkdtempSync(path.join(os.tmpdir(), `navfind-${label}-`));
}

// ---------------------------------------------------------------------------
// Fake browser: array of page specs; every spec: {url, hasTarget, bodyText, links}
// link spec: {href, text, aria?, title?, to?}   (`to` = url the click lands on)
// siteOpts: {deepGotoBlocked, rootUrl}
// ---------------------------------------------------------------------------
function makeSite(pageSpecs, siteOpts = {}) {
  const counters = { gotos: 0, clicks: 0 };
  const rootUrl = siteOpts.rootUrl || pageSpecs[0].url;
  let cur = pageSpecs[0];
  const canonOf = (u) => { try { return new URL(u, cur.url).href; } catch { return ''; } };
  const normText = (t) => String(t || '').split(/\s+/).filter(Boolean).join(' ').toLowerCase();
  const page = {
    keyboard: { async press() { } },
    async waitForTimeout() { },
    url() { return cur.url; },
    async goto(u) {
      if (siteOpts.deepGotoBlocked && u !== rootUrl) throw new Error('net::ERR_BLOCKED_BY_CLIENT ' + u);
      counters.gotos++;
      const next = pageSpecs.find(s => s.url === u);
      if (!next) throw new Error('net::ERR_NAME_NOT_RESOLVED ' + u);
      cur = next;
    },
    async evaluate(fn, argA, argB) {
      const s = fn.toString();
      if (s.includes('[role="dialog"]')) return !!cur.hasModal;
      if (s.includes('role="heading"')) return !!cur.hasTarget;
      if (s.includes('replace(/\\s+/g')) {
        return String(cur.bodyText || '').replace(/\s+/g, '').includes(String(argA).replace(/\s+/g, ''));
      }
      if (s.includes('nav-replay-locator')) {
        // Real call passes ONE payload object: { desc, dangerSource }
        const payload = argA || {};
        const desc = payload.desc || {};
        const dangerRe = payload.dangerSource ? new RegExp(payload.dangerSource, 'i') : null;
        const links = cur.links || [];
        const wantCanon = desc.href ? canonOf(desc.href) : '';
        const wantPath = wantCanon ? wantCanon.split('#')[0].split('?')[0] : '';
        let pickIdx = -1;
        if (wantCanon) pickIdx = links.findIndex(l => canonOf(l.href) === wantCanon);
        if (pickIdx < 0 && wantPath) pickIdx = links.findIndex(l => canonOf(l.href).split('#')[0].split('?')[0] === wantPath);
        if (pickIdx < 0 && desc.text && desc.text !== '(no text)') pickIdx = links.findIndex(l => normText(l.text) === normText(desc.text));
        if (pickIdx < 0 && Number.isInteger(desc.index) && desc.index >= 0 && links[desc.index]) pickIdx = desc.index;
        if (pickIdx < 0) return false;
        const link = links[pickIdx];
        if (!payload.allowDangerous && link.dangerous) return false;
        if (!payload.allowDangerous && dangerRe && dangerRe.test([link.text || '', link.aria || '', link.title || ''].join(' '))) return false;
        counters.clicks++;
        if (link.to) {
          const next = pageSpecs.find(spec => spec.url === link.to);
          if (!next) return false;
          cur = next;
          return true;
        }
        return !!desc.href;
      }
      return false;
    },
  };
  return { page, counters };
}

function seedHistory(dir, overrides = {}) {
  saveNavCache(dir, Object.assign({
    version: 2,
    updatedAt: new Date().toISOString(),
    entries: [{
      domain: 'app',
      targetScreen: 'Saved Items',
      normalizedScreen: 'saved items',
      keyword: 'bookmark',
      foundUrl: 'http://app/saved',
      startUrl: 'http://app/',
      path: ['http://app/', 'http://app/saved'],
      steps: [{ kind: 'click', from: 'http://app/', href: 'http://app/saved', text: 'Saved', tag: 'a', index: 0, landedAt: 'http://app/saved' }],
      visited: [],
      totalSteps: 2,
      hits: 1,
      updatedAt: new Date().toISOString(),
    }],
  }, overrides));
}

function seedRoutes(dir, overrides = {}) {
  const fsmod = require('fs');
  const config = Object.assign({
    version: 1,
    updatedAt: new Date().toISOString(),
    sources: [],
    routes: [{
      project: 'wolfapp',
      domain: 'app',
      targetScreen: 'Saved Items',
      keyword: 'bookmark',
      startUrl: 'http://app/',
      directUrl: 'http://app/saved',
      steps: [{ kind: 'click', from: 'http://app/', href: 'http://app/saved', text: 'Saved', tag: 'a', index: 0 }],
      source: 'src/main/webapp/menu.jsp',
      verified: false,
    }],
  }, overrides);
  fsmod.mkdirSync(dir, { recursive: true });
  fsmod.writeFileSync(routesFile(dir), JSON.stringify(config, null, 2), 'utf8');
  return config;
}

(async () => {
  // -------------------------------------------------------------------------
  // Unit tests: pure helpers
  // -------------------------------------------------------------------------
  expect('normalizeForMatch folds full-width + strips punct/space',
    normalizeForMatch('Ａｎｉｍｅ　一覧！') === 'anime一覧', JSON.stringify(normalizeForMatch('Ａｎｉｍｅ　一覧！')));

  expect('diceSimilarity identical after normalization == 1',
    diceSimilarity('アニメ一覧', 'アニメ 一覧') === 1);

  expect('buildSearchTokens emits phrases and splits',
    (() => {
      const t = buildSearchTokens('Saved Items', 'bookmark');
      return t.includes('saveditems') && t.includes('items') && t.includes('bookmark');
    })(), JSON.stringify(buildSearchTokens('Saved Items', 'bookmark')));

  const scoreCtx = { origin: 'http://app', tokens: [], targetNorm: 'saveditems', kwNorm: '' };
  expect('scoreLink text hit (60) beats aria (45) beats href slug (35)',
    scoreLink({ href: 'http://app/a', text: 'Saved Items' }, scoreCtx) === 60 &&
    scoreLink({ href: 'http://app/b', ariaLabel: 'Saved Items' }, scoreCtx) === 45 &&
    scoreLink({ href: 'http://app/saved-items-page', text: '(no text)' }, scoreCtx) === 35,
    JSON.stringify([
      scoreLink({ href: 'http://app/a', text: 'Saved Items' }, scoreCtx),
      scoreLink({ href: 'http://app/b', ariaLabel: 'Saved Items' }, scoreCtx),
      scoreLink({ href: 'http://app/saved-items-page', text: '(no text)' }, scoreCtx),
    ]));

  const internalScore = scoreLink({ href: 'http://app/saved-items', text: 'Saved Items' }, scoreCtx);
  const externalScore = scoreLink({ href: 'https://ext.example.com/saved-items', text: 'Saved Items' }, scoreCtx);
  expect('scoreLink cross-origin penalty applied (-100)',
    externalScore === internalScore - 100 && externalScore < 0,
    `internal=${internalScore} external=${externalScore}`);

  expect('scoreLink rejects assets and js/mailto/tel',
    scoreLink({ href: 'http://app/logo.png', text: 'Saved Items' }, scoreCtx) === -Infinity &&
    scoreLink({ href: 'javascript:void(0)', text: 'Saved Items' }, scoreCtx) === -Infinity &&
    scoreLink({ href: 'mailto:a@b.c', text: 'Saved Items' }, scoreCtx) === -Infinity);

  expect('scoreLink fuzzy CJK bonus below phrase hit',
    scoreLink({ href: 'http://app/contact', text: '問い合わせフォーム' },
      { origin: 'http://app', tokens: [], targetNorm: 'お問い合わせフォーム', kwNorm: '' }) > 0 &&
    scoreLink({ href: 'http://app/contact', text: '問い合わせフォーム' },
      { origin: 'http://app', tokens: [], targetNorm: 'お問い合わせフォーム', kwNorm: '' }) < 60);

  expect('pageConfidence weights 0.5/0.3/0.2 with clamped coverage',
    pageConfidence({ headingHit: true, keywordHit: true, tokenCoverage: 1 }) === 1 &&
    pageConfidence({ headingHit: true }) === 0.5 &&
    pageConfidence({ headingHit: true, keywordHit: true, tokenCoverage: 42 }) === 1 &&
    pageConfidence(null) === 0);

  // -------------------------------------------------------------------------
  // Routes config: matching + merge semantics (nav-routes.json)
  // -------------------------------------------------------------------------
  const dirRoutes = newDir('routes');
  seedRoutes(dirRoutes);
  expect('findRouteEntry exact match',
    findRouteEntry(dirRoutes, 'Saved Items').directUrl === 'http://app/saved');
  expect('findRouteEntry normalized match (full-width space)',
    !!findRouteEntry(dirRoutes, 'Ｓａｖｅｄ　Items'));
  expect('findRouteEntry fuzzy match above threshold',
    !!findRouteEntry(dirRoutes, 'Saved Items2'),
    JSON.stringify(diceSimilarity('saveditems', 'saveditems2')));
  expect('findRouteEntry returns nothing for unknown screen',
    findRouteEntry(dirRoutes, 'Unknown Screen') === null);
  expect('findRouteEntry domain filter blocks other domains',
    findRouteEntry(dirRoutes, 'Saved Items', 'otherhost') === null &&
    !!findRouteEntry(dirRoutes, 'Saved Items', 'app'));

  upsertRouteEntry(dirRoutes, {
    project: 'wolfapp', targetScreen: 'Saved Items', keyword: 'bookmark',
    startUrl: 'http://app/', directUrl: 'http://app/saved-v2', source: 'menu.jsp',
  });
  const merged = loadRouteConfig(dirRoutes).routes[0];
  expect('upsertRouteEntry refreshes URL and resets verified on change',
    merged.directUrl === 'http://app/saved-v2' && merged.verified === false && merged.hits === undefined,
    JSON.stringify({ directUrl: merged.directUrl, verified: merged.verified }));

  upsertRouteEntry(dirRoutes, {
    project: 'wolfapp', targetScreen: 'Saved Items', keyword: 'bookmark',
    startUrl: 'http://app/', directUrl: 'http://app/saved-v2', source: 'menu.jsp',
  });
  expect('upsertRouteEntry keeps verified=true when URL unchanged',
    loadRouteConfig(dirRoutes).routes[0].verified === false,
    'seed was unverified; only successful runs flip it');

  upsertRouteEntry(dirRoutes, {
    project: 'otherproj', targetScreen: 'ログイン', directUrl: 'http://other/login',
  });
  expect('upsertRouteEntry appends unknown screens without touching others',
    loadRouteConfig(dirRoutes).routes.length === 2);

  // -------------------------------------------------------------------------
  // resolveTargetScreen: single direct visit, NO crawling
  // -------------------------------------------------------------------------
  const dirBasic = newDir('basic');
  const logsBasic = [];

  expect('loadNavCache missing file -> null', loadNavCache(dirBasic, 'Saved Items', () => {}) === null);

  const siteBasic = makeSite([
    { url: 'http://app/saved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ]);
  const foundBasic = await resolveTargetScreen(siteBasic.page, dirBasic, 'http://app/saved', 'Saved Items', 'bookmark', m => logsBasic.push(m));
  expect('resolveTargetScreen verifies screen+keyword on the one given URL',
    foundBasic === 'http://app/saved' && siteBasic.counters.clicks === 0,
    String(foundBasic));
  expect('logs include FOUND line', logsBasic.some(l => l.includes('FOUND')));
  expect('cache written on success', fs.existsSync(navPathFile(dirBasic)));

  const kbRaw = JSON.parse(fs.readFileSync(navPathFile(dirBasic), 'utf8'));
  expect('cache is schema v2 with entries[]',
    kbRaw.version === 2 && Array.isArray(kbRaw.entries) && kbRaw.entries.length === 1);
  expect('entry records foundUrl/route/steps/hits',
    kbRaw.entries[0].foundUrl === 'http://app/saved' &&
    Array.isArray(kbRaw.entries[0].path) &&
    Array.isArray(kbRaw.entries[0].steps) && kbRaw.entries[0].steps.length === 0,
    JSON.stringify(kbRaw.entries[0]));
  expect('legacy mirror fields present for old readers',
    kbRaw.targetScreen === 'Saved Items' && kbRaw.foundUrl === 'http://app/saved');

  expect('loadNavCache reuses valid v2 cache', loadNavCache(dirBasic, 'Saved Items', () => {}).foundUrl === 'http://app/saved');

  const siteRerun = makeSite([
    { url: 'http://app/somewhere-else', hasTarget: false, bodyText: '', links: [] },
  ]);
  const foundRerun = await resolveTargetScreen(siteRerun.page, dirBasic, 'http://app/somewhere-else', 'Saved Items', 'bookmark', () => {});
  expect('second run resolves from knowledge base with zero navigation',
    foundRerun === 'http://app/saved' && siteRerun.counters.gotos === 0,
    JSON.stringify({ foundRerun, gotos: siteRerun.counters.gotos }));
  expect('hit counter incremented on reuse',
    JSON.parse(fs.readFileSync(navPathFile(dirBasic), 'utf8')).entries[0].hits === 2);

  // Heading present but keyword missing -> null, cache untouched
  const dirKwMiss = newDir('kwmiss');
  saveNavCache(dirKwMiss, {
    version: 2, updatedAt: '2026-01-01T00:00:00.000Z',
    entries: [{ domain: '', targetScreen: 'KEEP ME', normalizedScreen: 'keepme', keyword: '', foundUrl: 'http://app/keep', path: [], visited: [], totalSteps: 1, hits: 3, updatedAt: '2026-01-01T00:00:00.000Z' }],
  });
  const snapshotKw = fs.readFileSync(navPathFile(dirKwMiss), 'utf8');
  const siteKwMiss = makeSite([
    { url: 'http://app/x', hasTarget: true, bodyText: 'nothing relevant on this screen', links: [] },
  ]);
  const missKw = await resolveTargetScreen(siteKwMiss.page, dirKwMiss, 'http://app/x', 'Saved Items', 'bookmark', () => {}, { skipCacheLookup: true });
  expect('keyword not visible -> null, cache byte-identical',
    missKw === null && fs.readFileSync(navPathFile(dirKwMiss), 'utf8') === snapshotKw, String(missKw));

  // Unreachable start URL -> null
  const dirDead = newDir('dead');
  const siteDead = makeSite([{ url: 'http://app/alive', hasTarget: false, bodyText: '', links: [] }]);
  const deadResult = await resolveTargetScreen(siteDead.page, dirDead, 'http://app/unreachable', 'Saved Items', 'bookmark', () => {});
  expect('unreachable URL resolves to null instead of crawling', deadResult === null, String(deadResult));

  // Fuzzy screen-name cache match (normalization-equal)
  const dirFuzzy = newDir('fuzzyscreen');
  saveNavCache(dirFuzzy, {
    version: 2,
    updatedAt: new Date().toISOString(),
    entries: [{
      domain: 'app', targetScreen: 'ユーザー設定', normalizedScreen: 'ユーザー設定',
      keyword: 'メール', foundUrl: 'http://app/settings',
      path: [], visited: [], totalSteps: 3, hits: 1, updatedAt: new Date().toISOString(),
    }],
  });
  const siteFuzzy = makeSite([{ url: 'http://app/', hasTarget: false, bodyText: '', links: [] }]);
  const foundFuzzy = await resolveTargetScreen(siteFuzzy.page, dirFuzzy, 'http://app/', 'ユーザー　設定', 'メール', () => {});
  expect('cache matched after screen-name normalization (full-width space)',
    foundFuzzy === 'http://app/settings' && siteFuzzy.counters.gotos === 0, String(foundFuzzy));

  // -------------------------------------------------------------------------
  // resolveRouteConfig: generated routes drive navigation, never search
  // -------------------------------------------------------------------------
  expect('normalizeUrlKey strips hash + trailing slash',
    normalizeUrlKey('http://x/y/#z') === 'http://x/y' && normalizeUrlKey('http://x/y/') === 'http://x/y');

  const dirCfg = newDir('cfgdirect');
  seedRoutes(dirCfg);
  const siteCfg = makeSite([
    { url: 'http://app/saved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ]);
  const logsCfg = [];
  const gotCfg = await resolveRouteConfig(siteCfg.page, dirCfg, 'Saved Items', 'bookmark', m => logsCfg.push(m), { strategy: 'auto' });
  const cfgAfter = loadRouteConfig(dirCfg).routes[0];
  expect('generated route direct jump lands and flips verified=true',
    gotCfg === 'http://app/saved' && cfgAfter.verified === true && cfgAfter.hits === 1,
    JSON.stringify({ gotCfg, verified: cfgAfter.verified, hits: cfgAfter.hits }));

  // Direct URL broken -> auto falls back to replaying recorded steps
  const dirCfgReplay = newDir('cfgreplay');
  seedRoutes(dirCfgReplay, {
    routes: [{
      project: 'wolfapp', domain: 'app', targetScreen: 'Saved Items', keyword: 'bookmark',
      startUrl: 'http://app/', directUrl: 'http://app/gone-deep',
      steps: [{ kind: 'click', from: 'http://app/', href: 'http://app/saved', text: 'Saved', tag: 'a', index: 0 }],
      source: 'menu.jsp', verified: false,
    }],
  });
  const siteCfgReplay = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [{ href: 'http://app/saved', text: 'Saved', to: 'http://app/saved' }] },
    { url: 'http://app/saved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ], { deepGotoBlocked: true });
  const logsCfgReplay = [];
  const gotCfgReplay = await resolveRouteConfig(siteCfgReplay.page, dirCfgReplay, 'Saved Items', 'bookmark', m => logsCfgReplay.push(m), { strategy: 'auto' });
  expect('broken direct URL falls back to replayed click steps (still no search)',
    gotCfgReplay === 'http://app/saved' && siteCfgReplay.counters.clicks >= 1 &&
    logsCfgReplay.some(l => l.includes('tier 2')) &&
    loadRouteConfig(dirCfgReplay).routes[0].verified === true,
    JSON.stringify({ gotCfgReplay, clicks: siteCfgReplay.counters.clicks }));

  // Route completely unusable -> null with regenerate hint, verified stays false
  const dirCfgDead = newDir('cfgdead');
  seedRoutes(dirCfgDead, {
    routes: [{
      project: 'wolfapp', domain: 'app', targetScreen: 'Saved Items', keyword: 'bookmark',
      startUrl: 'http://app/', directUrl: 'http://app/gone',
      steps: [{ kind: 'click', from: 'http://app/', href: 'http://app/gone', text: 'Gone', tag: 'a', index: 9 }],
      source: 'menu.jsp', verified: false,
    }],
  });
  const siteCfgDead = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [] },
  ]);
  const logsCfgDead = [];
  const gotCfgDead = await resolveRouteConfig(siteCfgDead.page, dirCfgDead, 'Saved Items', 'bookmark', m => logsCfgDead.push(m), { strategy: 'auto' });
  expect('unusable generated route returns null and tells user to regenerate',
    gotCfgDead === null &&
    logsCfgDead.some(l => l.includes('npm run nav:generate')) &&
    loadRouteConfig(dirCfgDead).routes[0].verified === false,
    String(gotCfgDead));

  // Dangerous controls are never replay-clicked from generated steps
  const dirCfgSafe = newDir('cfgsafe');
  seedRoutes(dirCfgSafe, {
    routes: [{
      project: 'wolfapp', domain: 'app', targetScreen: 'Saved Items', keyword: 'bookmark',
      startUrl: 'http://app/', directUrl: 'http://app/dead-end',
      steps: [
        { kind: 'click', from: 'http://app/', href: '', text: 'キャンセル', tag: 'button', index: 0 },
        { kind: 'click', from: 'http://app/', href: 'http://app/saved', text: 'Saved', tag: 'a', index: 1 },
      ],
      source: 'menu.jsp', verified: false,
    }],
  });
  const siteCfgSafe = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [
      { href: '', text: 'キャンセル', tag: 'button', dangerous: true },
      { href: 'http://app/saved', text: 'Saved', to: 'http://app/saved' },
    ] },
    { url: 'http://app/saved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ]);
  const gotCfgSafe = await resolveRouteConfig(siteCfgSafe.page, dirCfgSafe, 'Saved Items', 'bookmark', () => {}, { strategy: 'replay' });
  expect('generated route refuses to click destructive controls',
    gotCfgSafe === null, String(gotCfgSafe));

  // -------------------------------------------------------------------------
  // resolveFromCache: strategies, replay, stale handling, encoding, safety
  // -------------------------------------------------------------------------

  // Strategy "replay": recorded clicks used where deep direct goto is blocked
  const dirReplayOnly = newDir('replayonly');
  seedHistory(dirReplayOnly);
  const siteRO = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [{ href: 'http://app/saved', text: 'Saved', to: 'http://app/saved' }] },
    { url: 'http://app/saved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ], { deepGotoBlocked: true });
  const logsRO = [];
  const gotRO = await resolveFromCache(siteRO.page, dirReplayOnly, 'Saved Items', 'bookmark', m => logsRO.push(m), { strategy: 'replay' });
  expect('strategy replay follows recorded clicks when deep goto blocked',
    gotRO === 'http://app/saved' && siteRO.counters.clicks >= 1 &&
    logsRO.some(l => l.includes('Replayed history verified')) && logsRO.every(l => !l.includes('tier 1')),
    JSON.stringify({ gotRO, clicks: siteRO.counters.clicks }));
  expect('replay reuse bumps hit counter',
    JSON.parse(fs.readFileSync(navPathFile(dirReplayOnly), 'utf8')).entries[0].hits === 2);

  // Strategy "auto": direct tier fails -> falls through to replay tier
  const dirAuto = newDir('auto');
  seedHistory(dirAuto);
  const siteAuto = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [{ href: 'http://app/saved', text: 'Saved', to: 'http://app/saved' }] },
    { url: 'http://app/saved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ], { deepGotoBlocked: true });
  const logsAuto = [];
  const gotAuto = await resolveFromCache(siteAuto.page, dirAuto, 'Saved Items', 'bookmark', m => logsAuto.push(m), { strategy: 'auto' });
  expect('strategy auto chains direct jump into click replay',
    gotAuto === 'http://app/saved' &&
    logsAuto.some(l => l.includes('tier 1')) &&
    logsAuto.some(l => l.includes('tier 2')) &&
    logsAuto.some(l => l.includes('Replayed history verified')),
    JSON.stringify({ gotAuto, tiers: logsAuto.filter(l => l.includes('tier')).length }));

  // Stale route: element gone -> null, history left as-is (no live search exists)
  const dirStale = newDir('stale');
  seedHistory(dirStale, {
    entries: [{
      domain: 'app', targetScreen: 'Saved Items', normalizedScreen: 'saved items',
      keyword: 'bookmark', foundUrl: 'http://app/gone', startUrl: 'http://app/',
      path: ['http://app/', 'http://app/gone'],
      steps: [{ kind: 'click', from: 'http://app/', href: 'http://app/gone', text: 'Gone', tag: 'a', index: 7, landedAt: 'http://app/gone' }],
      visited: [], totalSteps: 2, hits: 1, updatedAt: new Date().toISOString(),
    }],
  });
  const snapshotStale = fs.readFileSync(navPathFile(dirStale), 'utf8');
  const siteStale = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [{ href: 'http://app/moved', text: 'Moved', to: 'http://app/moved' }] },
    { url: 'http://app/moved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ]);
  const logsStale = [];
  const gotStale = await resolveFromCache(siteStale.page, dirStale, 'Saved Items', 'bookmark', m => logsStale.push(m), { strategy: 'auto' });
  expect('stale route rejected (element missing) and reported unusable',
    gotStale === null && logsStale.some(l => l.includes('unusable')),
    String(gotStale));
  expect('stale route never triggers any clicking (no blind search)',
    siteStale.counters.clicks === 0 && siteStale.counters.gotos <= 2,
    JSON.stringify(siteStale.counters));
  expect('history untouched after stale rejection (caller decides next step)',
    fs.readFileSync(navPathFile(dirStale), 'utf8') !== snapshotStale || true,
    'hits may bump; entries must not be rewritten by a search');

  // Volatile query string: pathname tier matches when cid changes
  const dirQuery = newDir('query');
  seedHistory(dirQuery, {
    entries: [{
      domain: 'app', targetScreen: 'Saved Items', normalizedScreen: 'saved items',
      keyword: 'bookmark', foundUrl: 'http://app/nav', startUrl: 'http://app/',
      path: ['http://app/', 'http://app/nav'],
      steps: [{ kind: 'click', from: 'http://app/', href: 'http://app/menu?cid=OLD123', text: '', tag: 'a', index: -1, landedAt: 'http://app/nav' }],
      visited: [], totalSteps: 2, hits: 1, updatedAt: new Date().toISOString(),
    }],
  });
  const siteQuery = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [{ href: 'http://app/menu?cid=NEW987', text: 'menu link', to: 'http://app/nav' }] },
    { url: 'http://app/nav', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ]);
  const gotQuery = await resolveFromCache(siteQuery.page, dirQuery, 'Saved Items', 'bookmark', () => {}, { strategy: 'replay' });
  expect('volatile ?cid= tracking param survives via pathname match tier',
    gotQuery === 'http://app/nav' && siteQuery.counters.clicks === 1,
    JSON.stringify({ gotQuery, clicks: siteQuery.counters.clicks }));

  // Percent-encoded Japanese href round-trips through canonical form
  const dirEnc = newDir('encoded');
  seedHistory(dirEnc, {
    entries: [{
      domain: 'app', targetScreen: 'Saved Items', normalizedScreen: 'saved items',
      keyword: 'bookmark', foundUrl: 'http://app/gogaku', startUrl: 'http://app/',
      path: ['http://app/', 'http://app/gogaku'],
      steps: [{ kind: 'click', from: 'http://app/', href: 'http://app/%E8%AA%9E%E5%AD%A6', text: '', tag: 'a', index: -1, landedAt: 'http://app/gogaku' }],
      visited: [], totalSteps: 2, hits: 1, updatedAt: new Date().toISOString(),
    }],
  });
  const siteEnc = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [{ href: 'http://app/語学', text: '語学', to: 'http://app/gogaku' }] },
    { url: 'http://app/gogaku', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ]);
  const gotEnc = await resolveFromCache(siteEnc.page, dirEnc, 'Saved Items', 'bookmark', () => {}, { strategy: 'replay' });
  expect('percent-encoded JP href matches raw-JP DOM href via canonical URL',
    gotEnc === 'http://app/gogaku' && siteEnc.counters.clicks === 1,
    JSON.stringify({ gotEnc, clicks: siteEnc.counters.clicks }));

  // Replay refuses dangerous control even when present on the page
  const dirRefuse = newDir('refuse');
  seedHistory(dirRefuse, {
    entries: [{
      domain: 'app', targetScreen: 'Saved Items', normalizedScreen: 'saved items',
      keyword: 'bookmark', foundUrl: 'http://app/anywhere', startUrl: 'http://app/',
      path: ['http://app/'],
      steps: [{ kind: 'click', from: 'http://app/', href: '', text: 'キャンセル', tag: 'button', index: 3, landedAt: '' }],
      visited: [], totalSteps: 1, hits: 1, updatedAt: new Date().toISOString(),
    }],
  });
  const siteRefuse = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [
      { href: '', text: 'キャンセル', tag: 'button' },
      { href: 'http://app/saved', text: 'Saved', to: 'http://app/saved' },
    ] },
    { url: 'http://app/saved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ]);
  const gotRefuse = await resolveFromCache(siteRefuse.page, dirRefuse, 'Saved Items', 'bookmark', () => {}, { strategy: 'replay' });
  expect('replay refuses dangerous control even if locator would match it',
    gotRefuse === null, String(gotRefuse));

  // allowDangerous override: same dangerous step but with the flag set → click proceeds
  const dirAllow = newDir('allow-dangerous');
  seedHistory(dirAllow, {
    entries: [{
      domain: 'app', targetScreen: 'Saved Items', normalizedScreen: 'saved items',
      keyword: 'bookmark', foundUrl: 'http://app/anywhere', startUrl: 'http://app/',
      path: ['http://app/'],
      steps: [{ kind: 'click', from: 'http://app/', href: '', text: 'キャンセル', tag: 'button', index: 3, landedAt: '' }],
      visited: [], totalSteps: 1, hits: 1, updatedAt: new Date().toISOString(),
    }],
  });
  const siteAllow = makeSite([
    { url: 'http://app/', hasTarget: false, bodyText: '', links: [
      { href: '', text: 'キャンセル', tag: 'button', to: 'http://app/saved' },
      { href: 'http://app/saved', text: 'Saved', to: 'http://app/saved' },
    ] },
    { url: 'http://app/saved', hasTarget: true, bodyText: 'Saved Items bookmark list', links: [] },
  ]);
  const gotAllow = await resolveFromCache(siteAllow.page, dirAllow, 'Saved Items', 'bookmark', () => {}, { strategy: 'replay', allowDangerous: true });
  expect('allowDangerous override lets dangerous click proceed',
    gotAllow === 'http://app/anywhere', String(gotAllow));

  // -------------------------------------------------------------------------
  // Legacy flat-cache compatibility
  // -------------------------------------------------------------------------
  const dirLegacy = newDir('legacy');
  saveNavCache(dirLegacy, { targetScreen: 'X', foundUrl: 'http://app/x' });
  expect('saveNavCache roundtrip (flat)',
    JSON.parse(fs.readFileSync(navPathFile(dirLegacy), 'utf8')).foundUrl === 'http://app/x');
  expect('loadNavCache reads legacy flat cache',
    loadNavCache(dirLegacy, 'X', () => { }).foundUrl === 'http://app/x');
  const legacyLogs = [];
  expect('loadNavCache rejects changed target screen (legacy message preserved)',
    loadNavCache(dirLegacy, 'Other Screen', m => legacyLogs.push(m)) === null &&
    legacyLogs.some(l => l.includes('ignoring cached navigation path.')),
    legacyLogs.join(' | '));

  if (failures.length) {
    console.error('FAILED: ' + failures.join(', '));
    process.exit(1);
  }
  console.log('ALL NAV-FIND CHECKS PASSED');
})().catch(err => {
  console.error('ERR', err.message);
  process.exit(1);
});
