const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '../run-ut.js'), 'utf8');
const hasKeywordOnlyHelper = /function isKeywordOnlyCase\(testCase\) \{\s*return !testCase\.AfterText && \(!!testCase\.Keyword \|\| !!testCase\.PartialText\);\s*\}/s.test(src);
const hasSavedPositionResolver = /function resolvePositionFromFile\(testCase\) \{[\s\S]*?Position file missing/s.test(src);
const hasTargetMetadataHelper = /function findElementTarget\(page, text, options = \{\}\) \{[\s\S]*?matchedPath[\s\S]*?stableId[\s\S]*?stableSelector[\s\S]*?targetTagName/s.test(src);
const hasPartialTextFinder = /pickFromList\(partial \? collectPartialCandidates\(text\.trim\(\)\) : findAllExact\(\), partial\)/.test(src);
const hasPartialCandidateCollection = /const collectPartialCandidates = \(needle\) => \{[\s\S]*?parent\.textContent\.includes\(needle\)[\s\S]*?el\.textContent\.includes\(needle\)/s.test(src);
const hasKeywordHintPreference = /const hint = \(keyword \|\| ''\)\.trim\(\)\.toLowerCase\(\);[\s\S]*?const withHint = pool\.filter\(el => el\.textContent\.toLowerCase\(\)\.includes\(hint\)\);[\s\S]*?return smallest\(withHint\);/s.test(src);
const hasPartialFallbackSelection = /let outcome = pickFromList\(partial \? collectPartialCandidates\(text\.trim\(\)\) : findAllExact\(\), partial\);\s*if \(!outcome\) \{\s*outcome = pickFromList\(partial \? findAllExact\(\) : collectPartialCandidates\(text\.trim\(\)\), !partial\);/s.test(src);
const hasExactCandidateEnumeration = /const findAllExact = \(\) => \{[\s\S]*?found\.push\(parent\);[\s\S]*?found\.push\(el\);/s.test(src);
const hasRenderedBoxHelper = /const renderedBoxOf = \(candidate\) => \{[\s\S]*?nearestWholeElement\(candidate\)[\s\S]*?getClientRects\(\)\.length > 0/s.test(src);
const hasVisiblePoolPreference = /const rendered = list\.filter\(candidate => renderedBoxOf\(candidate\)\);\s*const pool = rendered\.length \? rendered : list;/s.test(src);
const hasBoxFromTextElement = /const target = nearestWholeElement\(el\);[\s\S]*?rect = target\.getBoundingClientRect\(\)/s.test(src);
const hasNearestWholeElement = /const nearestWholeElement = \(el\) => \([\s\S]*?el\.closest\(WHOLE_SELECTORS\)[\s\S]*?\)/s.test(src);
const hasFreshAfterBox = /else if \(isKeywordOnlyCase\(testCase\)\) \{[\s\S]*?resolvePositionFromFile[\s\S]*?resolveFreshTargetBox/s.test(src);
const hasFallbackToSaved = /if \(!target \|\| !target\.box\)[\s\S]*?target = await findElementTarget\(page, testCase\.PartialText \|\| testCase\.Keyword, \{ partial: !!testCase\.PartialText, keyword: testCase\.Keyword \|\| '' \}\)/s.test(src);
const hasStableSelectorResolution = /function resolveFreshTargetBox\(page, target\) \{[\s\S]*?target\.stableSelector \|\| target\.stableId[\s\S]*?document\.querySelector\(selector\)/s.test(src);
const hasTextRefindNoSemantic = /resolveFreshTargetBox[\s\S]*?node\.parentElement\.textContent\.trim\(\) === target\.text\.trim\(\)[\s\S]*?await stabilizeAfterScroll\(whole\);\s*return boxOf\(whole\);/s.test(src);
const hasBeforePartialLocate = /const autoSlices = testCase\.PartialText && testCase\.AfterPartialText[\s\S]*?findElementTarget\(page, beforeText, \{[\s\S]*?partial: !!testCase\.PartialText,[\s\S]*?sliceStart: manualStart !== undefined \? manualStart : \(autoSlices \? autoSlices\.start : undefined\),[\s\S]*?sliceEnd: manualEnd !== undefined \? manualEnd : \(autoSlices \? autoSlices\.beforeEnd : undefined\)/s.test(src);
const hasAfterRequiresPosition = /const requiresSavedPosition = !testCase\.AfterText && \(!!testCase\.Keyword \|\| !!testCase\.PartialText\);/s.test(src);
const hasSpanBoxHelper = /const spanBoxOf = \(root, fragment, start = 0, end\) => \{[\s\S]*?document\.createRange\(\)[\s\S]*?range\.getBoundingClientRect\(\)/s.test(src);
const hasSpanBoxSlicedOffsets = /range\.setStart\(startPos\.node, startPos\.offset\);[\s\S]*?range\.setEnd\(lastPos\.node, lastPos\.offset \+ 1\);/s.test(src);
const hasSpanBoxMultiNodeConcat = /nodes\.push\(\{ node, offset: full\.length \}\);[\s\S]*?full \+= node\.nodeValue;/s.test(src);
const hasPartialSpanBoxResolution = /const fragmentBox = spanBoxOf\(el, text\.trim\(\), sliceStart, sliceEnd\);[\s\S]*?wholeFallback = true;/s.test(src);
const hasPartialBoxFlagInReturn = /box,\n\s+wholeFallback,\n\s+partial: !!partial,[\s\S]*?sliceStart,[\s\S]*?sliceEnd,/s.test(src);
const hasValidBoxHelper = /function isValidBox\(box\) \{[\s\S]*?box\.width > 0 && box\.height > 0;/s.test(src);
const hasBeforeDegenerateGuard = /if \(!isValidBox\(savedTarget\.box\)\) \{[\s\S]*?degenerate/s.test(src);
const hasWholeFallbackWarning = /function warnWholeFallback\(context, target\) \{[\s\S]*?target\.wholeFallback[\s\S]*?warnWholeFallback\(`\$\{testCase\.TestID\} \(\$\{testCase\.Browser\}\) before phase`, savedTarget\)/s.test(src);
const hasKeywordPassedToTargetFinder = /keyword: testCase\.Keyword \|\| '',/s.test(src);
const hasSliceWordBoundaryExpansion = /isWordChar\(before\[beforeEnd\]\) && isWordChar\(before\[beforeEnd - 1\]\)[\s\S]*?isWordChar\(after\[afterEnd\]\) && isWordChar\(after\[afterEnd - 1\]\)/s.test(src);
const hasBeforePartialBoxLocator = /const highlightLocator = keywordOnly && !textCoverBefore\s*\?\s*\{\s*type: 'target',\s*value: savedTarget\s*\}\s*:\s*\{\s*type: 'text',\s*value: gateText\s*\};/s.test(src);
const hasTextCoverBeforeCondition = /const textCoverBefore = keywordOnly && !!testCase\.BeforeText && !testCase\.PartialText;/.test(src);
const hasAfterPartialKeepsSavedBox = /if \(target && !target\.partial\) \{[\s\S]*?resolveFreshTargetBox/s.test(src);
const hasAfterPartialBoxLocator = /afterLocator = \{\s*type: 'target',\s*value: target\s*\}/s.test(src);
const hasAfterPartialFreshSlice = /let effectiveAfterPartialText = testCase\.AfterPartialText;[\s\S]*?if \(effectiveAfterPartialText\) \{[\s\S]*?sliceRange\(testCase\.PartialText, effectiveAfterPartialText\)[\s\S]*?findElementTarget\(page, effectiveAfterPartialText, \{[\s\S]*?sliceStart: afterStart,[\s\S]*?sliceEnd: afterEnd/s.test(src);
const hasToIntHelper = /function toInt\(value\) \{[\s\S]*?parseInt\(String\(value\), 10\)[\s\S]*?Number\.isFinite\(n\) \? n : undefined;/s.test(src);
const hasSliceRangeHelper = /function sliceRange\(beforeText, afterText\) \{[\s\S]*?before\[start\] === after\[start\][\s\S]*?before\[before\.length - 1 - suffix\] === after\[after\.length - 1 - suffix\]/s.test(src);
const hasMatchedTextRecorded = /matchedText: el\.textContent\.trim\(\),/s.test(src);
const hasAfterNoPartialTextAutoSlice = /} else if \(target && target\.partial && target\.matchedText\) \{[\s\S]*?sliceRange\(target\.matchedText, currentText\)[\s\S]*?const changedSlice = currentText\.slice\(autoSlices\.start, autoSlices\.afterEnd\)\.trim\(\);[\s\S]*?findElementTarget\(page, changedSlice, \{ partial: true, keyword: testCase\.Keyword \|\| '' \}\)/s.test(src);
const hasStaleTargetUpgradeCall = /if \(target && !target\.partial && testCase\.PartialText\) \{\s*target = await upgradeStaleTargetToPartial\(page, target, testCase\) \|\| target;\s*\}/s.test(src);
const hasUpgradeHelper = /async function upgradeStaleTargetToPartial\(page, target, testCase\) \{[\s\S]*?findElementTarget\(page, testCase\.PartialText, \{\s*partial: true,\s*keyword: keywordHint,\s*\}\)/s.test(src);
const hasUpgradeChangedWordFallback = /if \(!upgraded && target\.matchedText\) \{[\s\S]*?sliceRange\(target\.matchedText, currentText\)[\s\S]*?upgraded = await findElementTarget\(page, changedSlice, \{ partial: true, keyword: keywordHint \}\)/s.test(src);

const findByTextRegion = (() => {
  const s = src.indexOf('function findElementByText');
  const e = src.indexOf('function findElementTarget');
  return s !== -1 && e !== -1 && e > s ? src.slice(s, e) : '';
})();
const hasFindByTextSpanDetection = /const spanBox = spanBoxOf\(el, text\.trim\(\)\);[\s\S]*?drawOverlay\(spanBox\);[\s\S]*?return spanBox;/.test(findByTextRegion);
const hasFindByTextOverlayDiv = /ut-position-highlight/.test(findByTextRegion);
const hasFindByTextMultiNodeRange = /nodes\.push\(\{ node, offset: full\.length \}\);[\s\S]*?range\.setStart\(startPos\.node, startPos\.offset\);[\s\S]*?range\.setEnd\(lastPos\.node, lastPos\.offset \+ 1\);/.test(findByTextRegion);
const hasFindByTextBoxShadowLastResort = /const spanBox = spanBoxOf[\s\S]*?data-ut-highlight[\s\S]*?boxShadow = `0 0 0 3px \$\{annotationColor\}`;/.test(findByTextRegion);
const hasFindByTextContainmentFallback = /const exact = all\.find\(e => e\.childNodes\.length && e\.textContent\.trim\(\) === text\.trim\(\)\);[\s\S]*?const needle = text\.trim\(\);[\s\S]*?const needsBoundary = \/\^\[A-Za-z0-9\]\+\$\/\.test\(needle\);[\s\S]*?containers\.reduce\(\(best, e\) => \(!best \|\| e\.textContent\.length < best\.textContent\.length \? e : best\)\)/.test(findByTextRegion);
const hasWholeWordBoundaryMatcher = /const wholeWordIncludes = \(haystack, frag\) => \{[\s\S]*?!isWordChar\(before\) && !isWordChar\(after\)/.test(findByTextRegion);
const hasInstantScrollStabilizer = /behavior: 'instant'/.test(src)
  && /requestAnimationFrame\(\(\) => requestAnimationFrame\(resolve\)\)/.test(src)
  && (src.match(/const stabilizeAfterScroll/g) || []).length >= 4;
const hasStabilizedSavedPosition = /await stabilizeAfterScroll\(el\);\s*const target = nearestWholeElement\(el\);\s*const matchedPath = elementPath\(el\);/s.test(src);

const phaseRegion = (() => {
  const s = src.indexOf('async function runBefore(');
  const e = src.indexOf('async function runBeforeAll(');
  return s !== -1 && e !== -1 && e > s ? src.slice(s, e) : '';
})();
const hasSharedCasePageOpener = /async function openCasePage\(browser\) \{\s*const context = await browser\.newContext\(\{ viewport: \{ width: 1440, height: 900 \} \}\);\s*const page = await context\.newPage\(\);\s*return \{ context, page \};\s*\}/s.test(src);
const hasPhaseFunctionsUseSharedPage = /async function runBefore\(testCase, page(?:, browserStart)?\)/.test(phaseRegion)
  && /async function runAfter\(entry, page\)/.test(phaseRegion)
  && !phaseRegion.slice(0, phaseRegion.indexOf('async function openCasePage')).includes('newContext');
const hasBeforeAllSharedPage = /async function runBeforeAll\(cases, browsers\) \{[\s\S]*?let \{ context, page \} = await openCasePage\(browser\);[\s\S]*?runBefore\(\{ \.\.\.testCase, Browser: browserName \}, page, browserStart\);[\s\S]*?await context\.close\(\)\.catch\(\(\) => \{\}\);[\s\S]*?await browser\.close\(\);/s.test(src);
const hasAfterAllSharedPage = /async function runAfterAll\(cases, browsers\) \{[\s\S]*?let \{ context, page \} = await openCasePage\(browser\);[\s\S]*?runAfter\(entry, page\);/s.test(src);
const hasCrashGuardRecreate = /\(\{ context, page \} = await openCasePage\(browser\)\);/.test(src);

const serverSrc = fs.readFileSync(path.join(__dirname, '..', 'server.js'), 'utf8');
const navFindPath = path.join(__dirname, '..', 'nav-find.js');
const hasNavFindModule = fs.existsSync(navFindPath);
const navFindSrc = hasNavFindModule ? fs.readFileSync(navFindPath, 'utf8') : '';
const indexHtmlSrc = fs.readFileSync(path.join(__dirname, '..', 'public', 'index.html'), 'utf8');
const runUtUsesNavFind = /const \{ loadNavCache, resolveRouteConfig, resolveFromCache, normalizeUrlKey \} = require\('\.\/nav-find'\);/.test(src);
const resolveCaseUrlRegion = src.slice(src.indexOf('async function resolveCaseUrl'), src.indexOf('async function loginAndGoto'));
const loginAndGotoResolvesTargetScreen = /resolveRouteConfig\(page[\s\S]*?resolveFromCache\(page[\s\S]*?throw new Error\(`No navigation route/.test(resolveCaseUrlRegion);
const parseNavReplayStrategy = /\['auto', 'direct', 'replay'\]\.includes\(testCase\.NavReplay\)/.test(src);
const loginAndGotoSkipsRedundantGoto = /if \(normalizeUrlKey\(page\.url\(\)\) !== normalizeUrlKey\(targetUrl\)\) \{\s*await page\.goto\(targetUrl/.test(src);
const writeReportNavigationLine = /function describeNavigation\(testCase\) \{[\s\S]*?loadNavCache\(REPORT_DIR, testCase\.TargetScreen/.test(src)
  && /`- Navigation: \$\{item\.Navigation\}`/.test(src);
const serverEmitsNavReplayConditional = /data\.navReplay === 'direct' \|\| data\.navReplay === 'replay'[\s\S]*?lines\.push\(`- NavReplay: \$\{data\.navReplay\}`\);/s.test(serverSrc);
const navFindHasReplayEngine = navFindSrc.includes('// nav-replay-locator')
  && navFindSrc.includes('async function resolveFromCache(')
  && navFindSrc.includes("? opts.strategy : 'auto'");
const navFindHasDangerFilter = navFindSrc.includes('DANGEROUS_TEXT_RE')
  && navFindSrc.includes('ログアウト')
  && navFindSrc.includes('キャンセル');
const navFindSkipsCacheOnHeal = navFindSrc.includes('opts.skipCacheLookup');
const navFindExportsDangerousRe = navFindSrc.includes('DANGEROUS_TEXT_RE,');
const navFindReplayAllowDangerous = navFindSrc.includes('input.allowDangerous');
const indexHasDangerousOk = indexHtmlSrc.includes('id="dangerousOk"')
  && indexHtmlSrc.includes('Allow Dangerous Clicks');
const serverWritesDangerousOk = serverSrc.includes('DangerousOk: true');
const runUtPassesDangerousOk = src.includes('testCase.DangerousOk')
  && src.includes('allowDangerous');
const indexHasStrategySelect = indexHtmlSrc.includes('id="navReplay"')
  && indexHtmlSrc.includes('id="navReplayHint"')
  && indexHtmlSrc.includes("getElementById('navReplay').value");
const serverRunUsesCacheOnly = /const cached = loadNavCache\(REPORT_DIR, data\.targetScreen/.test(serverSrc)
  && !serverSrc.includes('findTargetScreen(')
  && !serverSrc.includes('pwBrowser.launch');
const buildCaseBlockWritesBaseUrl = /`- BaseURL: \$\{data\.baseUrl \|\| data\.url\}`/.test(serverSrc);
const serverRequiresKeywordDiff = /const \{ classifyKeywordChange \} = require\('\.\/keyword-diff'\);/.test(serverSrc);
const buildCaseBlockAutoPartial = /lines\.push\(`- PartialText: \$\{change\.beforeFragment\}`\);[\s\S]*?lines\.push\(`- AfterPartialText: \$\{change\.afterFragment\}`\);/.test(serverSrc);

const allChecks = [
  ['isKeywordOnlyCase handles PartialText', hasKeywordOnlyHelper],
  ['saved position resolver', hasSavedPositionResolver],
  ['findElementTarget metadata helpers', hasTargetMetadataHelper],
  ['findElementTarget substring finder', hasPartialTextFinder],
  ['findElementTarget candidate collection', hasPartialCandidateCollection],
  ['findElementTarget keyword hint preference', hasKeywordHintPreference],
  ['findElementTarget partial/exact selection', hasPartialFallbackSelection],
  ['findElementTarget exact candidate enumeration', hasExactCandidateEnumeration],
  ['findElementTarget rendered-box helper', hasRenderedBoxHelper],
  ['findElementTarget prefers visible candidates', hasVisiblePoolPreference],
  ['whole-element box from text element', hasBoxFromTextElement],
  ['nearestWholeElement helper', hasNearestWholeElement],
  ['after phase fresh box resolution', hasFreshAfterBox],
  ['after phase fallback to saved', hasFallbackToSaved],
  ['stable selector resolution', hasStableSelectorResolution],
  ['text re-find without semantics', hasTextRefindNoSemantic],
  ['before phase auto-slice locate', hasBeforePartialLocate],
  ['after phase requires saved position', hasAfterRequiresPosition],
  ['spanBoxOf range-based helper', hasSpanBoxHelper],
  ['spanBoxOf sliced offsets', hasSpanBoxSlicedOffsets],
  ['spanBoxOf multi-node concatenation', hasSpanBoxMultiNodeConcat],
  ['partial box resolves to text span', hasPartialSpanBoxResolution],
  ['partial flag + slice in target metadata', hasPartialBoxFlagInReturn],
  ['isValidBox helper', hasValidBoxHelper],
  ['before phase degenerate box guard', hasBeforeDegenerateGuard],
  ['whole-element fallback warning', hasWholeFallbackWarning],
  ['keyword passed to target finder', hasKeywordPassedToTargetFinder],
  ['sliceRange word-boundary expansion', hasSliceWordBoundaryExpansion],
  ['before phase partial target locator', hasBeforePartialBoxLocator],
  ['before phase text-cover condition', hasTextCoverBeforeCondition],
  ['after phase partial keeps saved box', hasAfterPartialKeepsSavedBox],
  ['after phase partial target locator', hasAfterPartialBoxLocator],
  ['after phase fresh slice locate', hasAfterPartialFreshSlice],
  ['toInt helper', hasToIntHelper],
  ['sliceRange helper', hasSliceRangeHelper],
  ['matchedText recorded in target', hasMatchedTextRecorded],
  ['after phase no-AfterPartialText auto-slice', hasAfterNoPartialTextAutoSlice],
  ['stale whole-element target upgraded to partial', hasStaleTargetUpgradeCall],
  ['upgrade helper locates fragment', hasUpgradeHelper],
  ['upgrade changed-word fallback slice', hasUpgradeChangedWordFallback],
  ['findElementByText text-span detection', hasFindByTextSpanDetection],
  ['findElementByText overlay div', hasFindByTextOverlayDiv],
  ['findElementByText multi-node range', hasFindByTextMultiNodeRange],
  ['findElementByText element-boxShadow last resort', hasFindByTextBoxShadowLastResort],
  ['findElementByText containment fallback', hasFindByTextContainmentFallback],
  ['findElementByText whole-word boundary matcher', hasWholeWordBoundaryMatcher],
  ['scroll-then-stabilize used by box locators', hasInstantScrollStabilizer],
  ['keyword centered before saving position', hasStabilizedSavedPosition],
  ['shared case page opener per browser', hasSharedCasePageOpener],
  ['phase functions use shared page', hasPhaseFunctionsUseSharedPage],
  ['before phase single window for all cases', hasBeforeAllSharedPage],
  ['after phase single window for all cases', hasAfterAllSharedPage],
  ['crash guard recreates page', hasCrashGuardRecreate],
  ['nav-find shared module exists', hasNavFindModule],
  ['run-ut uses shared nav finder', runUtUsesNavFind],
  ['resolveCaseUrl verifies history then falls back live (skip stale cache)', loginAndGotoResolvesTargetScreen],
  ['NavReplay strategy parsed and whitelisted', parseNavReplayStrategy],
  ['loginAndGoto skips redundant goto after replay', loginAndGotoSkipsRedundantGoto],
  ['report shows Navigation history line', writeReportNavigationLine],
  ['server emits conditional NavReplay field', serverEmitsNavReplayConditional],
  ['nav-find has replay engine + locator marker', navFindHasReplayEngine],
  ['nav-find has EN+JP dangerous-control filter', navFindHasDangerFilter],
  ['live heal bypasses stale cache lookup', navFindSkipsCacheOnHeal],
  ['nav-find exports DANGEROUS_TEXT_RE', navFindExportsDangerousRe],
  ['replayClickStep accepts allowDangerous param', navFindReplayAllowDangerous],
  ['index.html has Allow Dangerous Clicks checkbox', indexHasDangerousOk],
  ['server writes DangerousOk to ut_cases.md', serverWritesDangerousOk],
  ['run-ut passes DangerousOk through to nav-find', runUtPassesDangerousOk],
  ['index.html offers navigation strategy select with hint', indexHasStrategySelect],
  ['server /run is cache-only (no browser launch)', serverRunUsesCacheOnly],
  ['case block stores BaseURL', buildCaseBlockWritesBaseUrl],
  ['server uses keyword-diff classifier', serverRequiresKeywordDiff],
  ['buildCaseBlock emits auto partial fragments', buildCaseBlockAutoPartial],
];

const failed = allChecks.filter(([, ok]) => !ok);
if (failed.length) {
  throw new Error(`Keyword-only mode regression check failed: ${failed.map(([name]) => name).join(', ')}`);
}

console.log('keyword-only mode regression check passed');