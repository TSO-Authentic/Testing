# Navigation — Config-Driven Route Resolution

Navigation for each UT case is resolved from two static knowledge files, **never**
by crawling or blind link-searching.

```
resolveCaseUrl(page, testCase)
│
├─ P-1  nav-routes.json           ← auto-generated routes (npm run nav:generate)
│     findRouteEntry() → direct goto or step replay
│     verified flag flipped on success; stale entry reported
│
├─ P0   ut-report/navigation-path.json   ← learned cache from previous runs
│     loadNavCache() → direct goto or step replay
│     hits incremented on reuse
│
└─ ERROR: hard stop — no blind search fallback.
   Fix: add the route to nav-sources.json, run npm run nav:generate,
   or manually add an entry to nav-routes.json.
```

Both layers use the same execution logic controlled by the per-case
`NavReplay` field (or the UI dropdown):

| Strategy | Behaviour |
|---|---|
| `auto` *(default)* | ① direct jump → verify heading + keyword → fail ⇒ ② replay recorded clicks from startUrl → verify → fail ⇒ null |
| `direct` | tier ① only |
| `replay` | tier ② directly (falls back to ① when no steps recorded) |

---

## nav-routes.json — auto-generated routes

Created and updated by `nav-gen.js`. Entries are **never** overwritten by the
runner — only `verified`, `foundUrl`, and `hits` are updated on successful
navigation.

```jsonc
{
  "version": 1,
  "updatedAt": "…",
  "sources": [
    { "name": "my-app", "path": "C:/work/my-app", "baseUrl": "http://localhost:8080/my-app" }
  ],
  "routes": [
    {
      "project": "my-app",
      "domain": "localhost",
      "targetScreen": "Flashcards",
      "normalizedScreen": "flashcards",
      "keyword": "All in",
      "startUrl": "http://localhost:8080/my-app/",
      "directUrl": "http://localhost:8080/my-app/flashcards/list.jsp",
      "routePath": "/my-app/flashcards/list.jsp",
      "steps": [
        { "kind": "click", "from": "…", "href": "…", "text": "Flashcards", "tag": "a", "index": -1 }
      ],
      "inMenu": true,
      "source": "src/main/webapp/index.jsp",
      "extractedKind": "anchor",
      "score": 105,
      "verified": false,
      "hits": 0
    }
  ]
}
```

**Key fields:**

- `directUrl` — absolute URL for the direct-jump tier. Empty when `baseUrl` is
  not configured in `nav-sources.json` (route is inert until you add it).
- `steps` — click replay instructions. `text` + `tag` + `index` identify the
  element on the start page.
- `inMenu` — true when the click step targets a nav/menu container element.
  Used to prefix the step label with "Navigate to: " in logs.
- `verified` — set to true after a successful direct jump or replay. Reset to
  false when `directUrl` changes (re-extraction).
- `hits` — incremented every time the route is successfully reused.

### Generating routes

1. Fill in `nav-sources.json`:

```json
{
  "sources": [
    { "name": "my-app", "path": "C:/work/my-app", "baseUrl": "http://localhost:8080/my-app" }
  ]
}
```

2. Run:

```bash
npm run nav:generate
# or directly:
node nav-gen.js C:/work/my-app
```

The generator scans each source project for:
- `web.xml` / `jboss-web.xml` → context root, welcome files, display name
- Markup files (`.jsp`, `.html`, `.vue`, `.jsx`, `.tsx`) → `<a href>`, `<form>`,
  Struts `<html:link>`, JSTL `<c:url>`, Vue Router `<router-link>`,
  React Router `<Link>` / `<NavLink>`
- JS/TS router configs → Next.js `app/` + `pages/` dirs, Nuxt `pages/` dir,
  `createBrowserRouter` / `createWebHistory` routes
- Java controllers → `@RequestMapping` / `@GetMapping` / `@PostMapping` paths
- XML / properties → screen-ID to URL mappings

Matched candidates are scored against `TargetScreen` values in `ut_cases.md`
(using `scoreLink` + menu bonus). Best match per screen is written as a route.

**What `baseUrl` does:** when set, `directUrl` becomes an absolute URL
(`baseUrl + routePath`) the runner can navigate to. Without it, `directUrl` is
empty and the runner cannot reach the screen.

### Manual editing

You can add/edit/delete entries by hand. The runner only updates `verified`,
`foundUrl`, and `hits` — all other fields are preserved. Extra fields
(e.g. `"notes": "…"`) are never removed.

The `upsertRouteEntry` function matches entries by `project` + screen name.
If the URL changes on re-extraction, `verified` is reset to `false`.

---

## navigation-path.json — learned cache

Written automatically after each successful navigation that was NOT served by
`nav-routes.json`. Schema version 2:

```jsonc
{
  "version": 2,
  "updatedAt": "…",
  "entries": [
    {
      "domain": "app.example.com",
      "targetScreen": "ユーザー設定",
      "normalizedScreen": "ユーザー設定",
      "keyword": "メール",
      "foundUrl": "https://…",
      "startUrl": "https://…",
      "steps": [{ "kind": "click", "from": "…", "href": "…", "text": "設定", "tag": "a", "index": 5 }],
      "path": ["url1", "url2"],
      "visited": ["…"],
      "totalSteps": 4,
      "hits": 3,
      "updatedAt": "…"
    }
  ]
}
```

* `path` and `visited` are legacy mirrors kept for old readers.
* `hits` is incremented on every successful reuse.
* Old flat cache files are auto-migrated to a v2 entry on the next save.

---

## Link scoring (`scoreLink`) — pure, exported

Used by the runner for on-page verification and historically for blind search
(removed). Still exported for test coverage.

| Signal | Points |
|---|---|
| TargetScreen/Keyword phrase in link text | +60 |
| … in aria-label / title | +45 |
| … in href slug | +35 |
| … in surrounding context (≤120 chars) | +10 |
| distinct search-token hits | ×15, cap +30 |
| CJK-bigram Dice similarity ≥0.6 | ≤ +25 |
| cross-origin href | −100 |
| asset href (png/pdf/js/…) · mailto:/tel:/javascript: | rejected |

Normalization: NFKC → lowercase → strip whitespace/punctuation
(`normalizeForMatch`, exported). Fuzzy uses character bigrams with the Dice
coefficient (`diceSimilarity`), so `問い合わせフォーム` matches
`お問い合わせフォーム`.

## Clickable controls & safety filter

Collection covers `a[href], button:not([disabled]), [role="link"],
[role="button"]:not([disabled]), [data-href], [data-to], [data-url]`.
`DANGEROUS_TEXT_RE` (EN+JP blocklist: logout/削除/退会/解約/購入/支払/決済/
有料/配信停止/登録解除/キャンセル…) is checked at **replay time** and blocks
the click. Form-submit buttons, disabled and `aria-disabled` controls are
skipped. ログイン is deliberately not blocked.

## Modal handling

Escape → Skip/N5 buttons → generalized close sweep:
`OK/はい/閉じる/close/同意/開始/後で` text, `aria-label*=close`,
`.modal-close`, `[data-dismiss=modal]`.

## Tests

```bash
node tests\nav-find.test.js             # 46 checks: helpers, cache, route config, replay, stale
node tests\nav-routes-config.test.js     # 9 checks: merge, generator fixture, verified flip
node tests\keyword-only-mode.test.js    # regression: code-structure assertions
node tests\keyword-diff.test.js         # keyword-diff classifier
```
