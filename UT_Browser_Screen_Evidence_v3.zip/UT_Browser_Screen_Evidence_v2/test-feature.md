# UT Browser Screen Evidence — Test Feature

## Overview

Single-page UI with two tabs for managing UT test cases and form element definitions for Playwright automation.

- **Tab 1 — Test Cases**: List, edit, and delete test cases
- **Tab 2 — Form Builder**: Google Forms-style interface to add form elements with values

Data is stored in `test-cases.json` and managed via REST API endpoints.

---

## Pages

| Page | URL | Description |
|------|-----|-------------|
| Index | `http://localhost:3000/` | Main page with tabs |

---

## Form Element Types

Playwright can fill these element types one by one:

| Type | Description | Value Format |
|------|-------------|--------------|
| `text` | Text input field | Any text string |
| `password` | Password input field | The password to type |
| `textarea` | Multi-line text area | The text to fill |
| `checkbox` | Checkbox toggle | `checked` / `unchecked` |
| `radio` | Radio button | Value of the radio to select |
| `select` | Dropdown / select menu | Option text or value |
| `date` | Date picker input | `YYYY-MM-DD` format |
| `number` | Number input field | Numeric value |
| `email` | Email input field | `user@example.com` |
| `url` | URL input field | Full URL string |

---

## REST API (Curl)

Base URL: `http://localhost:3000`

### List All Test Cases

```bash
curl http://localhost:3000/api/cases
```

### Get Single Test Case

```bash
curl http://localhost:3000/api/cases/UT-001
```

### Create New Test Case

```bash
curl -X POST http://localhost:3000/api/cases \
  -H "Content-Type: application/json" \
  -d '{
    "targetScreen": "N5 Kanji Lessons",
    "keyword": "11 lessons · 110 kanji",
    "elements": [
      { "type": "text", "label": "Search", "value": "kanji" },
      { "type": "checkbox", "label": "Remember me", "value": "checked" },
      { "type": "select", "label": "Language", "value": "Japanese" }
    ]
  }'
```

### Update Existing Test Case

```bash
curl -X PUT http://localhost:3000/api/cases/UT-001 \
  -H "Content-Type: application/json" \
  -d '{
    "targetScreen": "N5 Kanji Lessons",
    "keyword": "11 lessons · 110 kanji",
    "elements": [
      { "type": "text", "label": "Search", "value": "updated value" }
    ]
  }'
```

### Delete Test Case

```bash
curl -X DELETE http://localhost:3000/api/cases/UT-001
```

### Get Available Target Screens

```bash
curl http://localhost:3000/api/routes
```

Returns target screens from `nav-routes.json`:

```json
[
  {
    "targetScreen": "N5 Kanji Lessons",
    "directUrl": "http://localhost:5173/KanjiLesson",
    "keyword": "11 lessons · 110 kanji"
  }
]
```

---

## Data Format (test-cases.json)

```json
[
  {
    "id": "UT-001",
    "targetScreen": "N5 Kanji Lessons",
    "keyword": "11 lessons · 110 kanji",
    "elements": [
      {
        "type": "text",
        "label": "Search input",
        "value": "kanji"
      },
      {
        "type": "checkbox",
        "label": "Accept terms",
        "value": "checked"
      },
      {
        "type": "select",
        "label": "Language dropdown",
        "value": "Japanese"
      }
    ]
  }
]
```

---

## Workflow

1. **Generate navigation routes**: `npm run nav:generate` (populates `nav-routes.json`)
2. **Open the tool**: `npm run form` → opens `http://localhost:3000`
3. **Tab 1**: View existing test cases
4. **Click "Add New Test"** → switches to Tab 2
5. **Select Target Screen** from dropdown (auto-populated from routes)
6. **Enter Keyword** for verification
7. **Click "Add Form Element"** to add rows — each row has:
   - Type selector (text, checkbox, select, etc.)
   - Label / CSS selector name
   - Value to enter
8. **Save** — writes to `test-cases.json`
9. **Edit**: Click Edit on any row in Tab 1 → pre-fills the form builder
10. **Delete**: Click Delete → confirmation dialog → removes from JSON

---

## Curl Quick Reference

| Action | Command |
|--------|---------|
| List all | `curl http://localhost:3000/api/cases` |
| Get one | `curl http://localhost:3000/api/cases/UT-001` |
| Create | `curl -X POST http://localhost:3000/api/cases -H "Content-Type: application/json" -d '{...}'` |
| Update | `curl -X PUT http://localhost:3000/api/cases/UT-001 -H "Content-Type: application/json" -d '{...}'` |
| Delete | `curl -X DELETE http://localhost:3000/api/cases/UT-001` |
| Routes | `curl http://localhost:3000/api/routes` |

<!-- CASES:AUTO -->
## Current Test Cases (auto-generated)

Regenerated automatically whenever cases are created, updated or deleted through the UI/API. Each form element gets its own detail row.

| ID | Target Screen | Keyword | NavReplay | Browsers | # | Element Details |
|----|---------------|---------|-----------|----------|---|-----------------|
| UT-001 | Saved Items | I want to know saved items | replay | Edge | 0 | — |
| UT-002 | Add New Employee | Fill in the employee details below | replay | Chrome | 6 | text · Full Name · Myo |
| | | | | | | text · Email · mjirre@gmail.coms |
| | | | | | | text · Phone · 09748456752 |
| | | | | | | select · Department · HR |
| | | | | | | text · Position · IT Support Technician |
| | | | | | | date · Join Date · 08/27/2026 |
| UT-003 | 誰かのために、 | 誰かのために、社会のために。 | replay | Chrome | 0 | — |
| UT-004 | Add New Employee | Enter the employee information below. | replay | Chrome | 6 | text · Full Name · Myo |
| | | | | | | text · Email · mlyand@gmail.coms |
| | | | | | | text · Phone · 09748456752 |
| | | | | | | select · Department · HR |
| | | | | | | text · Position · IT Support Technician |
| | | | | | | date · Join Date · 08/27/2026 |
<!-- /CASES:AUTO -->
